# Shell command reference

The prompt is `chakra>`. Type `help` for a short list, or `help files`, `help system`, `help tasks`, `help keys` for details.

## Files

File names are 8.3 (up to 8 letters, a dot, up to 3 letters), any case. With a disk they are saved on it and survive reboot; without a disk they live in a 16-file RAM disk.

| Command | What it does | Example |
|---|---|---|
| `ls` (`dir`) | List files, sizes and free space | `ls` |
| `cat <f>` (`type`) | Show a file | `cat README.TXT` |
| `write <f> <text>` | Create or replace a file | `write todo.txt buy milk` |
| `append <f> <text>` | Add a line to a file | `append todo.txt call mum` |
| `cp <a> <b>` (`copy`) | Copy a file | `cp todo.txt backup.txt` |
| `ren <a> <b>` | Rename a file | `ren backup.txt old.txt` |
| `rm <f>` (`del`) | Delete a file | `rm old.txt` |
| `hexdump <f>` | Show the first 128 bytes in hex | `hexdump KERNEL.BIN` |
| `wc <f>` | Count lines, words and bytes | `wc README.TXT` |
| `df` | Disk space | `df` |

## System

| Command | What it does | Example |
|---|---|---|
| `mem` (`free`) | RAM, free pages, paging state, heap use | `mem` |
| `memmap` | The BIOS memory map (E820) | `memmap` |
| `cpu` | CPU vendor string | `cpu` |
| `disk` | Boot drive, disk size, file system, space | `disk` |
| `uptime` | Time since boot | `uptime` |
| `time`, `date` | Read the hardware clock | `time` |
| `sleep <seconds>` | Wait (up to 60) | `sleep 3` |
| `color <fg> [bg]` | Change text colours by name or number 0-15 | `color lightgreen black` |
| `clear` (`cls`) | Clear the screen | `clear` |
| `chakras` | The seven chakras in colour | `chakras` |
| `about`, `ver` | Show the banner and version | `about` |
| `crash div0\|null\|ud` | Trigger a kernel panic on purpose | `crash null` |
| `reboot`, `halt` | Restart or stop | `reboot` |

## Tasks and the desktop

| Command | What it does | Example |
|---|---|---|
| `tasks` (`ps`) | List tasks, state, CPU ticks, progress | `tasks` |
| `bg primes <n>` | Count primes up to n in the background; result goes to `PRIMES.TXT` | `bg primes 300000` |
| `bg count` | A background counter; watch PROGRESS in `tasks` | `bg count` |
| `kill <id>` | Stop a task (ids 0 and 1 are protected) | `kill 2` |
| `ui` | Open the text-mode desktop (in graphics mode the desktop is already running) | `ui` |

## Other

| Command | What it does | Example |
|---|---|---|
| `echo <text>` | Print text | `echo hello` |
| `calc <expr>` | Integer maths with `+ - * / %` and brackets | `calc (2+3)*7` |
| `history` | List recent commands | `history` |

## Disk and file manager

| Command | What it does | Example |
|---|---|---|
| `disk` | Disk size, FAT12 layout, clusters, space bar | `disk` |
| `df` | Used and free space with a bar | `df` |
| `fsck` | Check the file system for problems | `fsck` |
| `fsck fix` | Check and repair (frees lost clusters, fixes wrong sizes and broken chains) | `fsck fix` |
| `label [name]` | Show or set the volume label | `label MYDISK` |
| `stat <f>` | Size, first cluster, chain length, modified time | `stat README.TXT` |
| `touch <f>` | Create an empty file | `touch notes.txt` |
| `format yes` | Erase all files (`KERNEL.BIN` is kept so the disk still boots) | `format yes` |

## Reading and editing files

| Command | What it does | Example |
|---|---|---|
| `more <f>` (`less`) | Show a file one page at a time (space = next, q = quit) | `more WELCOME.TXT` |
| `edit <f>` | Line editor: `p` list, `a` add lines (end with `.`), `i N` insert, `d N` delete, a number replaces a line, `w` save, `q` quit | `edit notes.txt` |

## Network, web and USB

| Command | What it does | Example |
|---|---|---|
| `lspci` | List PCI devices | `lspci` |
| `net` (`ifconfig`) | Network card, MAC, IP, gateway, DNS | `net` |
| `dhcp` | Get an address | `dhcp` |
| `ping <ip or name>` | Four pings | `ping 10.0.2.2` |
| `nslookup <name>` | Look up an IP address | `nslookup github.com` |
| `get <url> [file]` (`wget`) | Fetch a page, print the start or save it | `get http://10.0.2.2:8000/a.txt a.txt` |
| `web <url>` (`browse`) | Fetch a page and show it as text (opens the Browser on the desktop) | `web http://10.0.2.2:8000/` |
| `usb` | USB controllers and devices | `usb` |
| `bt` (`bluetooth`) | Probe a USB Bluetooth adapter | `bt` |

## Basic input and output

| Command | What it does | Example |
|---|---|---|
| `beep [hz] [ms]` | Sound the PC speaker | `beep 600 200` |
| `inb <port>` | Read a byte from an I/O port (hex) | `inb 61` |
| `outb <port> <value>` | Write a byte to an I/O port (hex). Careful: wrong ports can hang the machine | `outb 80 1` |
| `keys` | Key monitor: shows the code of each key; Esc quits | `keys` |

## Redirection

Send any command's output to a file with `>` (replace) or `>>` (add):

```
ls > files.txt
echo first > log.txt
mem >> log.txt
```

## Editing keys

| Key | Action |
|---|---|
| Left / Right, Home / End | Move in the line (also `Ctrl+A` start, `Ctrl+E` end) |
| Backspace, Delete | Remove characters |
| Up / Down | Command history (the last 16 commands) |
| Tab | Complete a command name or a file name (if several names match, they are listed) |
| `Ctrl+U` | Clear the line |
| `Ctrl+C` | Cancel the line |
| `Ctrl+L` | Clear the screen |

A line can hold up to 70 characters.

## Colour names

`black blue green cyan red magenta brown lightgrey darkgrey lightblue lightgreen lightcyan lightred lightmagenta yellow white`
