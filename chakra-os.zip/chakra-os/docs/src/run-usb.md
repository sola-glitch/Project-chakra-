# Run Chakra on a real PC from a USB stick

This puts Chakra on a USB stick and boots a physical computer from it. Read the warnings first.

> **Warning 1: writing the image erases the stick.** Everything on the USB stick is overwritten. Use an empty stick. Choosing the wrong device letter can destroy your computer's own disk, so double check it.
>
> **Warning 2: this build has been tested in emulators, not yet on real hardware.** Chakra does not write to your computer's disks, so the risk is low, but a particular PC may not boot it. Try it on a spare machine first.

## What the PC needs

- An x86 PC that can boot in **legacy BIOS mode** (called "Legacy", "CSM" or "BIOS" in its settings). Almost any PC from before about 2020 qualifies, and many newer ones offer a compatibility mode. A pure-UEFI machine with no legacy option cannot boot Chakra.
- A USB stick of any size (the image is only 1.44 MB).
- A keyboard. A built-in keyboard works. For an external USB keyboard, enable "USB legacy support" in the BIOS if the keys do not respond.

## Step 1: Write the image to the stick

### On Linux

1. Plug in the stick and find its device name:
   ```
   lsblk -o NAME,SIZE,MODEL,TRAN
   ```
   Look for the line with `usb` in the last column, for example `sdb`. Use the whole device (`/dev/sdb`), not a partition (`/dev/sdb1`).
2. Unmount it:
   ```
   sudo umount /dev/sdb* 2>/dev/null
   ```
3. Write the image (replace `sdb`):
   ```
   sudo dd if=dist/chakra.img of=/dev/sdb bs=1M conv=fsync status=progress
   sync
   ```

### On macOS

```
diskutil list
diskutil unmountDisk /dev/diskN
sudo dd if=dist/chakra.img of=/dev/rdiskN bs=1m
diskutil eject /dev/diskN
```

Replace `N` with the number of the USB stick shown by `diskutil list`.

### On Windows

Use a tool that can write a raw disk image:

- **Rufus**: choose the stick, click SELECT and pick `chakra.img`, and if asked choose **DD Image mode**, then START.
- **balenaEtcher**: Flash from file, choose `chakra.img`, choose the stick, Flash.

### On Android

Writing raw images to USB from a phone is unreliable. Use a PC for this step, or run Chakra in an emulator on the phone instead (see the Android guide).

## Step 2: Boot from the stick

1. Plug the stick into the target PC and turn it on.
2. Open the one-time boot menu. The key depends on the maker. Common ones: `F12` (Dell, Lenovo, Acer), `F9` or `Esc` (HP), `F8` or `F11` (Asus, MSI, Gigabyte). Watch for a hint on the first screen.
3. Pick the USB entry. If you see two (for example one starting with `UEFI:`), choose the one **without** `UEFI`. If there is only a UEFI entry, enter the BIOS setup and enable Legacy/CSM boot first, then retry.
4. You should see `Chakra stage 2`, `Loading KERNEL.BIN...`, `Press T for text mode...`, then the graphical desktop with a Terminal window and `chakra>`. Type `help`. If the screen stays black or garbled, restart and press **T** when prompted to use text mode.

> **Files on a USB boot are not saved.** Chakra's disk driver talks to IDE-style disks, and a USB stick is not one, so after a USB boot `disk` says "RAM disk" and your files vanish at reboot. Everything else works: the desktop, shell, tasks and memory manager. The mouse works if the PC has a PS/2 mouse or a touchpad (a USB mouse works when the BIOS emulates PS/2 for it). The network works only on a PC with a Realtek RTL8139 card, which is rare today; `usb` lists devices only on old-style UHCI controllers, so on most modern PCs it reports the controller as detected but not supported. To keep files, run Chakra in an emulator (the image file keeps them).

## Step 3: Get your stick back

Chakra only uses the first 1.44 MB of the stick (it is a small FAT12 volume, so Windows or Linux may show the stick as a tiny disk containing `KERNEL.BIN`, `README.TXT` and `WELCOME.TXT`; that is normal). To use the stick normally again, reformat it: on Windows right-click it in Explorer and choose Format; on Linux run `sudo wipefs -a /dev/sdb` and create a new partition table with your disk tool; on macOS use Disk Utility, Erase.

## Troubleshooting

| Problem | What to do |
|---|---|
| The stick is not in the boot menu | Legacy/CSM may be off. Enable it in BIOS setup. Also try a different USB port (a USB 2.0 port is more reliable). |
| `Chakra: cannot read stage 2` | The BIOS is treating the stick in an unusual way. Try the other boot entry for the same stick (for example "USB-HDD" versus "USB-FDD"), or try another stick. |
| `Disk read error` or `KERNEL.BIN not found` | The image was not written completely. Write it again and run `sync` before unplugging. |
| Machine restarts or hangs right after the stage 2 messages | Try another PC. Some BIOSes handle the A20 line or memory calls differently; send the exact PC model when asking for a fix. |
| Keyboard does not respond | Enable "USB legacy support" / "USB keyboard support" in BIOS, or use a PS/2 or built-in keyboard. |
| Desktop is garbled or black | Restart and press **T** at the prompt to use text mode. |
| Screen blank but PC is running | Some PCs start the display in a non-text mode. Try a different PC or a different video output. |
| `disk` says RAM disk | Expected on USB boot, see the note in Step 2. |
