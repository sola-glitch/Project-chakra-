# Chakra OS

Chakra OS is an operating system written from scratch: its own two-stage bootloader, kernel, memory manager, multitasking, file system, network stack, graphical desktop and shell. It is not a Linux respin. It boots on any x86 PC or PC emulator that starts in BIOS mode.

> **Version 1.0.0.** It boots into a graphical desktop with windows and a mouse, runs preemptive multitasking with paging and a heap, saves files on a FAT12 disk, reaches the internet over TCP/IP and HTTP, and has a USB foundation with a Bluetooth probe. About 6,000 lines in total.

## What you get

| Piece | What it does |
|---|---|
| `boot/stage1.asm`, `boot/stage2.asm` | Two-stage loader: FAT12 boot sector, then a loader that reads the BIOS memory map, picks a video mode, finds `KERNEL.BIN` and enters protected mode. |
| `kernel/mm.c` | Page allocator, paging (NULL guard) and the `kmalloc` heap. |
| `kernel/sched.c` | Preemptive round-robin multitasking, 100 task switches a second. |
| `kernel/gfx.c`, `kernel/gui.c`, `kernel/mouse.c` | Framebuffer graphics, the desktop (windows, taskbar, 6 apps) and the PS/2 mouse. |
| `kernel/ata.c`, `kernel/fat12.c`, `kernel/fs.c`, `kernel/diskman.c` | Disk driver, FAT12 read/write, file system front end, disk and file manager (check, repair, label, format). |
| `kernel/pci.c`, `kernel/rtl8139.c`, `kernel/net.c`, `kernel/http.c` | PCI, network card, TCP/IP, DHCP, DNS, ping, HTTP and the HTML-to-text viewer. |
| `kernel/uhci.c` | USB host controller driver, device discovery and the Bluetooth probe. |
| `kernel/shell.c`, `kernel/iocmd.c`, `kernel/netcmd.c` | The `chakra>` shell with history, tab completion, redirection and about 60 commands. |
| `dist/chakra.img` | A ready-to-run disk image, so you do not have to build anything to try it. |

## Fastest way to try it

Copy the image first, because Chakra saves your files into it:

```
cp dist/chakra.img work.img
qemu-system-i386 -drive format=raw,file=work.img -nic user,model=rtl8139
```

A window opens with the Chakra desktop. No screen available (for example in Termux on Android)?

```
qemu-system-i386 -drive format=raw,file=work.img -nographic -nic user,model=rtl8139
```

Then pick the guide for where you want to run it:

- [Run on a PC emulator](run-pc-emulator.html)
- [Run on a real PC from USB](run-usb.html)
- [Run on an Android phone](run-android.html)

New here? Read [How to use it](using-chakra.html) and [What it is for](uses.html). The new features have their own pages: [the desktop](desktop.html), [internet and the web](internet.html), [USB and Bluetooth](usb-bluetooth.html). To understand how it works, see [Architecture](architecture.html). To see how it compares with the nanobyte OS tutorial, see [Chakra vs nanobyte](compare.html).

## Honest status

Tested in QEMU: boot as a hard disk and as a floppy, graphics and text modes, both build toolchains (GCC and Clang), files surviving a reboot, the disk checker and repair, tasks and background jobs, history and tab completion, the panic screen, the desktop apps with real mouse and keyboard input, DHCP, DNS, ping, TCP and HTTP (including a real internet request), USB device listing, and RAM from 4 MB up. **Not tested:** real hardware, the Android steps, and a real Bluetooth adapter. HTTPS (TLS), Wi-Fi, xHCI USB and native USB keyboards/mice are not built yet.
