# What Chakra can be used for

Chakra 0.1.0 is a small, real operating system. It is not a replacement for Windows, Linux or Android, and it is honest to say so up front. Its value is that it is **yours, small enough to read in one sitting, and it really boots**. This page covers what it is good for, what you can do with it yourself, and what it cannot do.

## What it is good for

### 1. Learning how an operating system works

Every part of a real OS is here in miniature, and each part fits in one short file:

| You want to understand | Read this file |
|---|---|
| What happens when a computer powers on | `boot/stage1.asm`, `boot/stage2.asm` |
| Real mode, protected mode, the GDT and A20 | `boot/stage2.asm` |
| Reading files from a FAT12 disk | `boot/stage2.asm`, `kernel/fat12.c` |
| How a kernel starts and runs C code | `kernel/entry.asm`, `kernel/kmain.c` |
| How the screen really works (video memory) | `kernel/vga.c` |
| How keys reach a program (keyboard controller) | `kernel/kbd.c` |
| Interrupts, the timer and CPU exceptions | `kernel/idt.c` |
| Memory: pages, paging and a heap | `kernel/mm.c` |
| Drawing a desktop with windows and a mouse | `kernel/gfx.c`, `kernel/gui.c`, `kernel/mouse.c` |
| How a network stack works | `kernel/net.c`, `kernel/rtl8139.c`, `kernel/http.c` |
| How USB devices are discovered | `kernel/uhci.c` |
| Tasks and context switching | `kernel/sched.c`, `kernel/entry.asm` |
| Talking to a disk and reading FAT12 | `kernel/ata.c`, `kernel/fat12.c` |
| How `printf` is built with no library | `kernel/lib.c` |
| How a command shell parses a line | `kernel/shell.c` |

You can change any line, rebuild in seconds, and see the result. That makes it a safe place to make mistakes.

### 2. Teaching and demonstrations

- Show a class or a group what "booting" means by starting an emulator and watching Chakra come up.
- Use the red panic screen on purpose (a divide-by-zero in a test command) to explain CPU exceptions.
- Use it as a lab: "add a command that does X" is a good 20-minute exercise.

### 3. A foundation for your own bigger OS

Chakra already has a two-stage loader, interrupts, a memory manager, multitasking, a disk file system, a shell and a text UI. The [roadmap](extending.html) lists what to add next: an ELF program loader, user mode, subdirectories, networking, graphics. Each step builds on what exists.

### 4. Low-level experiments

Because nothing sits between your code and the hardware, Chakra is a good test bench for:

- reading hardware ports (the real-time clock, PIT timer, keyboard controller, serial port)
- writing to video memory directly
- measuring how fast loops and system pieces run (using the timer ticks)
- trying assembly and C inline assembly

### 5. A showcase project

A from-scratch OS with its own bootloader, memory manager, scheduler and file system is a strong portfolio piece. The docs site in `docs/site/` is ready to show beside it.

## What it can do today

| Area | Today |
|---|---|
| Boot | Two-stage boot from a FAT12 disk: hard disk, floppy image or USB stick (BIOS mode) |
| Display | A **graphical desktop** with windows, a taskbar and a mouse; or 80x25 text mode with a status bar |
| Apps | Terminal, Files (file manager), Disks (disk manager), Editor, Browser, Monitor |
| Input | Keyboard on interrupts with arrow keys, PS/2 mouse, or characters over a serial port |
| Command line | Editing, history, tab completion, redirection (`>` and `>>`), about 60 commands |
| Memory | Page allocator, paging with a NULL-pointer guard, a kernel heap |
| Multitasking | Preemptive tasks, background jobs, a desktop task |
| Files and disks | FAT12 on an ATA disk, read and write, survives reboot; check, repair, label, format |
| Internet | DHCP, DNS, ping, TCP, HTTP, a text web viewer (Realtek RTL8139 card; plain http only) |
| USB and Bluetooth | USB controller (UHCI) driver and device listing; a Bluetooth adapter probe |
| Basic I/O | PC speaker, I/O ports, key monitor, pager and line editor |
| Safety net | a clear "kernel panic" screen on a crash instead of a silent freeze |

## What you can use it for (ideas for you)

These fit someone who builds on an Android phone and wants real low-level skills. Pick one and go.

1. **Study project.** Work through the nanobyte tutorial pages and rebuild each idea inside Chakra, one step at a time (the [comparison](compare.html) shows what is left). Write down what you learn in `docs/src/` and rebuild the docs site: your own tutorial grows with the OS.
2. **Portfolio case study.** Take screenshots of the desktop, the Disks and Browser windows, write the problem (build an OS from scratch), the approach (two-stage FAT12 boot, memory manager, scheduler, file system, network stack, desktop), the result (boots in an emulator, runs background jobs, saves files, loads web pages), and link the docs site.
3. **Command and app lab.** Add one command or desktop app a week: a number-base converter, a to-do list stored in a file, a quiz, a clock app, a calculator window, a new background job. It is the fastest way to get good at C.
4. **Phone-only OS dev loop.** In Termux: edit code, `make TOOLCHAIN=clang`, run with `make run-serial` (or VNC for the desktop). No PC needed (see the Android guide).
5. **Network lab.** Write a tiny web server, an echo service or a chat client on top of the TCP code in `kernel/net.c`.
6. **Hardware lab.** Add the xHCI driver, a second network card, or USB keyboard support, using the PCI and UHCI code as templates.
7. **Next milestone: HTTPS.** Add TLS so the browser can open modern sites.
8. **Next milestone: an ELF loader.** Make Chakra run separate programs from the FAT12 disk, using the nanobyte loader as your guide.
9. **Bigger goal: user mode and system calls.** Give programs their own privilege level and address space, so one bad program cannot crash the kernel.
10. **Security learning.** Packet handling, file parsers and drivers are good places to study how bugs become vulnerabilities, and your own OS is a safe place to learn why protections such as paging and user mode exist.
11. **Teach others.** Run a workshop at your school or community: boot Chakra, break it on purpose, fix it.

## What it cannot do (yet)

- It is not a daily-use computer: it has a handful of built-in apps and a basic text browser, not a modern web browser or office software.
- It cannot run Linux or Windows programs, or even separate Chakra programs yet (everything is built into the kernel).
- Bluetooth is only a probe of a USB adapter: no scanning, pairing or data yet.
- After a USB boot it cannot save files (the disk driver only sees IDE-style disks).
- It cannot boot directly on an ARM phone, because it is x86. On a phone it runs in an emulator.
- It does not support UEFI-only PCs, HTTPS, Wi-Fi, USB keyboards/mice/sticks, sound, subdirectories or multiple users.
- Its tasks run inside the kernel (no user mode yet), so a buggy task can crash the system.
- It has not been hardened for security, so do not store anything private in it.

Each item is a possible future project, and the roadmap shows a sensible order.
