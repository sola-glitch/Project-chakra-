# Build Chakra

You do not have to build anything to try Chakra: `dist/chakra.img` is already built. Build it yourself when you want to change the code.

## What you need

| Tool | Why |
|---|---|
| `nasm` | assembles the boot sector and entry stubs |
| `gcc` with 32-bit support, **or** `clang` + `lld` | compiles the C kernel |
| `ld` and `objcopy` (binutils) with GCC, or `llvm-objcopy` with Clang | links and flattens the kernel |
| `make` | runs the build |
| `python3` | builds the FAT12 disk image (`tools/mkimage.py`, no extra packages needed) |
| `qemu-system-i386` | optional, to run it |

## Linux (Debian / Ubuntu)

```
sudo apt update
sudo apt install build-essential gcc-multilib nasm make python3 qemu-system-x86
make
```

If `gcc -m32` complains about missing headers you do not need them (Chakra is freestanding), but `gcc-multilib` makes 32-bit linking work reliably. If you prefer Clang:

```
sudo apt install clang lld llvm nasm make python3 qemu-system-x86
make TOOLCHAIN=clang
```

## Windows

Use WSL (Windows Subsystem for Linux) with Ubuntu, then follow the Linux steps. To run the image you can use QEMU for Windows from the official site, pointing it at the `build/chakra.img` file inside WSL (`\\wsl$\Ubuntu\home\...`).

## macOS

```
brew install nasm qemu make llvm lld python
make TOOLCHAIN=clang
```

(Homebrew's LLVM is not on your PATH by default; `brew info llvm` shows the line to add.) The default GCC on macOS is really Apple Clang for 64-bit, so use the `TOOLCHAIN=clang` path.

## Android (Termux)

Termux's compiler targets ARM, so use the Clang cross-target path:

```
pkg install clang lld llvm nasm make python
make TOOLCHAIN=clang
```

This path is verified on desktop Linux. Termux package details can differ; if it fails, use the prebuilt `dist/chakra.img`.

## Build commands

| Command | Result |
|---|---|
| `make` | Builds `build/chakra.img` |
| `make run` | Builds and starts QEMU with a window and a network card (files you save are written into `build/chakra.img`) |
| `make run-fresh` | Same, but on a throw-away copy, so the built image stays untouched |
| `make run-floppy` | Same, but the image is attached as a floppy (tests the CHS loader) |
| `make run-serial` | Builds and runs in the terminal, no window |
| `make clean` | Deletes `build/` |

## What the build does

1. Assembles stage 1 and stage 2 (`boot/*.asm`) to flat binaries.
2. Assembles `kernel/entry.asm` and compiles each `kernel/*.c` file with freestanding flags (no standard library, no stack protector, no SSE).
3. Links everything at address `0x10000` using `kernel/linker.ld` and flattens it to `kernel.bin`.
4. Runs `tools/mkimage.py`, which builds a 1.44 MB **FAT12 disk image**: stage 1 in sector 0, stage 2 in sectors 1 to 8, then `KERNEL.BIN` plus every file in `files/` on the volume.

The network card option lives in the Makefile variable `NET` (default `-nic user,model=rtl8139`); override it with `make run NET=""` to run without networking, or add `-usb -device usb-mouse` to try USB.

To put your own file on the disk image, drop it into `files/` (8.3 name, for example `NOTES.TXT`) and run `make`.
