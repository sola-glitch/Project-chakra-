# Run Chakra on an Android phone

An Android phone has an ARM processor, but Chakra is written for x86. So on a phone, Chakra runs **inside an emulator**. This guide gives three ways, best first.

## Method 1: Termux + QEMU (recommended)

### Step 1: Install Termux

Install **Termux from F-Droid** (f-droid.org). The Google Play version is outdated and cannot install packages.

### Step 2: Install QEMU

Open Termux and run:

```
pkg update
pkg upgrade
pkg install qemu-system-i386
```

Answer `y` to prompts.

### Step 3: Get Chakra onto your phone

Download or copy `chakra.img` (or the whole `chakra-os.zip`) so it is in your phone's Downloads folder. In Termux:

```
termux-setup-storage
cp ~/storage/downloads/chakra.img ~/chakra.img
cp ~/chakra.img ~/chakra-original.img
```

The second copy is your clean backup: Chakra saves your files **into** `chakra.img`, so they are still there next time you start it. To start over, copy the backup back over `chakra.img`.

Allow storage access when Android asks. If you only have the zip:

```
pkg install unzip
unzip ~/storage/downloads/chakra-os.zip -d ~/
cp ~/chakra-os/dist/chakra.img ~/chakra.img
cp ~/chakra.img ~/chakra-original.img
```

### Step 4: Run it (text mode)

```
qemu-system-i386 -drive format=raw,file=chakra.img -nographic -nic user,model=rtl8139
```

Within a few seconds the banner and `chakra>` prompt appear in Termux. Type with your phone keyboard. Press Enter to run a command. The arrow keys on Termux's extra-keys row work for history and editing, and Tab completes names.

- Colours do not show in this mode and the colour bar appears as `#` characters. The graphical desktop, the status bar and the `ui` text desktop are screen-only, so use Step 5 to see them. The network commands (`dhcp`, `ping`, `get`, `web`) work in this mode.
- To exit QEMU press `Ctrl+A`, then `X`. Termux has a `Ctrl` key on its extra-keys row; tap `Ctrl`, then `A`, release, then `X`.
- Try `-m 32` to give it more memory (Chakra needs at least 4 MB). There is no hardware acceleration on Android, so the emulator is software only, which Chakra handles fine.

### Step 5 (optional): Run it with a graphical screen

QEMU can serve the screen over VNC, and a VNC app on the same phone shows it:

```
qemu-system-i386 -drive format=raw,file=chakra.img -nic user,model=rtl8139 -vnc 127.0.0.1:1
```

Install a VNC viewer app (for example bVNC or RealVNC Viewer), connect to `127.0.0.1` port `5901`, and you will see the real coloured screen, including the **graphical desktop** with windows. Use your VNC app's touch pointer as the mouse. QEMU on a phone is software-only, so the desktop is slower than on a PC: be patient with window drags, or press **T** at the boot prompt (you will need a keyboard) for the lighter text mode. Switch back to Termux to stop QEMU with `Ctrl+C`.

## Method 2: Build it on the phone

If you want to change the code on your phone, build with the Clang path:

```
pkg install clang lld llvm nasm make python
cd ~/chakra-os
make TOOLCHAIN=clang
make run-serial
```

This build path works on desktop Linux. Termux packages vary by device and version; if the build fails, tell me the first error line and use the prebuilt `dist/chakra.img` meanwhile.

## Method 3: An Android emulator app

Apps such as **Limbo PC Emulator** run QEMU with a touch interface. In the app: create a new machine, architecture `x86`, machine type `pc`, RAM 64 MB, attach `chakra.img` as **Hard Disk A** (an IDE disk, so Chakra can save files), boot from hard disk, start. This was not tested for this guide, so settings names may differ between app versions.

## Troubleshooting

| Problem | What to do |
|---|---|
| `qemu-system-i386: command not found` | Run `pkg install qemu-system-i386` again, then close and reopen Termux. |
| `chakra.img: No such file` | Run `ls ~` and `ls ~/storage/downloads` to find where the file really is, then copy it. |
| Nothing appears after starting | Wait ten seconds. Then check you used `-nographic` or `-vnc`; plain `qemu-system-i386` needs a window Termux cannot show. |
| You cannot get out | Press `Ctrl+A` then `X`. Or close the Termux session from the notification. |
| Files I saved are gone | You copied the backup over `chakra.img`, or booted a different copy. Saved files live inside the image you boot. |
| Keys type twice or oddly | Turn off your keyboard's auto-correct / predictive text, or use Termux's own extra-keys row. |
| Cannot run it directly on the phone hardware | Correct: Chakra is x86 and your phone is ARM. A native phone version would need an ARM port of the kernel (see [Extending Chakra](extending.html)). |
