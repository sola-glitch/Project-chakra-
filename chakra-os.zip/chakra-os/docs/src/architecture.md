# Architecture

This page explains what happens from power-on to the `chakra>` prompt, and what each part of the kernel does. It follows the ideas of the nanobyte OS tutorial (two boot stages, a FAT12 disk) but is written from scratch and kept small.

## The boot sequence

1. **BIOS** reads sector 0 of the boot disk to `0x7C00` and jumps to it.
2. **Stage 1** (`boot/stage1.asm`, 16-bit, 512 bytes). Its first bytes are a FAT12 header, so the whole disk is an ordinary FAT12 volume. Its only job: read disk sectors 1 to 8 (stage 2) to `0x7E00` and jump there. It reads them in CHS mode from cylinder 0, which every BIOS supports, and retries three times.
3. **Stage 2** (`boot/stage2.asm`, 16-bit, about 900 bytes of 4 KB available):
   - sets text mode and checks whether the BIOS supports LBA disk reads (falling back to CHS)
   - asks the BIOS for memory: the full **E820 map** and the total in KB (E801). Everything is saved in a **BootInfo** block at `0x500`
   - reads the FAT12 header, then the FAT and the root directory
   - searches the root directory for `KERNEL.BIN`, then follows its **FAT cluster chain**, loading each cluster to `0x10000`
   - copies the BIOS 8x16 text font to memory (the desktop uses it), waits about half a second for you to press **T**, and unless you do, picks a 32-bit **VBE graphics mode** (800x600, else 1024x768, else 640x480) and records the framebuffer address, size and pitch in BootInfo
   - enables A20, loads a flat GDT, sets the PE bit in `CR0` and jumps into 32-bit code, then to the kernel
4. **Kernel entry** (`kernel/entry.asm`): zero the `.bss`, call `kmain()`.
5. **kmain** copies BootInfo into kernel memory, then starts serial, VGA, the interrupt table, the memory manager (paging on), the scheduler, the keyboard, the file system, and the timer. Then it starts the status bar task, prints the banner and runs the shell.

## Disk layout

The image is a 1.44 MB FAT12 volume, built by `tools/mkimage.py`:

```
sector 0         stage 1 (boot sector + FAT12 header)
sectors 1-8      stage 2 (reserved sectors)
sectors 9-26     two copies of the FAT (9 sectors each)
sectors 27-40    root directory (224 entries)
sector 41 on     data: KERNEL.BIN, README.TXT, WELCOME.TXT and your files
```

Because it is a standard FAT12 volume, you can open the image with other tools, and you can replace the kernel by simply replacing the `KERNEL.BIN` file on it.

## Memory map

| Address | Contents |
|---|---|
| `0x00000500` | BootInfo from stage 2 (copied to kernel memory early, because page 0 is later unmapped) |
| `0x00002000` | Copy of the BIOS 8x16 font (copied into the kernel at start) |
| `0x00007C00` | Stage 1 (only needed during boot); stage 2 at `0x7E00` |
| `0x00010000` | Kernel image, then its `.bss` (file caches, bitmaps, history) |
| `0x00090000` | Top of the boot stack, used by the shell task |
| `0x000B8000` | VGA text buffer |
| `0x00100000` and up | Managed by the page allocator: kernel heap, task stacks, page tables, the desktop back buffer |
| high addresses (often `0xFD000000`) | The video framebuffer, mapped by the memory manager when graphics starts |

## Memory manager (`kernel/mm.c`)

- **Page allocator.** A bitmap, one bit per 4 KB page, over the usable RAM from 1 MB up (from the E820 map; up to 1 GB). `pmm_alloc` and `pmm_free` hand out and take back pages.
- **Paging.** All RAM is identity-mapped (virtual address equals physical), with **page 0 deliberately unmapped**. A NULL-pointer access therefore raises a page fault and the kernel panic screen shows `CR2 = 0`. Try `crash null`.
- **Kernel heap.** `kmalloc` and `kfree`: a first-fit free list with block splitting and merging of neighbours, in a block of up to 4 MB.

## Multitasking (`kernel/sched.c`)

Tasks are kernel threads, each with its own 8 KB stack, up to 8 at once. The timer fires 100 times a second and calls the scheduler (after acknowledging the interrupt), which picks the next ready task round-robin and swaps stacks with a small assembly routine (`switch_context`). Tasks can sleep (`task_sleep`), exit, or be killed. The **shell** is task 0, the **status bar** is task 1, and background jobs started with `bg` are tasks 2 and up. A critical-section helper (`irq_save` / `irq_restore`) protects shared data such as the heap and the disk.

## Interrupts and input

Hardware interrupts are remapped to vectors 32 to 47. IRQ0 (timer) drives scheduling and `uptime`. IRQ1 (keyboard) feeds a 64-key ring buffer, so no keystroke is lost while another task runs. A polling fallback catches keys on machines that do not deliver IRQ1. Arrow keys, Home, End and Delete are decoded from the extended scancodes. The serial port is read too, and ANSI escape sequences (what a terminal sends for arrow keys) become the same key codes, so the shell works the same over `qemu -nographic` and in Termux.

If the CPU raises an exception, Chakra shows a red **KERNEL PANIC** screen with the exception name, `EIP`, the error code and, for page faults, the faulting address.

## Disk and files

- **ATA driver** (`kernel/ata.c`): PIO mode, primary bus, master drive, 28-bit LBA. Found in QEMU and on machines with IDE or SATA in IDE-compatible mode.
- **FAT12 driver** (`kernel/fat12.c`): mounts the volume, reads files by following cluster chains, creates, overwrites, appends, renames and deletes files in the root directory, and writes the FAT (both copies) and directory straight through to disk.
- **File system front end** (`kernel/fs.c`): one API for the shell. Names are 8.3 and upper-case. If no ATA disk is found (for example when booted from USB or as a floppy), it falls back to a 16-file RAM disk.

## Console and UI

All output goes through `putc()`: to VGA rows 1 to 24 and mirrored to serial COM1. VGA **row 0 is the status bar**, owned by its own task, and it never scrolls. Output can be captured into a buffer, which is how `>` and `>>` redirection works. The `ui` command takes over the screen with boxes and menus drawn straight into video memory.

## Graphics and desktop (`kernel/gfx.c`, `kernel/gui.c`, `kernel/mouse.c`)

- **Framebuffer.** Stage 2 sets a VBE mode with a linear framebuffer. The kernel maps it, draws everything into a **back buffer** (rectangles and text using the BIOS font), then copies it to the screen. The mouse pointer is drawn on top, and moves without redrawing the whole screen.
- **Mouse.** PS/2 mouse on IRQ12, three-byte packets accumulated into movement and button state.
- **Desktop task.** A task named `desktop` runs the event loop: it reads keyboard and mouse input, routes keys to the window on top, handles clicks and window dragging, and redraws about every half second or when something changes. Windows are kept in a stacking order; each of the six apps (Terminal, Files, Disks, Editor, Browser, Monitor) supplies drawing, click and key handling.
- **Terminal.** The console code writes into an 80x28 character grid, which the Terminal window draws. The shell runs unchanged. In text mode the same code writes to VGA memory instead.
- **Browser** fetches pages in a separate task, so the desktop stays responsive while loading.

## Networking (`kernel/pci.c`, `kernel/rtl8139.c`, `kernel/net.c`, `kernel/http.c`)

PCI scanning finds the Realtek RTL8139 card; the driver uses I/O ports and a receive ring. The stack handles Ethernet, ARP (with a small cache), IPv4, ICMP echo, UDP, DHCP, DNS (A records), and a TCP client with sequence tracking, retransmission and a 96 KB receive buffer. The HTTP client resolves the host, sends an HTTP/1.0 request, follows redirects, decodes chunked replies and returns the body; an HTML-to-text converter turns pages into readable text with a list of links. The stack is polled (no network interrupts), and waiting calls sleep between polls so other tasks keep running.

## USB (`kernel/uhci.c`)

The UHCI driver resets the controller, builds the frame list and a queue head, resets and enables each port, and runs **control transfers** as chains of transfer descriptors (setup, data, status). Enumeration assigns an address, reads the device, configuration and string descriptors, and records class, IDs, name and endpoints. A Bluetooth adapter (class E0/01/01) gets an **HCI Reset** and a **Read BD_ADDR** command, with replies read from its interrupt endpoint.

## Disk manager (`kernel/diskman.c`, `kernel/fat12.c`)

Beyond reading and writing files, the FAT12 driver can describe its layout, count free clusters, **check** the volume (bad chains, cross-linked clusters, wrong sizes, lost clusters) and **repair** it, read and set the volume label, and report per-file details. The `disk`, `df`, `fsck`, `label`, `stat`, `touch` and `format` commands and the Disks and Files apps use these.

## Source layout

```
boot/stage1.asm      boot sector with FAT12 header
boot/stage2.asm      FAT12 loader, memory map, protected mode
tools/mkimage.py     builds the FAT12 disk image
files/               files copied onto the image
kernel/entry.asm     entry point, interrupt stubs, switch_context
kernel/linker.ld     places the kernel at 0x10000
kernel/chakra.h      shared types and declarations
kernel/kmain.c       startup, banner
kernel/vga.c         screen, capture, direct drawing
kernel/serial.c      COM1
kernel/kbd.c         keyboard IRQ, arrows, serial keys, getchar()
kernel/idt.c         interrupts, PIC, timer, panic screen
kernel/mm.c          page allocator, paging, heap
kernel/sched.c       tasks and scheduler
kernel/ata.c         disk driver
kernel/fat12.c       FAT12 driver
kernel/fs.c          file system front end
kernel/rtc.c         hardware clock
kernel/lib.c         string functions, printf
kernel/shell.c       shell and commands
kernel/ui.c          text-mode status bar and desktop
kernel/gfx.c         framebuffer graphics
kernel/gui.c         graphical desktop and apps
kernel/mouse.c       PS/2 mouse
kernel/pci.c         PCI scanning
kernel/rtl8139.c     network card driver
kernel/net.c         ARP, IP, ICMP, UDP, DHCP, DNS, TCP
kernel/http.c        HTTP client, HTML-to-text
kernel/netcmd.c      network shell commands
kernel/uhci.c        USB host controller, Bluetooth probe
kernel/diskman.c     disk and file manager commands
kernel/iocmd.c       beep, ports, pager, line editor
Makefile             build rules
```

## Limits to know about

- **x86 only, BIOS only.** (The desktop needs a VBE video mode; without one Chakra uses text mode.) A phone's ARM processor cannot run it directly; Android runs it through an emulator. UEFI-only PCs need a legacy/CSM mode.
- **Kernel-mode tasks only.** No user mode and no separate address spaces yet, so a bad task can crash the kernel.
- **Root directory only.** The FAT12 driver has no subdirectories, and no long file names.
- **ATA disk only.** USB sticks and SATA controllers in AHCI mode are not visible to the kernel, so files saved after a USB boot live in RAM.
- **One network card, no HTTPS.** Only the RTL8139 is supported, and web pages must be plain `http://`.
- **USB is a foundation.** Only UHCI controllers are driven, and only to list devices; Bluetooth is a probe, untested on a real adapter.
- **At least 4 MB of RAM.**
