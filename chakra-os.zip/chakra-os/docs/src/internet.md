# Internet and the web

Chakra 1.0 has a small network stack written from scratch, and a text-mode web browser.

## What is supported

| Layer | Support |
|---|---|
| Network card | **Realtek RTL8139** (the card QEMU emulates with `model=rtl8139`, and many older PCs) |
| Link and addressing | Ethernet, ARP, IPv4, **DHCP** (falls back to QEMU's 10.0.2.15 if there is no DHCP answer) |
| Tools | ICMP **ping**, UDP, **DNS** name lookup |
| Transport | **TCP** client (one stream at a time per connection, up to 4 connections) |
| Web | **HTTP/1.0** client with redirects and chunked replies, and an HTML-to-text page viewer |

**Not supported yet:** HTTPS (TLS), Wi-Fi, IPv6, other network cards (Intel e1000, Realtek 8169 and so on), servers (Chakra cannot be connected *to*), and images or scripts on web pages. Many big sites now require HTTPS, so for those Chakra will say so (for example GitHub answers "426 Upgrade Required").

## Using it

Start QEMU with a network card (the Makefile does this for you):

```
qemu-system-i386 -drive format=raw,file=work.img -nic user,model=rtl8139
```

| Command | What it does |
|---|---|
| `lspci` | List PCI devices (look for the Realtek network controller) |
| `net` | Show the network card, MAC address, IP, gateway and DNS |
| `dhcp` | Ask for an address and show the result |
| `ping <ip or name>` | Four pings |
| `nslookup <name>` | Look up an IP address, for example `nslookup github.com` |
| `get <url> [file]` | Fetch a page; show the start of it, or save it to a file |
| `web <url>` | Fetch and show a page as text (opens the Browser window on the desktop) |

Examples:

```
dhcp
ping 10.0.2.2
nslookup github.com
get http://10.0.2.2:8000/page.txt saved.txt
web http://10.0.2.2:8000/index.html
```

The address `10.0.2.2` is how a QEMU guest reaches the machine it runs on, so you can serve test pages from your own computer (`python3 -m http.server 8000`).

In QEMU's default networking, ping works to the gateway (`10.0.2.2`) but pings to the wider internet time out; that is how QEMU's NAT works, not a Chakra fault. DNS and HTTP work normally.

## What was tested

In QEMU with the RTL8139: DHCP, ARP, ping to the gateway, DNS lookup of `github.com` (got a real address), HTTP to a local web server (plain text and an HTML page, plus saving to a file), and a real request to `github.com` over the internet (it answered `426 Upgrade Required`, which proves the connection works). Not tested on real network hardware.

## Android and Termux

QEMU in Termux provides the same user-mode networking, so the same commands work there when you add `-nic user,model=rtl8139`. A phone's own Wi-Fi is not used directly; QEMU shares the phone's connection with Chakra.
