# The graphical desktop

Chakra 1.0 boots into a graphical desktop with windows and a mouse, as long as the BIOS offers a 32-bit video mode (almost every PC and every emulator does). The desktop is drawn by the kernel itself: no X11, no libraries.

## What you see

- A **taskbar** along the bottom with six apps and a clock.
- **Windows** with a title bar: drag the title bar to move a window, click the red **x** to close it, click anywhere on a window to bring it to the front.
- The colour stripe across the top and the mouse pointer.
- The **Terminal** window opens first and runs the same shell as the text mode.

Screen size is chosen at boot: 800x600 if available, otherwise 1024x768, otherwise 640x480.

## The apps

| App | What it does |
|---|---|
| **Terminal** | The `chakra>` shell in a window, with history, tab completion and every command. |
| **Files** | The file manager: list files, **Open** (in the Editor), **New**, **Copy**, **Rename**, **Delete**, with a free-space bar. Up/Down and Enter work too. `KERNEL.BIN` is protected from deletion. |
| **Disks** | The disk manager: disk size, FAT12 layout, clusters used and free, a space bar, and the buttons **Check** (look for problems), **Repair**, **Format** (erases all files, asks twice, keeps `KERNEL.BIN`) and **Refresh**. |
| **Editor** | A text editor for files up to 8 KB: type, arrows, Home/End, Backspace/Delete, **Save** or Ctrl+S. |
| **Browser** | Type an address, press Enter (or **Go**). Shows the page as text with a numbered link list; type a link number in the address box and press Enter to follow it. Up/Down scroll. |
| **Monitor** | Live tasks, uptime, clock, memory, network and screen status. |

## Keyboard and mouse

- Keys go to the window on top. In the Terminal they go to the shell.
- The mouse is a standard PS/2 mouse (also what emulators provide). USB mice work through the PC's PS/2 emulation; native USB mouse drivers are not built yet.

## Text mode

Press **T** when `Press T for text mode...` appears during boot (you have about half a second) to start the classic text mode, with the status bar and the `ui` text desktop. Chakra also falls back to text mode by itself if no video mode is available.

## Running the desktop

| Where | How |
|---|---|
| Emulator window | `make run`, or `qemu-system-i386 -drive format=raw,file=work.img -nic user,model=rtl8139`. Click inside the window to capture the mouse; `Ctrl+Alt+G` releases it. |
| Android (Termux) | Run QEMU with `-vnc 127.0.0.1:1` and open a VNC viewer app on `127.0.0.1:5901`. Software emulation is slower, so expect the desktop to feel sluggish. |
| Real PC | Boot from USB; the BIOS video mode is used. Not yet tested by the author. |
| `-nographic` | The desktop runs but is invisible; the shell still works over the serial console. |
