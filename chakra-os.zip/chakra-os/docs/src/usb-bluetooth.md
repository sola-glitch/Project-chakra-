# USB and Bluetooth

Chakra 1.0 has the **foundation** for USB and Bluetooth: a USB host controller driver, device discovery, and a first Bluetooth probe. It is a base to build on, not a finished feature.

## USB

| Part | Status |
|---|---|
| UHCI controller (USB 1.1) | Supported: reset, schedule, port reset, control transfers |
| Device enumeration | Reads each device's descriptors: ID, class, name, interfaces and endpoints, and selects its configuration |
| EHCI, OHCI, xHCI controllers | Detected and reported, **not supported yet**. Most modern PCs have xHCI (USB 3), so on those the `usb` command lists the controller but no devices |
| Hubs | Recognised, but devices behind a hub are not listed yet |
| Keyboards, mice, storage over USB | Not driven yet (keyboards and mice work through the PC's PS/2 emulation) |

Commands:

```
lspci          # find the USB controller
usb            # list controllers and the devices on the UHCI ports
```

In QEMU, add `-usb -device usb-mouse -device usb-kbd` to see devices. Tested this way: a QEMU mouse and keyboard were listed with their vendor/product IDs and names, and a storage device appeared behind a hub.

## Bluetooth

Bluetooth adapters are USB devices, which is why USB comes first. The `bt` command looks for a USB Bluetooth adapter (class E0/01/01), sends it the standard **HCI Reset** command, reads the answer from its event endpoint, then asks for its Bluetooth address.

```
bt
```

**Honest status:** this code is written to the Bluetooth HCI-over-USB specification, but it has **not been tested against a real adapter**, because the emulator available for testing has no Bluetooth device. It also needs the adapter to sit on a UHCI port. What does *not* exist yet: scanning for devices, pairing, and data links (ACL), plus audio and input profiles. Treat `bt` as a first step.

## What comes next

1. An **xHCI** driver (needed for most modern PCs).
2. A **hub** driver.
3. **HID**: native USB keyboards and mice.
4. **Mass storage**: USB sticks as disks, so files can be saved after a USB boot.
5. Bluetooth **inquiry (scan)** and connections, built on the same HCI code.
