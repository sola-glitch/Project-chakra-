# How to use Chakra, step by step

This is the hands-on walkthrough. It assumes Chakra is already running (see the run guides for your device). In graphics mode you see the desktop with a Terminal window; in text mode (press T at boot) you see the purple status bar, the banner and the `chakra>` prompt. The shell is the same in both.

## The basics

- Type a command and press **Enter**. Commands are lowercase words followed by arguments.
- **Left/Right/Home/End** move in the line. **Backspace** and **Delete** remove characters. **Up/Down** bring back earlier commands. **Tab** completes names.
- **Ctrl+C** cancels the line. **Ctrl+L** clears the screen. **Ctrl+U** clears the line.
- If you mistype, Chakra says `command not found (try 'help')`. Nothing breaks.
- A line can be up to 70 characters.
- The status bar on the top row shows version, uptime, free RAM, number of tasks, disk type and the clock. It keeps updating by itself, because it is a separate task.

## Lesson 1: Look around (2 minutes)

```
help
help files
about
mem
memmap
cpu
disk
uptime
date
time
```

`help` lists the topics. `mem` shows RAM, free pages, the heap and whether paging is on. `memmap` shows the memory map your BIOS reported. `disk` shows whether Chakra found a disk and which file system it uses.

## Lesson 2: Calculator

```
calc 2+2
calc (2+3)*7
calc 100/7
calc 100%7
calc -5*3
calc 10/0
```

`calc` does whole-number maths with `+ - * / %`, brackets and negative numbers. `100/7` gives 14 because there are no decimals. Dividing by zero gives a friendly error, not a crash.

## Lesson 3: Files that survive a reboot

```
ls
cat README.TXT
write todo.txt buy bread
append todo.txt call mum
cat todo.txt
cp todo.txt backup.txt
ren backup.txt old.txt
rm old.txt
ls
reboot
```

After the reboot run `ls` and `cat todo.txt`: the file is still there. Chakra saves files to the FAT12 disk (the image file you booted).

- File names are 8.3: up to 8 letters, a dot, up to 3 letters, any case (`todo.txt`, `NOTES.TXT`). Chakra shows them in capitals.
- If `disk` says "RAM disk" (floppy or USB boot), files are lost at reboot instead.
- A file can be as large as the free space (`df`).

## Lesson 4: Send output to a file

```
echo first entry > log.txt
mem >> log.txt
ls >> log.txt
cat log.txt
```

`>` replaces the file and `>>` adds to it. It works for any command.

## Lesson 5: Work faster at the prompt

1. Type `echo hello`, press Enter, then `echo world`, press Enter.
2. Press **Up** twice: `echo hello` comes back. Press **Down** to go forward.
3. Press **Left** a few times and type some letters: they are inserted in the middle.
4. Type `ch` and press **Tab**: it completes to `chakras`.
5. Type `cat w` and press **Tab**: it completes the file name `welcome.txt`.
6. Type `ca` and press **Tab**: it lists `calc` and `cat`.
7. `history` lists your last commands.

## Lesson 6: Background jobs (multitasking)

```
tasks
bg primes 300000
bg count
tasks
```

`bg` starts a job as its own task while you keep working. `tasks` shows each task's state, how many timer ticks it has used and its progress. Wait a few seconds, run `tasks` again, then:

```
cat primes.txt
kill 3
```

`primes.txt` holds the answer the background job computed and saved on its own. `kill` stops a task by its id; ids 0 (the shell) and 1 (the status bar) are protected.

## Lesson 7: The desktop

```
ui
```

A text-mode desktop opens with a menu on the left: **Files**, **System**, **Tasks**, **Chakras**, **About**, **Quit**.

- **Up/Down** choose a menu item. **Right** or **Enter** opens it.
- In **Files**, press Right to browse, Up/Down to pick a file, **Enter** to read it, **Left** to go back.
- **System** and **Tasks** refresh by themselves.
- **Q** or **Esc** returns to the shell.

The desktop draws straight into video memory, so you need a screen: an emulator window, a VNC viewer, or a real PC. It does not appear in a plain `-nographic` terminal.

## Lesson 8: Colours and timing

```
color lightgreen black
clear
color yellow blue
color lightmagenta black
chakras
sleep 3
uptime
```

`color` takes a text colour and an optional background (names or numbers 0 to 15; run `color` alone to see the names). `sleep` waits that many seconds (up to 60).

## Lesson 9: See a kernel panic on purpose

```
crash null
```

Chakra shows a red KERNEL PANIC screen: "Page fault ... Faulting address (CR2) = 0". That is the memory manager catching a NULL-pointer access. Reboot (or restart the emulator) to continue. Other options: `crash div0`, `crash ud`.

## Lesson 10: Add your own command (first real OS change)

1. Open `kernel/shell.c`.
2. Find the function `run()` and add this before the last `else`:

   ```c
   else if (!strcmp(c, "hello")) {
       kprintf("Hello, %s! Welcome to Chakra.\n", argc > 1 ? argv[1] : "friend");
   }
   ```
3. Add `"hello"` to the `cmds[]` list near the top (so Tab completes it) and a line to `cmd_help()`.
4. Run `make run-fresh` (or `make run-serial` with no window).
5. At the prompt type `hello Sola`.

You just modified an operating system. For more ideas see [Extending Chakra](extending.html).

## Lesson 11: The graphical desktop

Boot normally (do not press T). You get the desktop: a Terminal window and a taskbar with **Terminal, Files, Disks, Editor, Browser, Monitor**.

1. Click **Files** in the taskbar. Click a file, then **Open**: it opens in the **Editor**. Type, press **Ctrl+S** to save.
2. In **Files**, try **New** (type a name like `todo.txt` and press Enter), **Copy**, **Rename** and **Delete**.
3. Drag a window by its title bar. Click the red **x** to close it. Click a window to bring it to the front.
4. Click **Monitor** to watch tasks, memory and network status live.

See [the desktop](desktop.html) for everything each app can do.

## Lesson 12: Look after the disk

```
disk
df
fsck
label MYDISK
stat README.TXT
touch empty.txt
```

`disk` shows the layout and how full the disk is. `fsck` checks the file system; if it reports problems, `fsck fix` repairs them. In the desktop, the **Disks** app does the same with buttons: **Check**, **Repair**, **Format** (asks twice) and **Refresh**.

## Lesson 13: Read and edit files in the terminal

```
more WELCOME.TXT
edit notes.txt
```

In `edit`, type `a`, then some lines, then a single `.` on its own to stop adding; `p` lists the lines, `w` saves, `q` quits.

## Lesson 14: Go online

Run Chakra with a network card (`make run` does this; with plain QEMU add `-nic user,model=rtl8139`). Then:

```
dhcp
ping 10.0.2.2
nslookup github.com
get http://10.0.2.2:8000/hello.txt hello.txt
web http://10.0.2.2:8000/index.html
```

On your computer, `python3 -m http.server 8000` serves the current folder at `10.0.2.2:8000` from inside Chakra. In the desktop, open the **Browser**, type an address, press Enter; to follow a link, type its number and press Enter. Only `http://` addresses work: HTTPS is not built yet. See [internet and the web](internet.html).

## Lesson 15: USB and Bluetooth

Run QEMU with `-usb -device usb-mouse -device usb-kbd`, then:

```
usb
bt
```

`usb` lists the devices on the controller. `bt` looks for a Bluetooth adapter. See [USB and Bluetooth](usb-bluetooth.html).

## Lesson 16: Play with the hardware

```
beep 440 300
inb 61
keys
```

`beep` plays a tone on the PC speaker, `inb` reads an I/O port and `keys` shows the code of every key you press (Esc to stop).

## Ways to run it, and which keys to use

| Where | How you type |
|---|---|
| Emulator window | Click inside the window to use the mouse and keyboard. `Ctrl+Alt+G` frees your mouse. |
| `-nographic` / Termux | Type in the terminal; arrow keys and Tab work. The desktop, colours and `ui` do not show. Quit with `Ctrl+A` then `X`. |
| VNC viewer on Android | Type through the viewer app's keyboard and use the touch pointer as the mouse. The whole desktop shows. |
| Real PC from USB | Use the PC's keyboard. Enable "USB legacy support" in the BIOS if keys do not work. Files are not saved on USB boots. |

## Handy habits

- **Back up the image before you experiment.** Chakra writes your files into the image you boot, so keep a clean copy (`cp dist/chakra.img work.img`).
- **Rebuild after every change:** `make` (or `make run-fresh`). It only recompiles what changed.
- **Start clean if something is odd:** `make clean && make`.
- **Print to debug:** use `kprintf("value=%d\n", x);` in your code.
- **Crash screen:** a red `KERNEL PANIC` screen shows the exception name and the address (`EIP`). That is a clue, not a disaster: reboot and read the debugging tips in [Extending Chakra](extending.html).

## If something does not work

| Problem | Try this |
|---|---|
| Nothing happens when I type | Click the emulator window first, or type in the terminal for `-nographic`. |
| A command is "not found" | Check spelling with `help`. Commands are lowercase. |
| `write` says "bad name" | Use 8.3 names: letters and digits, up to 8, optional dot and up to 3 more. |
| `error: no space left` | The disk is full. Delete files (`rm`) and check `df`. |
| My files vanished | You booted from USB or a floppy (RAM disk), or from a fresh copy of the image. |
| `ui` shows nothing | You are in a text-only terminal. Use a window or VNC. |
| Strange characters appear | You are in `-nographic` mode and the colour bar shows as `#`. Normal. |
