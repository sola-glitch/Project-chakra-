# Chakra vs nanobyte OS

You asked which is better. Short answer: they are built for different jobs, and the best result is to grow Chakra with nanobyte's ideas. This comparison is based on reading the nanobyte source; I did not build or run nanobyte. The Chakra column was built and tested.

| | nanobyte OS | Chakra OS 1.0 |
|---|---|---|
| Goal | A tutorial: teach each piece of OS development step by step | A usable mini OS that boots to a shell |
| Size | About 4,900 lines of C and assembly | About 6,000 lines including tools |
| Boot | Two stages; stage 2 is written in C | Two stages, both in assembly; stage 2 is about 900 bytes |
| Disk format | Stage 2 reads FAT12, FAT16 and FAT32, with long file names and partitions (MBR) | FAT12 only, 8.3 names, whole-disk volume; stage 2 finds `KERNEL.BIN` through the FAT chain |
| Kernel format | ELF loader | Flat binary at a fixed address |
| Boot information | Boot parameters with memory regions | BootInfo with the full E820 map |
| CPU setup | GDT, IDT, PIC, a hardware abstraction layer | GDT, IDT, PIC, PIT timer, panic screen |
| Memory | Memory map only | Page allocator, paging with NULL guard, heap |
| Multitasking | No | Preemptive scheduler, background jobs |
| Disk and files | Loader reads FAT; kernel file system is an outline | ATA driver, FAT12 read/write in the kernel, survives reboot |
| What it does when it boots | Prints log lines and stops | Graphical desktop with windows and a mouse, plus a shell with about 60 commands |
| Keyboard and mouse | Not in the kernel yet | Interrupt-driven keyboard with arrow keys, PS/2 mouse |
| Networking | No | RTL8139 driver, TCP/IP, DHCP, DNS, HTTP, web viewer |
| USB | No | UHCI driver, device discovery, Bluetooth probe |
| To build it | A cross-compiled GCC, SCons, mtools and more | `nasm`, `gcc` (or `clang` + `lld`), `make`, `python3` |
| Build on a phone | Impractical | Documented (Termux with Clang), plus a prebuilt image |

## What nanobyte still does better

- It is a **step-by-step teaching resource**, with written lessons for every stage.
- Its **ELF kernel loader** and its more general boot parameters are the right model if you want to load programs, not just one kernel.
- Its loader handles **FAT12, FAT16 and FAT32, long file names and MBR partitions**, and its code is written in C and organised like a bigger project, with a hardware abstraction layer.

## What Chakra does better

- It is **usable straight away**, in an emulator or from a USB stick.
- It has **more of the operating system**: memory management, multitasking, files that persist, and a real shell.
- It is **simpler to build and to read**, which suits learning and phone-only work.

## What to take from nanobyte next

1. An **ELF loader**, so Chakra can run separate programs from the FAT12 disk.
2. **FAT subdirectories, long file names and FAT16/32**, so Chakra can use larger disks.
3. A **hardware abstraction layer** if you ever port Chakra to ARM or UEFI.
