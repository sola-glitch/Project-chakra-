# Extending Chakra

## Add a shell command (5 minutes)

Open `kernel/shell.c`. In the function `run()`, add a branch before the final `else`:

```c
else if (!strcmp(c, "hello")) {
    kprintf("Hello, %s!\n", argc > 1 ? argv[1] : "world");
}
```

Add `"hello"` to the `cmds[]` list near the top (so Tab completes it) and a line to `cmd_help()`, then run `make run-fresh`. `kprintf` understands `%s %c %d %u %x`, widths like `%02d` and left-aligned `%-12s`.

## Add a background job

Write a function `void job_hello(void *arg)` that loops, calls `task_sleep(1000)` and `task_set_progress(n)`, and start it from a command with `task_create("hello", job_hello, NULL)`. See `job_count` and `job_primes` in `kernel/shell.c`. A task ends when its function returns.

## Add a source file

Drop a new `.c` file into `kernel/`. The Makefile picks up every `kernel/*.c` automatically. Declare shared functions in `kernel/chakra.h`.

## Put your own files on the disk image

Drop them into `files/` (8.3 names) and run `make`. They appear in `ls` at the next boot.

## Debugging

- Use `make run-serial` and `kprintf` to print values.
- Exceptions show a red panic screen with the exception name and `EIP`. Find the source line with `objdump -d -M intel build/kernel.elf` and search for that address.
- QEMU can log faults: `qemu-system-i386 -drive format=raw,file=build/scratch.img -d int,cpu_reset -D qemu.log -no-reboot`.
- GDB: start QEMU with `-s -S`, then `gdb build/kernel.elf` and `target remote :1234`.
- `crash null`, `crash div0` and `crash ud` show you the panic screen on purpose.

## What is done, and what is next

Done in 1.0: two-stage FAT12 boot, a memory manager with paging and a heap, preemptive multitasking, an ATA + FAT12 file system with a disk manager, a graphical desktop with a mouse, a network stack with HTTP and a web viewer, a USB foundation with a Bluetooth probe, and many commands.

Sensible next steps, roughly in order:

1. **HTTPS.** A TLS client (hash functions, AES, key exchange) so Chakra can open the modern web.
2. **ELF program loader.** Load separate programs from the FAT12 disk and run them (nanobyte's `elf.c` is the model). Today every command and app is built into the kernel.
3. **User mode and system calls.** Run programs at ring 3 with their own page tables and an `int 0x80` interface, so a bad program cannot crash the kernel.
4. **More drivers.** xHCI (USB 3), a USB hub driver and HID keyboards/mice, USB mass storage (to save files after a USB boot), AHCI/SATA, more network cards (e1000, Realtek 8169), Wi-Fi.
5. **Bluetooth.** Device scanning, connections, then keyboard/mouse profiles on top of the HCI code in `kernel/uhci.c`.
6. **FAT upgrades.** Subdirectories, long file names, FAT16/32 for bigger disks, and an MBR partition parser.
7. **Desktop.** Window resizing and minimising, a launcher, icons, images and a real browser engine.
8. **Other platforms.** Chakra is x86 + BIOS. A phone version means writing an ARM kernel (new boot code, interrupt controller, drivers); the shell, FAT12, network stack and library code can be reused. A UEFI x86-64 version is the path for modern PCs without legacy boot.

## How the nanobyte project fits in

Nanobyte is the best reference for items 1 and 3: it has an ELF loader, FAT12/16/32 with long file names, and an MBR parser. See [Chakra vs nanobyte](compare.html).
