# Run Chakra on a PC emulator

An emulator is the safest way to run Chakra: nothing on your computer can be damaged, and you can restart in a second. This guide uses QEMU, with notes for VirtualBox and VMware.

## Option 1: QEMU (recommended)

### Install QEMU

| System | Command |
|---|---|
| Ubuntu / Debian | `sudo apt install qemu-system-x86` |
| Fedora | `sudo dnf install qemu-system-x86` |
| macOS | `brew install qemu` |
| Windows | Download the installer from qemu.org, then add its folder to your PATH, or run the commands below from inside that folder |

### Start Chakra with a window

Chakra saves your files into the image, so work on a copy and keep the original safe. From the Chakra folder:

```
cp dist/chakra.img work.img
qemu-system-i386 -drive format=raw,file=work.img -nic user,model=rtl8139
```

A window opens and shows `Press T for text mode...` for half a second, then the **graphical desktop**: a Terminal window with the `chakra>` prompt and a taskbar. Click inside the window and use the keyboard and mouse. Press **T** during that half second to start the classic text mode instead. To release your mouse/keyboard from the window press `Ctrl+Alt+G`.

### Start Chakra in your terminal (no window)

```
qemu-system-i386 -drive format=raw,file=work.img -nographic
```

Chakra prints to the serial port as well as the screen, so the shell appears in your terminal and you type there. Arrow keys, history and tab completion work. To quit QEMU press `Ctrl+A` then `X`. Colours do not show in this mode, the colour bar appears as `#` characters, and the status bar and the `ui` desktop are screen-only.

### Useful options

| Option | Meaning |
|---|---|
| `-m 64` | Give the machine 64 MB of RAM (Chakra needs at least 4 MB; try different sizes, then run `mem`) |
| `-fda work.img` | Boot the image as a floppy disk. Works, but there is no ATA disk, so files live in RAM |
| `-serial stdio` | Keep the window and also connect the shell to your terminal |
| `-nic user,model=rtl8139` | Give Chakra a network card (the only model it supports). Without it, network commands report "no network card" |
| `-usb -device usb-mouse -device usb-kbd` | Add USB devices so the `usb` command has something to list |
| `-vnc 127.0.0.1:1` | Show the desktop over VNC instead of a window |
| `-d int,cpu_reset -D qemu.log` | Log CPU resets and interrupts when debugging a crash |

### Shortcut with make

`make run`, `make run-fresh` (throw-away copy), `make run-floppy` and `make run-serial` cover the common cases and rebuild first if the code changed.

## Option 2: VirtualBox

VirtualBox wants a disk format it knows, so convert a copy of the raw image:

```
VBoxManage convertfromraw dist/chakra.img chakra.vdi --format VDI
```

Then in VirtualBox: New, name `Chakra`, Type `Other`, Version `Other/Unknown`, 64 MB RAM, **Do not add a virtual hard disk**. Open Settings, System, and turn **Enable EFI off** (Chakra needs BIOS). Open Storage and add the disk `chakra.vdi` to the **IDE controller** (not SATA). Chakra's disk driver only sees IDE disks; on a SATA controller it still boots, but files are kept in RAM only. Start the machine. VirtualBox has no RTL8139 network card option, so networking will not work there; the desktop, files and disk tools do.

## Option 3: VMware

Convert the image with `qemu-img convert -f raw -O vmdk dist/chakra.img chakra.vmdk`. Create a new virtual machine with "I will install the operating system later", guest OS "Other", firmware **BIOS**, and use the existing `chakra.vmdk` as its disk, attached as an **IDE** disk (not SCSI or SATA) so Chakra can save files. VMware has no RTL8139 card either, so use QEMU when you want the network features.

## What you should see

```
Chakra stage 2
Loading KERNEL.BIN...
Starting kernel
```

then the desktop. In the Terminal window you see the pink CHAKRA banner, a bar of seven colours, three green `[ok]` lines (memory, disk, multitasking) and `chakra>`. Try:

```
help
calc (2+3)*7
write notes.txt hello from chakra
cat notes.txt
dhcp
web http://10.0.2.2:8000/
```

## Troubleshooting

| Problem | What to do |
|---|---|
| `Chakra: cannot read stage 2` or `Disk read error` | The image is truncated or was copied in text mode. Rebuild with `make clean && make`, or re-copy `chakra.img` in binary mode. |
| `KERNEL.BIN not found` | The kernel file is missing from the image. Rebuild with `make`. |
| Network commands say "no network card" | Start QEMU with `-nic user,model=rtl8139`. |
| Black screen, nothing happens | In VirtualBox/VMware make sure EFI is **off**. In QEMU make sure you used `-drive format=raw,file=...`. |
| Typing does nothing in the window | Click the window first. In `-nographic` mode type in the terminal, not a window. |
| Shell says "RAM disk" instead of "FAT12" | The disk is not on an IDE controller (or you used `-fda`). Attach it as an IDE hard disk. |
| My saved files are gone | You started from a fresh copy of the image. Files are saved inside the image file you booted. |
| Red `KERNEL PANIC` screen | A CPU exception. Note the exception name and `EIP`, then see the debugging notes in [Extending Chakra](extending.html). |
