#!/usr/bin/env python3
"""Builds the Chakra docs site (docs/site/*.html) and GUIDE.md from docs/src/*.md.
No dependencies. Run:  python3 docs/build_docs.py
"""
import html, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
SRC, OUT = os.path.join(HERE, "src"), os.path.join(HERE, "site")
PAGES = [("index", "Overview"), ("uses", "What it is for"), ("using-chakra", "How to use it"), ("desktop", "Desktop"), ("internet", "Internet and web"), ("usb-bluetooth", "USB and Bluetooth"), ("architecture", "Architecture"), ("build", "Build Chakra"),
         ("run-pc-emulator", "Run: PC emulator"), ("run-usb", "Run: real PC (USB)"),
         ("run-android", "Run: Android"), ("shell", "Shell commands"), ("compare", "Chakra vs nanobyte"), ("extending", "Extending")]
CHAKRA = ["#e5484d", "#f0803c", "#f5d90a", "#46c26b", "#3cc8e8", "#5b6cff", "#c06cff"]

def inline(t):
    t = html.escape(t, quote=False)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', t)
    return t

def md(text):
    out, lines, i = [], text.split("\n"), 0
    while i < len(lines):
        l = lines[i]
        if l.startswith("```"):
            i += 1; code = []
            while i < len(lines) and not lines[i].startswith("```"):
                code.append(lines[i]); i += 1
            out.append('<pre><code>%s</code></pre>' % html.escape("\n".join(code)))
        elif re.match(r"#{1,3} ", l):
            n = len(l.split(" ")[0]); out.append("<h%d>%s</h%d>" % (n, inline(l[n + 1:]), n))
        elif l.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")]); i += 1
            i -= 1
            h = "".join("<th>%s</th>" % inline(c) for c in rows[0])
            b = "".join("<tr>%s</tr>" % "".join("<td>%s</td>" % inline(c) for c in r) for r in rows[2:])
            out.append('<div class="tw"><table><tr>%s</tr>%s</table></div>' % (h, b))
        elif l.startswith(">"):
            q = []
            while i < len(lines) and lines[i].startswith(">"):
                q.append(lines[i][1:].strip()); i += 1
            i -= 1
            out.append("<blockquote>%s</blockquote>" % "<br>".join(inline(x) for x in q if x))
        elif re.match(r"\s*(- |\d+\. )", l):
            ordered = bool(re.match(r"\s*\d+\. ", l)); items = []
            while i < len(lines) and (re.match(r"\s*(- |\d+\. )", lines[i]) or (lines[i].startswith("   ") and items)):
                if re.match(r"\s*(- |\d+\. )", lines[i]):
                    items.append([re.sub(r"^\s*(- |\d+\. )", "", lines[i])])
                else:
                    items[-1].append(lines[i])
                i += 1
            i -= 1
            li = []
            for it in items:
                body, extra, j = inline(it[0]), "", 1
                while j < len(it):
                    if it[j].strip().startswith("```"):
                        j += 1; c = []
                        while j < len(it) and not it[j].strip().startswith("```"):
                            c.append(it[j][3:] if it[j].startswith("   ") else it[j]); j += 1
                        extra += "<pre><code>%s</code></pre>" % html.escape("\n".join(c))
                    elif it[j].strip():
                        body += " " + inline(it[j].strip())
                    j += 1
                li.append("<li>%s%s</li>" % (body, extra))
            tag = "ol" if ordered else "ul"
            out.append("<%s>%s</%s>" % (tag, "".join(li), tag))
        elif l.strip():
            para = [l]
            while i + 1 < len(lines) and lines[i + 1].strip() and not re.match(r"(#|```|\||>|\s*(- |\d+\. ))", lines[i + 1]):
                i += 1; para.append(lines[i])
            out.append("<p>%s</p>" % inline(" ".join(para)))
        i += 1
    return "\n".join(out)

CSS = """
:root{--bg:#0e0b16;--fg:#e9e6f2;--mut:#9a93b3;--card:#171325;--line:#2a2340;--acc:#c06cff}
@media(prefers-color-scheme:light){:root{--bg:#faf8ff;--fg:#1c1730;--mut:#625b7c;--card:#fff;--line:#e3dcf3;--acc:#8a3fd1}}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--fg);font:16px/1.65 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
.bar{height:5px;background:linear-gradient(90deg,@@BAR@@)}
header{padding:14px 18px;display:flex;align-items:center;gap:12px;border-bottom:1px solid var(--line)}
header b{font-size:18px;letter-spacing:.5px}header span{color:var(--mut);font-size:13px}
.wrap{display:flex;max-width:1050px;margin:0 auto}
nav{width:220px;flex:none;padding:18px 14px;border-right:1px solid var(--line)}
nav a{display:block;padding:7px 10px;border-radius:8px;color:var(--mut);text-decoration:none;font-size:14.5px}
nav a:hover{color:var(--fg)}nav a.on{background:var(--card);color:var(--acc);font-weight:600}
main{flex:1;min-width:0;padding:22px 26px 60px}
h1{font-size:30px;margin:.2em 0 .5em}h2{margin-top:1.8em;font-size:22px;border-bottom:1px solid var(--line);padding-bottom:.25em}h3{margin-top:1.4em}
a{color:var(--acc)}code{background:var(--card);border:1px solid var(--line);padding:1px 6px;border-radius:5px;font:13.5px ui-monospace,Menlo,Consolas,monospace}
pre{position:relative;background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px;overflow-x:auto}
pre code{background:none;border:0;padding:0;white-space:pre}
.cp{position:absolute;top:6px;right:6px;font-size:12px;background:var(--bg);color:var(--mut);border:1px solid var(--line);border-radius:6px;padding:2px 8px}
blockquote{margin:1em 0;padding:10px 16px;border-left:4px solid var(--acc);background:var(--card);border-radius:0 10px 10px 0}
.tw{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:14.5px}
th,td{border:1px solid var(--line);padding:7px 10px;text-align:left;vertical-align:top}th{background:var(--card)}
@media(max-width:760px){.wrap{display:block}nav{width:auto;border-right:0;border-bottom:1px solid var(--line);display:flex;overflow-x:auto;gap:4px;padding:8px}
nav a{white-space:nowrap}main{padding:16px 14px 50px}h1{font-size:25px}}
""".replace("@@BAR@@", ",".join(CHAKRA))

JS = """document.querySelectorAll('pre').forEach(function(p){var b=document.createElement('button');b.className='cp';b.textContent='Copy';
b.onclick=function(){navigator.clipboard&&navigator.clipboard.writeText(p.innerText.replace(/^Copy\\n?/,'')).then(function(){b.textContent='Copied';setTimeout(function(){b.textContent='Copy'},1200)})};p.appendChild(b)});"""

def build():
    os.makedirs(OUT, exist_ok=True)
    for slug, title in PAGES:
        body = md(open(os.path.join(SRC, slug + ".md"), encoding="utf-8").read())
        nav = "".join('<a href="%s.html"%s>%s</a>' % (s, ' class="on"' if s == slug else "", t) for s, t in PAGES)
        page = ('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                '<title>%s - Chakra OS docs</title><style>%s</style></head><body><div class="bar"></div>'
                '<header><b>CHAKRA OS</b><span>documentation</span></header><div class="wrap"><nav>%s</nav><main>%s</main></div>'
                '<script>%s</script></body></html>') % (html.escape(title), CSS, nav, body, JS)
        open(os.path.join(OUT, slug + ".html"), "w", encoding="utf-8").write(page)
    parts = ["# Chakra OS - User Guide\n\nHow to build Chakra, run it on a PC emulator, a real PC from USB and an Android phone, how to use it, what it is for, the shell commands, and how it compares with nanobyte.\n"]
    for slug in ["uses", "build", "run-pc-emulator", "run-usb", "run-android", "using-chakra", "desktop", "internet", "usb-bluetooth", "shell", "compare"]:
        in_code, fixed = False, []
        for x in open(os.path.join(SRC, slug + ".md"), encoding="utf-8").read().split("\n"):
            if x.startswith("```"):
                in_code = not in_code
            fixed.append("#" + x if (x.startswith("#") and not in_code) else x)
        parts.append("\n".join(fixed))
    guide = "\n\n---\n\n".join(parts)
    guide = re.sub(r"\]\(([a-z-]+)\.html\)", r"](docs/site/\1.html)", guide)
    open(os.path.join(HERE, "..", "GUIDE.md"), "w", encoding="utf-8").write(guide + "\n")
    print("built %d pages + GUIDE.md" % len(PAGES))

if __name__ == "__main__":
    build()
