#!/usr/bin/env python3
"""Build the Chakra disk image: a 1.44 MB FAT12 volume.
  sector 0      stage 1 (boot sector with the FAT12 BPB)
  sectors 1-8   stage 2 loader (reserved sectors)
  then          FAT x2, root directory, data area (KERNEL.BIN + your files)
usage: mkimage.py stage1.bin stage2.bin kernel.bin out.img [extra files...]
"""
import sys, os

SECTOR, RESERVED, NFATS, SPF, ROOTENTS, TOTAL = 512, 9, 2, 9, 224, 2880
ROOT_SECS = ROOTENTS * 32 // SECTOR
FAT_LBA = RESERVED
ROOT_LBA = FAT_LBA + NFATS * SPF
DATA_LBA = ROOT_LBA + ROOT_SECS
NCLUST = TOTAL - DATA_LBA
DATE = ((2026 - 1980) << 9) | (11 << 5) | 7      # fixed date: reproducible builds

def name83(path):
    base, ext = os.path.splitext(os.path.basename(path))
    base, ext = base.upper(), ext[1:].upper()
    if not base or len(base) > 8 or len(ext) > 3:
        sys.exit("bad 8.3 name: " + path)
    return (base.ljust(8) + ext.ljust(3)).encode("ascii")

def main():
    if len(sys.argv) < 5:
        sys.exit(__doc__)
    s1, s2, kern, out = sys.argv[1:5]
    extras = sys.argv[5:]
    img = bytearray(TOTAL * SECTOR)
    b1 = open(s1, "rb").read()
    assert len(b1) == 512 and b1[510:512] == b"\x55\xaa", "stage1 must be 512 bytes with 55AA"
    img[0:512] = b1
    b2 = open(s2, "rb").read()
    if len(b2) > 8 * SECTOR:
        sys.exit("stage2 too big: %d > 4096" % len(b2))
    img[SECTOR:SECTOR + len(b2)] = b2

    fat = bytearray(SPF * SECTOR)
    def setfat(n, v):
        i = n + n // 2
        if n % 2 == 0:
            fat[i] = v & 0xFF
            fat[i + 1] = (fat[i + 1] & 0xF0) | ((v >> 8) & 0x0F)
        else:
            fat[i] = (fat[i] & 0x0F) | ((v & 0x0F) << 4)
            fat[i + 1] = (v >> 4) & 0xFF
    setfat(0, 0xFF0); setfat(1, 0xFFF)

    root = bytearray(ROOTENTS * 32)
    nxt, slot = 2, 0
    for path in [kern] + extras:
        data = open(path, "rb").read()
        nm = b"KERNEL  BIN" if path == kern else name83(path)
        n = max(1, (len(data) + SECTOR - 1) // SECTOR) if data else 0
        if nxt + n > NCLUST + 2:
            sys.exit("image full")
        first = nxt if n else 0
        for k in range(n):
            c = nxt + k
            setfat(c, 0xFFF if k == n - 1 else c + 1)
            lba = DATA_LBA + c - 2
            chunk = data[k * SECTOR:(k + 1) * SECTOR]
            img[lba * SECTOR:lba * SECTOR + len(chunk)] = chunk
        nxt += n
        e = bytearray(32)
        e[0:11] = nm
        e[11] = 0x20
        e[22:24] = (0).to_bytes(2, "little")
        e[24:26] = DATE.to_bytes(2, "little")
        e[26:28] = first.to_bytes(2, "little")
        e[28:32] = len(data).to_bytes(4, "little")
        root[slot * 32:(slot + 1) * 32] = e
        slot += 1

    for f in range(NFATS):
        o = (FAT_LBA + f * SPF) * SECTOR
        img[o:o + len(fat)] = fat
    img[ROOT_LBA * SECTOR:ROOT_LBA * SECTOR + len(root)] = root
    open(out, "wb").write(img)
    print("image: %d files, %d of %d clusters used" % (slot, nxt - 2, NCLUST))

main()
