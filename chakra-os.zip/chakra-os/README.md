# Chakra OS 1.0.0

An operating system written from scratch: two-stage FAT12 bootloader, protected-mode kernel with paging, heap and preemptive multitasking, ATA + FAT12 file system with a disk manager, a graphical desktop with a mouse, a network stack (DHCP, DNS, TCP, HTTP, web viewer), a USB foundation with a Bluetooth probe, and a shell. x86, BIOS boot.

- Try it now (on a copy, because Chakra saves files into the image):
  `cp dist/chakra.img work.img && qemu-system-i386 -drive format=raw,file=work.img -nic user,model=rtl8139`
  (add `-nographic` for a terminal-only run; press T at boot for text mode)
- Build it: `make` (needs nasm, gcc or clang+lld, make, python3). See GUIDE.md.
- Run it on a PC emulator, a real PC from USB, or an Android phone: see **GUIDE.md**
- Docs website (open in any browser): `docs/site/index.html`
- Regenerate the docs and GUIDE.md after editing `docs/src/*.md`: `python3 docs/build_docs.py`

Layout: `boot/` loaders, `kernel/` kernel, apps and shell, `tools/` image builder, `files/` files put on the disk, `docs/` documentation, `dist/` prebuilt image.
