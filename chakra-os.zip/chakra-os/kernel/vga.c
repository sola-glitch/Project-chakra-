/* Console. In text mode: VGA text (0xB8000), rows 1-24 scroll, row 0 is the status bar.
   In graphics mode: the same logic writes into a 80x28 terminal grid that the desktop draws.
   Everything printed is also mirrored to the serial port (COM1). */
#include "chakra.h"

#define TROWS 28
static volatile u16 *const VGAMEM = (volatile u16 *)0xB8000;
static u16 tbuf[TROWS * 80];
static volatile u16 *cells = (volatile u16 *)0xB8000;
static int top = 1, rows = 25, gterm;
static int cx, cy = 1;
static u8 fg = LGREY, bg = BLACK;
static char *capb; static u32 capn, capm;
volatile int gui_dirty;

static u16 cell(char c) { return (u16)(u8)c | ((u16)((bg << 4) | fg) << 8); }

static void update_cursor(void)
{
    if (gterm) { gui_dirty = 1; return; }
    u16 pos = cy * 80 + cx;
    outb(0x3D4, 14); outb(0x3D5, pos >> 8);
    outb(0x3D4, 15); outb(0x3D5, pos & 0xFF);
}

static void scroll(void)
{
    for (int i = (top + 1) * 80; i < rows * 80; i++) cells[i - 80] = cells[i];
    for (int i = (rows - 1) * 80; i < rows * 80; i++) cells[i] = cell(' ');
    cy = rows - 1;
}

static void vga_putc(char c)
{
    if (c == '\n') { cx = 0; cy++; }
    else if (c == '\r') { cx = 0; }
    else if (c == '\b') {
        if (cx > 0) cx--;
        else if (cy > top) { cy--; cx = 79; }
        cells[cy * 80 + cx] = cell(' ');
    } else if (c == '\t') {
        do { cells[cy * 80 + cx] = cell(' '); cx++; } while (cx % 4 && cx < 80);
    } else {
        cells[cy * 80 + cx] = cell(c);
        cx++;
    }
    if (cx >= 80) { cx = 0; cy++; }
    if (cy >= rows) scroll();
    update_cursor();
}

void putc(char c)
{
    if (capb) { if (capn + 1 < capm) capb[capn++] = c; return; }
    vga_putc(c);
    if (c == '\n') { serial_putc('\r'); serial_putc('\n'); }
    else if (c == '\b') { serial_putc('\b'); serial_putc(' '); serial_putc('\b'); }
    else if (c == '\t') serial_putc(' ');
    else if ((u8)c >= 0x80) serial_putc('#');
    else serial_putc(c);
}

void puts(const char *s) { while (*s) putc(*s++); }

void con_left(void)
{
    if (capb) return;
    if (cx > 0) { cx--; update_cursor(); }
    serial_putc('\b');
}
void con_right(void)
{
    if (capb) return;
    if (cx < 79) { cx++; update_cursor(); }
    serial_putc(27); serial_putc('['); serial_putc('C');
}

void con_capture_start(char *buf, u32 max) { capb = buf; capn = 0; capm = max; }
u32 con_capture_end(void) { u32 n = capn; if (capb && capm) capb[n < capm ? n : capm - 1] = 0; capb = NULL; return n; }

void clear_screen(void)
{
    if (capb) return;
    for (int i = top * 80; i < rows * 80; i++) cells[i] = cell(' ');
    cx = 0; cy = top;
    update_cursor();
    serial_putc(27); serial_putc('['); serial_putc('2'); serial_putc('J');
    serial_putc(27); serial_putc('['); serial_putc('H');
}

void set_color(u8 f, u8 b) { fg = f & 15; bg = b & 15; }
u8 get_fg(void) { return fg; }
u8 get_bg(void) { return bg; }

/* direct drawing (text mode only: the text desktop and status bar) */
void vga_put(int r, int c, u8 ch, u8 attr)
{
    if (gterm || r < 0 || r >= 25 || c < 0 || c >= 80) return;
    VGAMEM[r * 80 + c] = (u16)ch | ((u16)attr << 8);
}
void vga_text(int r, int c, const char *s, u8 attr) { while (*s && c < 80) vga_put(r, c++, (u8)*s++, attr); }
void vga_fill(int r, int c, int h, int w, u8 ch, u8 attr)
{ for (int i = 0; i < h; i++) for (int j = 0; j < w; j++) vga_put(r + i, c + j, ch, attr); }
void vga_cursor_visible(int v)
{
    if (gterm) return;
    outb(0x3D4, 0x0A);
    u8 x = inb(0x3D5);
    outb(0x3D5, v ? (x & ~0x20) : (x | 0x20));
}
void vga_init(void)
{
    for (int i = 0; i < 80; i++) VGAMEM[i] = ((u16)0x5F << 8) | ' ';
    clear_screen();
}

/* graphics mode: switch the console onto the terminal grid */
void con_use_terminal(void)
{
    gterm = 1; cells = tbuf; top = 0; rows = TROWS;
    for (int i = 0; i < TROWS * 80; i++) tbuf[i] = (u16)' ' | (0x07 << 8);
    cx = cy = 0;
    gui_dirty = 1;
}
void term_state(u16 **c, int *x, int *y, int *r) { *c = tbuf; *x = cx; *y = cy; *r = TROWS; }
