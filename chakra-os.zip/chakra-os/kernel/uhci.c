/* USB foundation: UHCI host controller driver, device enumeration, control transfers,
   and a Bluetooth HCI probe (class E0/01/01 adapters). Real PCs mostly have xHCI, which is
   detected but not supported yet. */
#include "chakra.h"

struct td { u32 link, status, token, buf; } __attribute__((aligned(16)));
struct qh { u32 link, elem; } __attribute__((aligned(16)));

#define MAXDEV 4
struct usbdev {
    int used, port, addr, ls;
    u8 maxpkt, cls, sub, proto, icls, isub, iproto, ep_int, ep_bulk_in, ep_bulk_out;
    u16 vid, pid, ep_int_max;
    char name[40];
    int tog_int;
};
static struct usbdev devs[MAXDEV];
static int ndev, inited, have_uhci;
static u16 io;
static u32 *fl;
static struct qh *qh;
static u8 *pg;                    /* one page: TDs, setup packet, data buffer */
#define TDS ((struct td *)pg)     /* 32 TDs at the start */
#define SETUP (pg + 1024)
#define DATA (pg + 1536)          /* 512 bytes */

static void ms(u32 n) { sleep_ms(n); }

static int uhci_init(void)
{
    if (inited) return have_uhci ? 0 : -1;
    inited = 1;
    struct pci_dev *d = pci_find_class(0x0C, 0x03, 0);
    for (int n = 0; d && d->prog != 0x00; d = pci_find_class(0x0C, 0x03, ++n)) ;
    if (!d) return -1;
    pci_enable(d);
    io = d->bar[4] & 0xFFE0;
    pci_write32(d, 0xC0, 0x8F00);                       /* turn off BIOS legacy emulation */
    outw(io, 4); ms(20); outw(io, 0); ms(10);           /* global reset */
    outw(io, 2); for (int t = 0; t < 100 && (inw(io) & 2); t++) ms(1);
    outw(io + 4, 0);
    pg = (u8 *)pmm_alloc();
    u32 flp = pmm_alloc();
    if (!pg || !flp) return -1;
    memset(pg, 0, 4096);
    fl = (u32 *)flp;
    qh = (struct qh *)(pg + 960);                       /* 16-byte aligned, after the 32 TDs */
    qh->link = 1; qh->elem = 1;
    for (int i = 0; i < 1024; i++) fl[i] = (u32)qh | 2;
    outl(io + 8, flp);
    outw(io + 6, 0);
    outb(io + 0x0C, 0x40);
    outw(io, 0xC1);                                      /* run, configured, 64-byte packets */
    have_uhci = 1;
    return 0;
}

/* run a chain of n TDs (already filled in) and wait for it to finish */
static int run(int n)
{
    for (int i = 0; i < n; i++) TDS[i].link = i + 1 < n ? ((u32)&TDS[i + 1] | 4) : 1;
    qh->elem = (u32)&TDS[0];
    for (int t = 0; t < 600; t++) {
        int done = 1, err = 0;
        for (int i = 0; i < n; i++) {
            if (TDS[i].status & 0x800000) done = 0;
            if (TDS[i].status & 0x760000) err = 1;
        }
        if (err) { qh->elem = 1; return -1; }
        if (done) { qh->elem = 1; return 0; }
        ms(1);
    }
    qh->elem = 1;
    return -2;
}

static u32 tok(int pid, int addr, int ep, int toggle, int len)
{ return ((u32)(len ? len - 1 : 0x7FF) << 21) | (toggle << 19) | (ep << 15) | (addr << 8) | pid; }
static u32 stat(int ls) { return 0x800000 | (3u << 27) | (ls ? (1u << 26) : 0); }

/* control transfer: in = 1 reads len bytes into out, in = 0 sends len bytes from out */
static int ctrl(int addr, int ls, int maxpkt, const u8 *setup, u8 *out, int len, int in)
{
    int n = 0;
    memcpy(SETUP, setup, 8);
    TDS[n].status = stat(ls); TDS[n].token = tok(0x2D, addr, 0, 0, 8); TDS[n].buf = (u32)SETUP; n++;
    int toggle = 1, done = 0;
    if (!in && len) memcpy(DATA, out, len);
    while (done < len && n < 28) {
        int c = len - done > maxpkt ? maxpkt : len - done;
        TDS[n].status = stat(ls); TDS[n].token = tok(in ? 0x69 : 0xE1, addr, 0, toggle, c); TDS[n].buf = (u32)DATA + done;
        n++; done += c; toggle ^= 1;
    }
    TDS[n].status = stat(ls); TDS[n].token = tok((in && len) ? 0xE1 : 0x69, addr, 0, 1, 0); TDS[n].buf = 0; n++;
    if (in && len) memset(DATA, 0, len);
    int r = run(n);
    if (r == 0 && in && len) memcpy(out, DATA, len);
    return r;
}

static int getdesc(struct usbdev *d, int addr, int type, int idx, int len, u8 *out)
{
    u8 s[8] = { 0x80, 6, idx, type, type == 3 ? 9 : 0, type == 3 ? 4 : 0, len, 0 };
    return ctrl(addr, d->ls, d->maxpkt, s, out, len, 1);
}

static void parse_cfg(struct usbdev *d, const u8 *c, int n)
{
    for (int i = 0; i + 2 <= n && c[i] >= 2; i += c[i]) {
        if (c[i + 1] == 4 && !d->icls) { d->icls = c[i + 5]; d->isub = c[i + 6]; d->iproto = c[i + 7]; }
        if (c[i + 1] == 5) {
            u8 a = c[i + 2], at = c[i + 3] & 3; u16 mp = c[i + 4] | (c[i + 5] << 8);
            if (at == 3 && (a & 0x80) && !d->ep_int) { d->ep_int = a & 15; d->ep_int_max = mp; }
            if (at == 2 && (a & 0x80) && !d->ep_bulk_in) d->ep_bulk_in = a & 15;
            if (at == 2 && !(a & 0x80) && !d->ep_bulk_out) d->ep_bulk_out = a & 15;
        }
    }
}

static int enumerate_port(int p)
{
    u16 r = io + 0x10 + 2 * p;
    if (!(inw(r) & 1) || ndev >= MAXDEV) return 0;
    outw(r, 0x200); ms(60); outw(r, 0); ms(10);
    outw(r, 0x0E);                                       /* enable port, clear change bits */
    for (int t = 0; t < 50 && !(inw(r) & 4); t++) ms(5);
    if (!(inw(r) & 4)) return 0;
    struct usbdev *d = &devs[ndev];
    memset(d, 0, sizeof *d);
    d->port = p; d->ls = (inw(r) & 0x100) != 0; d->maxpkt = 8;
    u8 b[256];
    if (getdesc(d, 0, 1, 0, 8, b)) return 0;
    d->maxpkt = b[7] ? b[7] : 8;
    d->addr = ndev + 1;
    u8 sa[8] = { 0, 5, d->addr, 0, 0, 0, 0, 0 };
    if (ctrl(0, d->ls, d->maxpkt, sa, NULL, 0, 0)) return 0;
    ms(15);
    if (getdesc(d, d->addr, 1, 0, 18, b)) return 0;
    d->cls = b[4]; d->sub = b[5]; d->proto = b[6];
    d->vid = b[8] | (b[9] << 8); d->pid = b[10] | (b[11] << 8);
    u8 ip = b[15];
    if (!getdesc(d, d->addr, 2, 0, 9, b)) {
        int total = b[2] | (b[3] << 8); if (total > 250) total = 250;
        u8 cv = b[5];
        if (!getdesc(d, d->addr, 2, 0, total, b)) parse_cfg(d, b, total);
        u8 sc[8] = { 0, 9, cv, 0, 0, 0, 0, 0 };
        ctrl(d->addr, d->ls, d->maxpkt, sc, NULL, 0, 0);
    }
    strncpy0(d->name, "", sizeof d->name);
    if (ip && !getdesc(d, d->addr, 3, ip, 64, b) && b[0] > 2) {
        int k = 0; for (int i = 2; i + 1 < b[0] && i < 64 && k < 38; i += 2) d->name[k++] = b[i] < 127 ? b[i] : '?';
        d->name[k] = 0;
    }
    d->used = 1; ndev++;
    return 1;
}

static int scan(void)
{
    if (!pci_count()) pci_scan();
    if (uhci_init()) return -1;
    ndev = 0; memset(devs, 0, sizeof devs);
    for (int p = 0; p < 2; p++) enumerate_port(p);
    return ndev;
}

int usb_count(void) { return ndev; }

static const char *classname(u8 c)
{
    switch (c) {
    case 1: return "audio"; case 3: return "keyboard/mouse (HID)"; case 7: return "printer"; case 8: return "storage";
    case 9: return "hub"; case 0xE0: return "wireless (Bluetooth)"; case 0xFF: return "vendor specific"; default: return "device";
    }
}

static u8 hcibuf[64];
static int hci_cmd(struct usbdev *d, u16 op, u8 *evt, int *elen)
{
    u8 cmd[3] = { op & 255, op >> 8, 0 };
    u8 s[8] = { 0x20, 0, 0, 0, 0, 0, 3, 0 };
    if (ctrl(d->addr, d->ls, d->maxpkt, s, cmd, 3, 0)) return -1;
    for (int tries = 0; tries < 60; tries++) {              /* wait for the event on the interrupt endpoint */
        TDS[0].status = stat(d->ls); TDS[0].token = tok(0x69, d->addr, d->ep_int, d->tog_int, d->ep_int_max > 32 ? 32 : d->ep_int_max);
        TDS[0].buf = (u32)DATA; memset(DATA, 0, 32);
        int r = run(1);
        if (r == 0) { d->tog_int ^= 1; memcpy(evt, DATA, 32); *elen = 32; return 0; }
        if (r == -1) return -2;
        ms(10);
    }
    return -3;
}

static void cmd_bt(void)
{
    if (scan() < 0) { puts("No USB host controller of the supported kind (UHCI) was found.\n"); return; }
    struct usbdev *d = NULL;
    for (int i = 0; i < ndev; i++) if (devs[i].cls == 0xE0 || devs[i].icls == 0xE0) d = &devs[i];
    if (!d) { puts("No Bluetooth adapter found on USB.\nPlug in a USB Bluetooth adapter (QEMU needs one passed through).\n"); return; }
    kprintf("Bluetooth adapter: %04x:%04x %s\n", d->vid, d->pid, d->name);
    if (!d->ep_int) { puts("The adapter has no interrupt endpoint: cannot read HCI events.\n"); return; }
    int n;
    if (hci_cmd(d, 0x0C03, hcibuf, &n)) { puts("HCI Reset: no answer from the adapter\n"); return; }
    kprintf("HCI Reset: event 0x%02x, status 0x%02x (%s)\n", hcibuf[0], hcibuf[5], hcibuf[5] == 0 ? "ok" : "error");
    if (!hci_cmd(d, 0x1009, hcibuf, &n) && hcibuf[0] == 0x0E && hcibuf[5] == 0)
        kprintf("Bluetooth address: %02x:%02x:%02x:%02x:%02x:%02x\n", hcibuf[11], hcibuf[10], hcibuf[9], hcibuf[8], hcibuf[7], hcibuf[6]);
    puts("This is the USB/HCI foundation: scanning, pairing and data links are not built yet.\n");
}

int usb_command(int argc, char **argv)
{
    (void)argc;
    if (!strcmp(argv[0], "bt") || !strcmp(argv[0], "bluetooth")) { cmd_bt(); return 1; }
    if (strcmp(argv[0], "usb")) return 0;
    if (!pci_count()) pci_scan();
    int found = 0;
    static const char *kind[4] = { "UHCI", "OHCI", "EHCI", "xHCI" };
    for (int i = 0; i < pci_count(); i++) {
        struct pci_dev *p = pci_get(i);
        if (p->class == 0x0C && p->sub == 0x03) {
            int k = p->prog == 0 ? 0 : p->prog == 0x10 ? 1 : p->prog == 0x20 ? 2 : 3;
            kprintf("USB controller: %s (%04x:%04x) %s\n", kind[k], p->vendor, p->device, k == 0 ? "supported" : "detected, not supported yet");
            found++;
        }
    }
    if (!found) { puts("No USB controller found.\n"); return 1; }
    int n = scan();
    if (n < 0) { puts("No UHCI controller: devices behind it cannot be listed.\n"); return 1; }
    kprintf("%d USB device(s) on the UHCI ports\n", n);
    for (int i = 0; i < n; i++) {
        struct usbdev *d = &devs[i];
        kprintf("  addr %d port %d  %04x:%04x  class %02x  %s  %s\n", d->addr, d->port, d->vid, d->pid, d->cls ? d->cls : d->icls, classname(d->cls ? d->cls : d->icls), d->name);
    }
    for (int i = 0; i < n; i++) if (devs[i].cls == 9) { puts("Note: devices behind a USB hub are not listed yet (no hub driver).\n"); break; }
    return 1;
}
