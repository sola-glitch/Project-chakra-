/* Network, PCI and web shell commands. */
#include "chakra.h"

static void show_ip(const char *label, u32 ip) { char b[16]; ip_str(ip, b); kprintf("%-10s: %s\n", label, b); }

static void cmd_net(void)
{
    if (!pci_count()) pci_scan();
    kprintf("Network card: %s\n", nic_init() == 0 ? nic_name() : "none (QEMU: add -nic user,model=rtl8139)");
    if (!net.up) { puts("Not configured yet. Run 'dhcp'.\n"); return; }
    kprintf("MAC       : %02x:%02x:%02x:%02x:%02x:%02x\n", net.mac[0], net.mac[1], net.mac[2], net.mac[3], net.mac[4], net.mac[5]);
    show_ip("IP", net.ip); show_ip("Netmask", net.mask); show_ip("Gateway", net.gw); show_ip("DNS", net.dns);
}

static void cmd_lspci(void)
{
    int n = pci_scan();
    kprintf("%d PCI device(s)\n", n);
    for (int i = 0; i < n; i++) {
        struct pci_dev *d = pci_get(i);
        kprintf(" %02x:%02x.%u  %04x:%04x  %s\n", d->bus, d->dev, d->fn, d->vendor, d->device, pci_class_name(d->class, d->sub));
    }
}

static void cmd_ping(const char *host)
{
    u32 ip, rtt;
    if (net_resolve(host, &ip)) { kprintf("ping: cannot resolve %s\n", host); return; }
    char b[16]; ip_str(ip, b);
    for (int i = 0; i < 4; i++) {
        int r = net_ping(ip, 2000, &rtt);
        if (r == 0) kprintf("reply from %s: time=%u ms\n", b, rtt);
        else if (r == -1) { puts("ping: no network card\n"); return; }
        else kprintf("request to %s timed out\n", b);
        sleep_ms(300);
    }
}

static void cmd_get(int argc, char **argv, int to_screen)
{
    if (argc < 2) { kprintf("usage: %s <http://host/path> %s\n", argv[0], to_screen ? "" : "[file]"); return; }
    char info[120], *body = NULL; u32 len = 0;
    int st = http_get(argv[1], &body, &len, info, sizeof info);
    if (st < 0) { kprintf("error: %s\n", info); return; }
    kprintf("HTTP %s\n", info);
    if (argc > 2 && !to_screen) {
        int r = fs_write(argv[2], body, len > 65000 ? 65000 : len, 0);
        if (r) puts("could not save the file (bad name or no space)\n"); else kprintf("saved to %s\n", argv[2]);
    } else if (to_screen) {
        char *txt = kmalloc(64 * 1024); char title[80];
        if (txt) {
            u32 n = html_to_text(body, len, txt, 64 * 1024, title, sizeof title);
            if (title[0]) kprintf("Title: %s\n\n", title);
            for (u32 i = 0; i < n && i < 3000; i++) putc(txt[i]);
            if (n > 3000) puts("\n[... cut off. Save the page with:  web <url> > page.txt ]\n");
            putc('\n');
            kfree(txt);
        }
    } else {
        for (u32 i = 0; i < len && i < 1500; i++) putc(body[i] == '\r' ? ' ' : body[i]);
        putc('\n');
    }
    kfree(body);
}

int net_command(int argc, char **argv)
{
    const char *c = argv[0];
    if (!strcmp(c, "net") || !strcmp(c, "ifconfig")) cmd_net();
    else if (!strcmp(c, "lspci")) cmd_lspci();
    else if (!strcmp(c, "dhcp")) {
        if (!pci_count()) pci_scan();
        if (nic_init()) { puts("no network card found (QEMU: add -nic user,model=rtl8139)\n"); return 1; }
        if (net_dhcp()) { net_static(); puts("DHCP failed; using 10.0.2.15 (QEMU defaults)\n"); } else puts("DHCP ok\n");
        cmd_net();
    }
    else if (!strcmp(c, "ping")) { if (argc < 2) puts("usage: ping <ip or name>\n"); else cmd_ping(argv[1]); }
    else if (!strcmp(c, "nslookup") || !strcmp(c, "dns")) {
        if (argc < 2) { puts("usage: nslookup <name>\n"); return 1; }
        u32 ip; int r = net_resolve(argv[1], &ip);
        if (r) kprintf("cannot resolve %s (error %d)\n", argv[1], r); else { char b[16]; ip_str(ip, b); kprintf("%s = %s\n", argv[1], b); }
    }
    else if (!strcmp(c, "get") || !strcmp(c, "wget") || !strcmp(c, "http")) cmd_get(argc, argv, 0);
    else if (!strcmp(c, "web") || !strcmp(c, "browse")) { if (gui_active() && argc > 1) { gui_open_url(argv[1]); puts("opened in the Browser window\n"); } else cmd_get(argc, argv, 1); }
    else return 0;
    return 1;
}
