/* PS/2 keyboard: IRQ1 driven, scancode set 1, with arrow keys.
   Also reads the serial port (ANSI arrow sequences) so the shell works
   identically over `qemu -nographic` / Termux. */
#include "chakra.h"

static const char lower[58] = {0,27,'1','2','3','4','5','6','7','8','9','0','-','=','\b','\t',
  'q','w','e','r','t','y','u','i','o','p','[',']','\n',0,'a','s','d','f','g','h','j','k','l',';',
  '\'','`',0,'\\','z','x','c','v','b','n','m',',','.','/',0,'*',0,' '};
static const char upper[58] = {0,27,'!','@','#','$','%','^','&','*','(',')','_','+','\b','\t',
  'Q','W','E','R','T','Y','U','I','O','P','{','}','\n',0,'A','S','D','F','G','H','J','K','L',':',
  '"','~',0,'|','Z','X','C','V','B','N','M','<','>','?',0,'*',0,' '};

static int shift, ctrl, caps, ext;
static volatile int q[64];
static volatile u32 qh, qt;

static void push(int k)
{
    u32 n = (qt + 1) & 63;
    if (n == qh) return;
    q[qt] = k; qt = n;
}

static void process(u8 sc)
{
    if (sc == 0xE0) { ext = 1; return; }
    int e = ext; ext = 0;
    if (sc & 0x80) {
        u8 k = sc & 0x7F;
        if (k == 0x1D) ctrl = 0;
        if (!e && (k == 0x2A || k == 0x36)) shift = 0;
        return;
    }
    if (e) {
        switch (sc) {
        case 0x48: push(KEY_UP); break;
        case 0x50: push(KEY_DOWN); break;
        case 0x4B: push(KEY_LEFT); break;
        case 0x4D: push(KEY_RIGHT); break;
        case 0x47: push(KEY_HOME); break;
        case 0x4F: push(KEY_END); break;
        case 0x53: push(KEY_DEL); break;
        case 0x1D: ctrl = 1; break;
        }
        return;
    }
    if (sc == 0x2A || sc == 0x36) { shift = 1; return; }
    if (sc == 0x1D) { ctrl = 1; return; }
    if (sc == 0x3A) { caps = !caps; return; }
    if (sc >= 58) return;
    char c = lower[sc];
    if (!c) return;
    int up = (c >= 'a' && c <= 'z') ? (shift ^ caps) : shift;
    if (up) c = upper[sc];
    if (ctrl && c >= 'a' && c <= 'z') { push(c - 'a' + 1); return; }
    push((u8)c);
}

void kbd_init(void)
{
    while (inb(0x64) & 1) inb(0x60);     /* drain */
}

void kbd_irq(void)
{
    u8 st = inb(0x64), d = inb(0x60);
    if (st & 0x20) mouse_byte(d); else process(d);
}

/* catches keys if IRQ1 is not delivered on some machines */
static void kbd_poll(void)
{
    u32 f = irq_save();
    while (inb(0x64) & 1) {
        u8 st = inb(0x64);
        u8 sc = inb(0x60);
        if (st & 0x20) mouse_byte(sc); else process(sc);
    }
    irq_restore(f);
}

static int sst, snum;
static int serial_key(void)
{
    for (;;) {
        int c = serial_getc_nb();
        if (c < 0) return -1;
        switch (sst) {
        case 0:
            if (c == 27) { sst = 1; continue; }
            if (c == '\r') return '\n';
            if (c == 0x7F) return '\b';
            return c;
        case 1:
            if (c == '[') { sst = 2; snum = 0; continue; }
            if (c == 'O') { sst = 3; continue; }
            sst = 0; return 27;
        case 2:
            if (c >= '0' && c <= '9') { snum = snum * 10 + (c - '0'); continue; }
            sst = 0;
            switch (c) {
            case 'A': return KEY_UP;   case 'B': return KEY_DOWN;
            case 'C': return KEY_RIGHT; case 'D': return KEY_LEFT;
            case 'H': return KEY_HOME; case 'F': return KEY_END;
            case '~': if (snum == 1 || snum == 7) return KEY_HOME;
                      if (snum == 4 || snum == 8) return KEY_END;
                      if (snum == 3) return KEY_DEL;
                      continue;
            }
            continue;
        case 3:
            sst = 0;
            if (c == 'H') return KEY_HOME;
            if (c == 'F') return KEY_END;
            continue;
        }
    }
}

int input_nb(void)
{
    kbd_poll();
    u32 f = irq_save();
    int k = -1;
    if (qh != qt) { k = q[qh]; qh = (qh + 1) & 63; }
    irq_restore(f);
    if (k >= 0) return k;
    return serial_key();
}

int getchar(void)
{
    if (gui_active()) {                  /* desktop mode: the desktop routes keys to the terminal */
        for (;;) {
            int k = gui_term_pop();
            if (k >= 0) return k;
            __asm__ volatile("hlt");
        }
    }
    for (;;) {
        int k = input_nb();
        if (k >= 0) return k;
        __asm__ volatile("hlt");
    }
}
