/* Tiny freestanding C library + formatted output. */
#include "chakra.h"

size_t strlen(const char *s) { size_t n = 0; while (s[n]) n++; return n; }
int strcmp(const char *a, const char *b)
{ while (*a && *a == *b) { a++; b++; } return (u8)*a - (u8)*b; }
int strncmp(const char *a, const char *b, size_t n)
{ while (n && *a && *a == *b) { a++; b++; n--; } return n ? (u8)*a - (u8)*b : 0; }
char *strncpy0(char *d, const char *s, size_t n)
{ size_t i = 0; while (i + 1 < n && s[i]) { d[i] = s[i]; i++; } d[i] = 0; return d; }
void *memset(void *d, int c, size_t n)
{ u8 *p = d; while (n--) *p++ = (u8)c; return d; }
void *memcpy(void *d, const void *s, size_t n)
{ u8 *a = d; const u8 *b = s; while (n--) *a++ = *b++; return d; }
void *memmove(void *d, const void *s, size_t n)
{
    u8 *a = d; const u8 *b = s;
    if (a < b) while (n--) *a++ = *b++;
    else { a += n; b += n; while (n--) *--a = *--b; }
    return d;
}
int memcmp(const void *a, const void *b, size_t n)
{ const u8 *x = a, *y = b; while (n--) { if (*x != *y) return *x - *y; x++; y++; } return 0; }

typedef void (*outfn)(char c, void *ctx);

static void num(outfn out, void *ctx, u32 v, u32 base, int width, char pad, int neg)
{
    char buf[12]; int i = 0;
    if (v == 0) buf[i++] = '0';
    while (v) { u32 d = v % base; buf[i++] = d < 10 ? '0' + d : 'a' + d - 10; v /= base; }
    int len = i + neg;
    if (pad == ' ') while (len++ < width) out(' ', ctx);
    if (neg) out('-', ctx);
    if (pad == '0') while (len++ < width) out('0', ctx);
    while (i) out(buf[--i], ctx);
}

static void vformat(outfn out, void *ctx, const char *f, __builtin_va_list ap)
{
    for (; *f; f++) {
        if (*f != '%') { out(*f, ctx); continue; }
        f++;
        char pad = ' '; int width = 0, left = 0;
        if (*f == '-') { left = 1; f++; }
        if (*f == '0') { pad = '0'; f++; }
        while (*f >= '0' && *f <= '9') width = width * 10 + (*f++ - '0');
        switch (*f) {
        case 's': {
            const char *s = __builtin_va_arg(ap, const char *);
            if (!s) s = "(null)";
            int n = (int)strlen(s);
            if (!left) while (n++ < width) out(' ', ctx);
            for (const char *q = s; *q; q++) out(*q, ctx);
            if (left) while (n++ < width) out(' ', ctx);
            break; }
        case 'c': out((char)__builtin_va_arg(ap, int), ctx); break;
        case 'd': { i32 v = __builtin_va_arg(ap, i32);
                    if (v < 0) num(out, ctx, 0u - (u32)v, 10, width, pad, 1); else num(out, ctx, v, 10, width, pad, 0); break; }
        case 'u': num(out, ctx, __builtin_va_arg(ap, u32), 10, width, pad, 0); break;
        case 'x': num(out, ctx, __builtin_va_arg(ap, u32), 16, width, pad, 0); break;
        case '%': out('%', ctx); break;
        default: out('%', ctx); if (*f) out(*f, ctx); else f--; break;
        }
    }
}

static void out_screen(char c, void *ctx) { (void)ctx; putc(c); }

void kprintf(const char *f, ...)
{
    __builtin_va_list ap;
    __builtin_va_start(ap, f);
    vformat(out_screen, NULL, f, ap);
    __builtin_va_end(ap);
}

struct sbuf { char *b; size_t max, n; };
static void out_buf(char c, void *ctx)
{
    struct sbuf *s = ctx;
    if (s->n + 1 < s->max) s->b[s->n] = c;
    s->n++;
}

int ksnprintf(char *buf, size_t max, const char *f, ...)
{
    struct sbuf s = { buf, max, 0 };
    __builtin_va_list ap;
    __builtin_va_start(ap, f);
    vformat(out_buf, &s, f, ap);
    __builtin_va_end(ap);
    if (max) buf[s.n < max ? s.n : max - 1] = 0;
    return (int)s.n;
}
