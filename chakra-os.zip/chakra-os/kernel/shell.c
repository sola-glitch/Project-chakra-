/* Chakra shell: line editor (arrows, history, tab completion), redirection,
   and the built-in commands. */
#include "chakra.h"

#define MAXARGS 16
#define LINELEN 71          /* 70 characters + NUL: keeps a line on one screen row */
#define HIST 16
#define PROMPT "chakra> "

static char hist[HIST][LINELEN];
static int hn;

static void say(u8 c, const char *s) { u8 o = get_fg(); set_color(c, get_bg()); puts(s); set_color(o, get_bg()); }

/* ====================== line editor ====================== */
static void redraw(const char *b, int ol, int op, int nl, int np)
{
    for (int i = 0; i < op; i++) con_left();
    for (int i = 0; i < nl; i++) putc(b[i]);
    for (int i = nl; i < ol; i++) putc(' ');
    int end = nl > ol ? nl : ol;
    for (int i = np; i < end; i++) con_left();
}

static void prompt(void) { say(LMAGENTA, "chakra"); say(DGREY, "> "); }

static const char *cmds[] = { "about", "bt", "usb", "beep", "df", "disk", "edit", "format", "fsck", "inb", "keys", "label", "more", "outb", "stat", "touch", "browse", "dhcp", "get", "ifconfig", "lspci", "net", "nslookup", "ping", "web", "wget", "append", "bg", "calc", "cat", "chakras", "clear", "color", "cp",
    "cpu", "crash", "date", "echo", "halt", "help", "hexdump", "history", "kill", "ls",
    "mem", "memmap", "reboot", "ren", "rm", "sleep", "tasks", "time", "ui", "uptime", "ver", "wc",
    "write", NULL };

static char lc(char c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }

/* Tab completion: command names for the first word, file names afterwards. */
static void complete(char *buf, int *plen, int *ppos)
{
    int len = *plen, pos = *ppos, ws = pos;
    while (ws > 0 && buf[ws - 1] != ' ') ws--;
    int first = 1;
    for (int i = 0; i < ws; i++) if (buf[i] != ' ') first = 0;
    int plen_w = pos - ws;
    char cand[24][FS_MAXNAME + 8]; int nc = 0;
    if (first) {
        for (int i = 0; cmds[i] && nc < 24; i++)
            if (!strncmp(cmds[i], buf + ws, plen_w)) strncpy0(cand[nc++], cmds[i], sizeof(cand[0]));
    } else {
        struct fs_entry fe[24];
        int n = fs_list(fe, 24);
        for (int i = 0; i < n; i++) {
            int ok = 1;
            for (int k = 0; k < plen_w; k++) if (lc(fe[i].name[k]) != lc(buf[ws + k])) { ok = 0; break; }
            if (ok && nc < 24) { for (int k = 0; fe[i].name[k]; k++) fe[i].name[k] = lc(fe[i].name[k]); strncpy0(cand[nc++], fe[i].name, sizeof(cand[0])); }
        }
    }
    if (!nc) return;
    int common = (int)strlen(cand[0]);
    for (int i = 1; i < nc; i++) { int k = 0; while (k < common && cand[i][k] == cand[0][k]) k++; common = k; }
    if (common > plen_w) {
        int add = common - plen_w;
        if (len + add >= LINELEN) return;
        int ol = len, op = pos;
        memmove(buf + pos + add, buf + pos, len - pos);
        memcpy(buf + pos, cand[0] + plen_w, add);
        len += add; pos += add;
        if (nc == 1 && pos == len && len + 1 < LINELEN) { buf[len++] = ' '; pos++; }
        redraw(buf, ol, op, len, pos);
        *plen = len; *ppos = pos;
    } else if (nc > 1) {
        putc('\n');
        for (int i = 0; i < nc; i++) { puts(cand[i]); putc(' '); }
        putc('\n');
        prompt();
        for (int i = 0; i < len; i++) putc(buf[i]);
        for (int i = pos; i < len; i++) con_left();
    }
}

/* returns 0 = a line is ready, 1 = cancelled */
static int readline(char *buf)
{
    int len = 0, pos = 0, hidx = hn;
    char saved[LINELEN];
    saved[0] = 0; buf[0] = 0;
    for (;;) {
        int k = getchar(), ol = len, op = pos;
        if (k == '\n') { putc('\n'); buf[len] = 0; return 0; }
        if (k == 3) { puts("^C\n"); return 1; }
        if (k == 12) { clear_screen(); prompt(); for (int i = 0; i < len; i++) putc(buf[i]); for (int i = pos; i < len; i++) con_left(); continue; }
        if (k == '\b') { if (pos > 0) { memmove(buf + pos - 1, buf + pos, len - pos); pos--; len--; redraw(buf, ol, op, len, pos); } }
        else if (k == KEY_DEL) { if (pos < len) { memmove(buf + pos, buf + pos + 1, len - pos - 1); len--; redraw(buf, ol, op, len, pos); } }
        else if (k == KEY_LEFT) { if (pos > 0) { pos--; con_left(); } }
        else if (k == KEY_RIGHT) { if (pos < len) { pos++; con_right(); } }
        else if (k == KEY_HOME || k == 1) { while (pos > 0) { pos--; con_left(); } }
        else if (k == KEY_END || k == 5) { while (pos < len) { pos++; con_right(); } }
        else if (k == 21) { len = pos = 0; redraw(buf, ol, op, 0, 0); }
        else if (k == KEY_UP || k == KEY_DOWN) {
            if (k == KEY_UP && hidx > 0) { if (hidx == hn) { memcpy(saved, buf, len); saved[len] = 0; } hidx--; }
            else if (k == KEY_DOWN && hidx < hn) hidx++;
            else continue;
            const char *src = (hidx == hn) ? saved : hist[hidx];
            len = (int)strlen(src); memcpy(buf, src, len + 1); pos = len;
            redraw(buf, ol, op, len, pos);
        }
        else if (k == '\t') complete(buf, &len, &pos);
        else if (k >= 32 && k < 127 && len < LINELEN - 1) {
            memmove(buf + pos + 1, buf + pos, len - pos);
            buf[pos++] = (char)k; len++;
            if (pos == len) putc((char)k); else redraw(buf, ol, op, len, pos);
        }
        buf[len] = 0;
    }
}

/* ====================== calc ====================== */
static const char *p; static int err;
static i32 expr(void);
static void ws(void) { while (*p == ' ') p++; }
static i32 factor(void)
{
    ws();
    if (*p == '-') { p++; return (i32)(0u - (u32)factor()); }
    if (*p == '+') { p++; return factor(); }
    if (*p == '(') { p++; i32 v = expr(); ws(); if (*p != ')') err = 1; else p++; return v; }
    if (*p >= '0' && *p <= '9') { i32 v = 0; while (*p >= '0' && *p <= '9') v = v * 10 + (*p++ - '0'); return v; }
    err = 1; return 0;
}
static i32 term(void)
{
    i32 v = factor();
    for (;;) {
        ws(); char o = *p;
        if (o == '*') { p++; v = (i32)((u32)v * (u32)factor()); }
        else if (o == '/' || o == '%') {
            p++; i32 r = factor();
            if (r == 0) { err = 2; return 0; }
            if (r == -1) v = (o == '/') ? (i32)(0u - (u32)v) : 0;
            else v = (o == '/') ? v / r : v % r;
        } else break;
    }
    return v;
}
static i32 expr(void)
{
    i32 v = term();
    for (;;) {
        ws(); char o = *p;
        if (o == '+') { p++; v = (i32)((u32)v + (u32)term()); }
        else if (o == '-') { p++; v = (i32)((u32)v - (u32)term()); }
        else break;
    }
    return v;
}

/* ====================== helpers ====================== */
static const char *cname[16] = { "black","blue","green","cyan","red","magenta","brown","lightgrey",
    "darkgrey","lightblue","lightgreen","lightcyan","lightred","lightmagenta","yellow","white" };
static int parse_color(const char *s)
{
    for (int i = 0; i < 16; i++) if (strcmp(s, cname[i]) == 0) return i;
    int v = 0;
    if (!*s) return -1;
    for (; *s; s++) { if (*s < '0' || *s > '9') return -1; v = v * 10 + (*s - '0'); }
    return v < 16 ? v : -1;
}
static u32 atou(const char *s) { u32 n = 0; while (*s >= '0' && *s <= '9') n = n * 10 + (*s++ - '0'); return n; }

static void join(char **argv, int from, int argc, char *out, int max)
{
    int n = 0;
    for (int i = from; i < argc; i++) {
        for (const char *s = argv[i]; *s && n < max - 2; s++) out[n++] = *s;
        if (i + 1 < argc && n < max - 2) out[n++] = ' ';
    }
    out[n] = 0;
}

static void fs_err(int r, const char *name)
{
    if (r == -1) kprintf("error: bad name or not found: %s (use 8.3 names like NOTES.TXT)\n", name);
    else if (r == -2) puts("error: no space left\n");
    else if (r == -3) puts("error: target already exists\n");
    else puts("error: disk problem\n");
}

/* ====================== file commands ====================== */
static void cmd_ls(void)
{
    struct fs_entry fe[32];
    int n = fs_list(fe, 32);
    for (int i = 0; i < n; i++) kprintf("  %-14s %6u bytes\n", fe[i].name, fe[i].size);
    if (!n) puts("  (no files)\n");
    kprintf("  %d file(s), %u bytes free on the %s\n", n, fs_free_bytes(), fs_on_disk() ? "disk" : "RAM disk");
}

static char *slurp(const char *name, u32 *len)
{
    u32 sz;
    if (fs_size(name, &sz)) { fs_err(-1, name); return NULL; }
    char *b = kmalloc(sz + 1);
    if (!b) { puts("error: out of memory\n"); return NULL; }
    if (fs_read(name, b, sz, len)) { kfree(b); puts("error: read failed\n"); return NULL; }
    b[*len] = 0;
    return b;
}

static void cmd_cat(const char *name)
{
    u32 n; char *b = slurp(name, &n);
    if (!b) return;
    for (u32 i = 0; i < n; i++) if (b[i] != '\r') putc(b[i]);
    if (!n || b[n - 1] != '\n') putc('\n');
    kfree(b);
}

static void cmd_write(int argc, char **argv, int append)
{
    if (argc < 2) { kprintf("usage: %s <file> <text>\n", append ? "append" : "write"); return; }
    char text[LINELEN + 2];
    join(argv, 2, argc, text, sizeof(text) - 1);
    int n = strlen(text);
    text[n++] = '\n';
    int r = fs_write(argv[1], text, n, append);
    if (r) fs_err(r, argv[1]);
}

static void cmd_cp(const char *a, const char *b)
{
    u32 n; char *buf = slurp(a, &n);
    if (!buf) return;
    int r = fs_write(b, buf, n, 0);
    if (r) fs_err(r, b);
    kfree(buf);
}

static void cmd_hexdump(const char *name)
{
    u32 n; char *b = slurp(name, &n);
    if (!b) return;
    if (n > 128) n = 128;
    for (u32 i = 0; i < n; i += 16) {
        kprintf("%04x  ", i);
        for (u32 j = 0; j < 16; j++) { if (i + j < n) kprintf("%02x ", (u8)b[i + j]); else puts("   "); }
        putc(' ');
        for (u32 j = 0; j < 16 && i + j < n; j++) { u8 c = b[i + j]; putc(c >= 32 && c < 127 ? c : '.'); }
        putc('\n');
    }
    kfree(b);
}

static void cmd_wc(const char *name)
{
    u32 n; char *b = slurp(name, &n);
    if (!b) return;
    u32 lines = 0, words = 0; int in = 0;
    for (u32 i = 0; i < n; i++) {
        if (b[i] == '\n') lines++;
        if (b[i] == ' ' || b[i] == '\n' || b[i] == '\r' || b[i] == '\t') in = 0; else if (!in) { in = 1; words++; }
    }
    kprintf("%u lines, %u words, %u bytes\n", lines, words, n);
    kfree(b);
}

/* ====================== system commands ====================== */
static void cmd_mem(void)
{
    u32 tp = pmm_total_pages(), fp = pmm_free_pages();
    kprintf("RAM top        : %u MB (BIOS total %u KB)\n", mem_top() >> 20, BOOTINFO->total_kb);
    kprintf("Page allocator : %u pages of 4 KB, %u free (%u KB free)\n", tp, fp, fp * 4);
    kprintf("Paging         : %s (page 0 unmapped, so NULL access faults)\n", paging_enabled() ? "on" : "off");
    kprintf("Kernel heap    : %u KB used of %u KB\n", heap_used() / 1024, heap_total() / 1024);
}

static void cmd_memmap(void)
{
    static const char *tn[6] = { "?", "usable", "reserved", "ACPI reclaim", "ACPI NVS", "bad" };
    u32 n = BOOTINFO->e820_count;
    if (!n) { puts("no E820 map from the BIOS\n"); return; }
    puts("  base       length     type\n");
    for (u32 i = 0; i < n && i < 20; i++) {
        struct e820_entry *e = &BOOTINFO->e820[i];
        kprintf("  %08x   %08x   %s\n", e->base_lo, e->len_lo, e->type < 6 ? tn[e->type] : "?");
    }
}

static void cmd_cpu(void)
{
    u32 a, b, c, d; char v[13];
    __asm__ volatile("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "a"(0));
    memcpy(v, &b, 4); memcpy(v + 4, &d, 4); memcpy(v + 8, &c, 4); v[12] = 0;
    kprintf("CPU vendor: %s\n", v);
}

static void cmd_chakras(void)
{
    static const u8 col[7] = { RED, BROWN, YELLOW, LGREEN, LCYAN, LBLUE, LMAGENTA };
    static const char *nm[7] = { "Root       - stability, survival", "Sacral     - creativity, flow",
        "Solar      - will, confidence", "Heart      - love, connection", "Throat     - voice, truth",
        "Third eye  - insight, vision", "Crown      - awareness, unity" };
    for (int i = 6; i >= 0; i--) { say(col[i], "  # "); puts(nm[i]); putc('\n'); }
}

static void cmd_reboot(void)
{
    puts("Rebooting...\n");
    int t = 100000; while ((inb(0x64) & 2) && --t) ;
    outb(0x64, 0xFE);
    struct { u16 l; u32 b; } __attribute__((packed)) z = { 0, 0 };
    __asm__ volatile("lidt %0; int3" ::"m"(z));
    for (;;) __asm__ volatile("hlt");
}

/* ====================== tasks / jobs ====================== */
static void job_primes(void *arg)
{
    u32 n = (u32)arg, count = 0;
    for (u32 i = 2; i <= n; i++) {
        int pr = 1;
        for (u32 d = 2; d * d <= i; d++) if (i % d == 0) { pr = 0; break; }
        if (pr) count++;
        if ((i & 0xFF) == 0) task_set_progress(i);
    }
    task_set_progress(n);
    char b[64];
    int len = ksnprintf(b, sizeof b, "primes up to %u: %u\n", n, count);
    fs_write("PRIMES.TXT", b, len, 0);
}
static void job_count(void *arg)
{
    (void)arg;
    u32 c = 0;
    for (;;) { task_sleep(1000); task_set_progress(++c); }
}

static void cmd_tasks(void)
{
    static const char *st[4] = { "free", "ready", "sleep", "dead" };
    struct task_info ti;
    puts("  ID  NAME        STATE   CPU(ticks)  PROGRESS\n");
    for (int i = 0; i < 8; i++)
        if (!task_get(i, &ti)) kprintf("  %-3d %-11s %-7s %-11u %u\n", ti.id, ti.name, st[ti.state], ti.cpu, ti.progress);
}

static void cmd_bg(int argc, char **argv)
{
    if (argc < 2) { puts("usage: bg primes <n>   |   bg count\n"); return; }
    int id;
    if (!strcmp(argv[1], "primes")) {
        u32 n = argc > 2 ? atou(argv[2]) : 100000;
        if (n < 2 || n > 5000000) { puts("n must be 2..5000000\n"); return; }
        id = task_create("primes", job_primes, (void *)n);
    } else if (!strcmp(argv[1], "count")) id = task_create("count", job_count, NULL);
    else { puts("unknown job (try: primes, count)\n"); return; }
    if (id < 0) puts("cannot start job (no free task slot or memory)\n");
    else kprintf("started job %d in the background; see 'tasks'\n", id);
}

static void cmd_crash(const char *how)
{
    volatile int z = 0;
    if (!strcmp(how, "div0")) { volatile int r = 1 / z; (void)r; }
    else if (!strcmp(how, "null")) { volatile int *q = (volatile int *)0; *q = 1; }
    else if (!strcmp(how, "ud")) __asm__ volatile("ud2");
    else puts("usage: crash div0|null|ud   (shows the kernel panic screen, then you must reboot)\n");
}

/* ====================== help ====================== */
static void cmd_help(int argc, char **argv)
{
    const char *t = argc > 1 ? argv[1] : "";
    if (!strcmp(t, "files"))
        puts("ls                 list files (name, size, free space)\n"
             "cat <f>            show a file         wc <f>   lines/words/bytes\n"
             "write <f> <text>   create or replace    append <f> <text>   add a line\n"
             "cp <a> <b>         copy                ren <a> <b>         rename\n"
             "rm <f>             delete              hexdump <f>         first 128 bytes\n"
             "df                 disk space          Names are 8.3: NOTES.TXT (any case)\n");
    else if (!strcmp(t, "system"))
        puts("mem      RAM, pages, heap, paging       memmap   BIOS memory map (E820)\n"
             "cpu      CPU vendor                     disk     disk and file system info\n"
             "uptime   time since boot                time/date hardware clock\n"
             "sleep n  wait n seconds                 color fg [bg]   change colours\n"
             "clear    clear screen                   chakras  the seven chakras\n"
             "crash div0|null|ud   trigger a kernel panic on purpose\n");
    else if (!strcmp(t, "tasks"))
        puts("tasks              list running tasks (preemptive multitasking)\n"
             "bg primes <n>      count primes up to n in the background -> PRIMES.TXT\n"
             "bg count           a background counter (watch PROGRESS in 'tasks')\n"
             "kill <id>          stop a task\n"
             "ui                 open the text-mode desktop (needs a screen)\n");
    else if (!strcmp(t, "keys"))
        puts("Left/Right/Home/End/Del   edit the line      Up/Down   command history\n"
             "Tab                       complete commands and file names\n"
             "Ctrl+A / Ctrl+E           start / end of line   Ctrl+U   clear the line\n"
             "Ctrl+C cancel            Ctrl+L clear screen\n"
             "cmd > file    send output to a file    cmd >> file    add output to a file\n");
    else {
        say(LMAGENTA, "Chakra shell");
        puts(" - type 'help <topic>' for details\n"
             "  help files    ls cat write append cp ren rm hexdump wc df\n"
             "  help system   mem memmap cpu disk uptime time date sleep color clear\n"
             "  help tasks    tasks bg kill ui\n"
             "  help keys     editing, history, tab completion, redirection\n"
             "  also: echo calc history about chakras reboot halt crash\n");
    }
}

/* ====================== dispatch ====================== */
static void run(int argc, char **argv)
{
    const char *c = argv[0];
    if (!strcmp(c, "help") || !strcmp(c, "?")) cmd_help(argc, argv);
    else if (!strcmp(c, "about") || !strcmp(c, "ver")) print_banner();
    else if (!strcmp(c, "clear") || !strcmp(c, "cls")) clear_screen();
    else if (!strcmp(c, "echo")) { char t[LINELEN + 2]; join(argv, 1, argc, t, sizeof(t)); puts(t); putc('\n'); }
    else if (!strcmp(c, "calc")) {
        char t[LINELEN + 2]; join(argv, 1, argc, t, sizeof(t));
        p = t; err = 0; i32 v = expr(); ws();
        if (*p) err = err ? err : 1;
        if (err == 2) puts("calc: division by zero\n");
        else if (err || !t[0]) puts("usage: calc <expression>  e.g. calc (2+3)*7\n");
        else kprintf("= %d\n", v);
    }
    else if (net_command(argc, argv) || disk_command(argc, argv) || io_command(argc, argv) || usb_command(argc, argv)) { }
    else if (!strcmp(c, "ls") || !strcmp(c, "dir")) cmd_ls();
    else if (!strcmp(c, "cat") || !strcmp(c, "type")) { if (argc < 2) puts("usage: cat <file>\n"); else cmd_cat(argv[1]); }
    else if (!strcmp(c, "write")) cmd_write(argc, argv, 0);
    else if (!strcmp(c, "append")) cmd_write(argc, argv, 1);
    else if (!strcmp(c, "rm") || !strcmp(c, "del")) { if (argc < 2) puts("usage: rm <file>\n"); else { int r = fs_remove(argv[1]); if (r) fs_err(r, argv[1]); } }
    else if (!strcmp(c, "ren")) { if (argc < 3) puts("usage: ren <old> <new>\n"); else { int r = fs_rename(argv[1], argv[2]); if (r) fs_err(r, argv[1]); } }
    else if (!strcmp(c, "cp") || !strcmp(c, "copy")) { if (argc < 3) puts("usage: cp <from> <to>\n"); else cmd_cp(argv[1], argv[2]); }
    else if (!strcmp(c, "hexdump")) { if (argc < 2) puts("usage: hexdump <file>\n"); else cmd_hexdump(argv[1]); }
    else if (!strcmp(c, "wc")) { if (argc < 2) puts("usage: wc <file>\n"); else cmd_wc(argv[1]); }
    else if (!strcmp(c, "mem") || !strcmp(c, "free")) cmd_mem();
    else if (!strcmp(c, "memmap")) cmd_memmap();
    else if (!strcmp(c, "cpu")) cmd_cpu();
    else if (!strcmp(c, "uptime")) { u32 s = ticks() / 100; kprintf("up %u min %u s (%u ticks)\n", s / 60, s % 60, ticks()); }
    else if (!strcmp(c, "time")) { int h, m, s, d, mo, y; rtc_read(&h, &m, &s, &d, &mo, &y); kprintf("%02d:%02d:%02d\n", h, m, s); }
    else if (!strcmp(c, "date")) { int h, m, s, d, mo, y; rtc_read(&h, &m, &s, &d, &mo, &y); kprintf("%04d-%02d-%02d\n", y, mo, d); }
    else if (!strcmp(c, "sleep")) {
        if (argc < 2) { puts("usage: sleep <seconds>\n"); return; }
        u32 n = atou(argv[1]); if (n > 60) n = 60;
        sleep_ms(n * 1000);
    }
    else if (!strcmp(c, "color")) {
        if (argc < 2) { puts("usage: color <fg> [bg]   colours: "); for (int i = 0; i < 16; i++) kprintf("%s ", cname[i]); putc('\n'); return; }
        int f = parse_color(argv[1]), b = argc > 2 ? parse_color(argv[2]) : (int)get_bg();
        if (f < 0 || b < 0) puts("color: unknown colour\n"); else set_color(f, b);
    }
    else if (!strcmp(c, "chakras")) cmd_chakras();
    else if (!strcmp(c, "tasks") || !strcmp(c, "ps")) cmd_tasks();
    else if (!strcmp(c, "bg")) cmd_bg(argc, argv);
    else if (!strcmp(c, "kill")) { if (argc < 2) puts("usage: kill <id>\n"); else if (task_kill((int)atou(argv[1]))) puts("cannot kill: no such task, or ids 0 and 1 (protected)\n"); }
    else if (!strcmp(c, "ui")) { if (gui_active()) puts("The graphical desktop is already running: use the taskbar at the bottom.\n"); else ui_run(); }
    else if (!strcmp(c, "history")) { for (int i = 0; i < hn; i++) kprintf("  %2d  %s\n", i + 1, hist[i]); }
    else if (!strcmp(c, "crash")) cmd_crash(argc > 1 ? argv[1] : "");
    else if (!strcmp(c, "reboot")) cmd_reboot();
    else if (!strcmp(c, "halt")) { puts("System halted. You can power off.\n"); for (;;) __asm__ volatile("cli; hlt"); }
    else kprintf("%s: command not found (try 'help')\n", c);
}

void shell_run(void)
{
    char line[LINELEN], *argv[MAXARGS];
    for (;;) {
        prompt();
        if (readline(line)) continue;
        if (!line[0]) continue;
        if (hn == 0 || strcmp(hist[hn - 1], line)) {
            if (hn == HIST) { memmove(hist[0], hist[1], (HIST - 1) * LINELEN); hn--; }
            strncpy0(hist[hn++], line, LINELEN);
        }
        int argc = 0; char *q = line;
        while (*q && argc < MAXARGS) {
            while (*q == ' ') *q++ = 0;
            if (!*q) break;
            argv[argc++] = q;
            while (*q && *q != ' ') q++;
        }
        if (!argc) continue;
        /* redirection:  cmd args > file   or   cmd args >> file */
        int redir = -1, app = 0;
        for (int i = 1; i < argc; i++) if (!strcmp(argv[i], ">") || !strcmp(argv[i], ">>")) { redir = i; app = argv[i][1] == '>'; break; }
        if (redir > 0 && redir + 1 < argc) {
            char *cap = kmalloc(8192);
            if (!cap) { puts("out of memory\n"); continue; }
            const char *target = argv[redir + 1];
            con_capture_start(cap, 8192);
            run(redir, argv);
            u32 n = con_capture_end();
            int r = fs_write(target, cap, n, app);
            if (r) fs_err(r, target);
            kfree(cap);
        } else if (redir > 0) puts("usage: <command> > <file>\n");
        else run(argc, argv);
    }
}
