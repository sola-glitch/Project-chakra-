/* Memory manager: physical page allocator (bitmap), paging (identity map with
   an unmapped page 0 so NULL accesses fault), and a kernel heap (kmalloc). */
#include "chakra.h"

#define PAGE 4096u
#define MAXPAGES 262144u                 /* manage up to 1 GB */
static u8 bitmap[MAXPAGES / 8];          /* 1 = used */
static u32 first_page = 0x100000 / PAGE;
static u32 end_page, free_pages, total_pages, hint;
static u32 top_addr;
static int paged;

static int used(u32 p) { return bitmap[p >> 3] & (1 << (p & 7)); }
static void mark(u32 p) { bitmap[p >> 3] |= 1 << (p & 7); }
static void unmark(u32 p) { bitmap[p >> 3] &= ~(1 << (p & 7)); }

struct bootinfo g_boot;
u8 g_font[4096];
void bootinfo_init(void) { memcpy(&g_boot, (const void *)0x500, sizeof(g_boot)); memcpy(g_font, (const void *)0x2000, 4096); }

u32 mem_top(void) { return top_addr; }
u32 pmm_total_pages(void) { return total_pages; }
u32 pmm_free_pages(void) { return free_pages; }

u32 pmm_alloc(void)
{
    u32 f = irq_save();
    for (u32 i = 0; i < end_page - first_page; i++) {
        u32 p = first_page + (hint + i) % (end_page - first_page);
        if (!used(p)) { mark(p); free_pages--; hint = p - first_page + 1; irq_restore(f); return p * PAGE; }
    }
    irq_restore(f);
    return 0;
}

u32 pmm_alloc_contig(u32 n)
{
    u32 f = irq_save(), run = 0;
    for (u32 p = first_page; p < end_page; p++) {
        run = used(p) ? 0 : run + 1;
        if (run == n) {
            u32 s = p - n + 1;
            for (u32 k = s; k <= p; k++) mark(k);
            free_pages -= n;
            irq_restore(f);
            return s * PAGE;
        }
    }
    irq_restore(f);
    return 0;
}

void pmm_free(u32 addr)
{
    u32 p = addr / PAGE;
    u32 f = irq_save();
    if (p >= first_page && p < end_page && used(p)) { unmark(p); free_pages++; }
    irq_restore(f);
}

/* ---------- paging ---------- */
static u32 *pd;
static void paging_init(void)
{
    u32 map_top = top_addr > 0x40000000u ? 0x40000000u : top_addr;
    map_top = (map_top + 0x3FFFFF) & ~0x3FFFFFu;
    u32 ntables = map_top >> 22;
    pd = (u32 *)pmm_alloc();
    if (!pd) return;
    memset(pd, 0, PAGE);
    for (u32 t = 0; t < ntables; t++) {
        u32 *pt = (u32 *)pmm_alloc();
        if (!pt) return;
        for (u32 i = 0; i < 1024; i++) pt[i] = ((t << 22) | (i << 12)) | 3;
        if (t == 0) pt[0] = 0;                       /* page 0 unmapped: NULL guard */
        pd[t] = (u32)pt | 3;
    }
    __asm__ volatile("mov %0,%%cr3" ::"r"(pd));
    u32 cr0;
    __asm__ volatile("mov %%cr0,%0" : "=r"(cr0));
    cr0 |= 0x80000000u;
    __asm__ volatile("mov %0,%%cr0" ::"r"(cr0));
    paged = 1;
}
int paging_enabled(void) { return paged; }

/* identity-map an extra physical range (the video framebuffer lives above RAM) */
int paging_map(u32 phys, u32 size)
{
    if (!paged) return 0;
    for (u32 a = phys & ~0xFFFu; a < phys + size; a += PAGE) {
        u32 di = a >> 22, ti = (a >> 12) & 1023;
        if (!(pd[di] & 1)) {
            u32 *pt = (u32 *)pmm_alloc();
            if (!pt) return -1;
            memset(pt, 0, PAGE);
            pd[di] = (u32)pt | 3;
        }
        ((u32 *)(pd[di] & ~0xFFFu))[ti] = a | 3;
    }
    u32 c3;
    __asm__ volatile("mov %%cr3,%0; mov %0,%%cr3" : "=r"(c3)::"memory");
    return 0;
}

/* ---------- heap: first-fit free list with coalescing ---------- */
struct hblock { u32 size; u32 free; struct hblock *next; };
static struct hblock *heap_head;
static u32 heap_bytes;

u32 heap_total(void) { return heap_bytes; }
u32 heap_used(void)
{
    u32 f = irq_save(), u = 0;
    for (struct hblock *b = heap_head; b; b = b->next) if (!b->free) u += b->size + sizeof(*b);
    irq_restore(f);
    return u;
}

void *kmalloc(u32 n)
{
    if (!heap_head || !n) return NULL;
    n = (n + 15) & ~15u;
    u32 f = irq_save();
    for (struct hblock *b = heap_head; b; b = b->next) {
        if (!b->free || b->size < n) continue;
        if (b->size >= n + sizeof(*b) + 32) {
            struct hblock *r = (struct hblock *)((u8 *)(b + 1) + n);
            r->size = b->size - n - sizeof(*b);
            r->free = 1; r->next = b->next;
            b->size = n; b->next = r;
        }
        b->free = 0;
        irq_restore(f);
        return b + 1;
    }
    irq_restore(f);
    return NULL;
}

void kfree(void *p)
{
    if (!p) return;
    u32 f = irq_save();
    struct hblock *b = (struct hblock *)p - 1;
    b->free = 1;
    for (struct hblock *c = heap_head; c; c = c->next)         /* merge neighbours */
        while (c->free && c->next && c->next->free) {
            c->size += sizeof(*c) + c->next->size;
            c->next = c->next->next;
        }
    irq_restore(f);
}

void mm_init(void)
{
    /* find the usable RAM region that starts at 1 MB (type 1 in the E820 map) */
    u32 top = 0;
    for (u32 i = 0; i < BOOTINFO->e820_count && i < 20; i++) {
        struct e820_entry *e = &BOOTINFO->e820[i];
        if (e->type != 1 || e->base_hi || e->len_hi) continue;
        u32 end = e->base_lo + e->len_lo;
        if (e->base_lo <= 0x100000 && end > top) top = end;
    }
    if (!top) top = BOOTINFO->total_kb * 1024;          /* fallback: E801 total */
    if (top > 0x40000000u) top = 0x40000000u;
    if (top < 0x200000) top = 0x200000;
    top_addr = top;
    end_page = top / PAGE;
    for (u32 i = 0; i < sizeof(bitmap); i++) bitmap[i] = 0xFF;
    for (u32 p = first_page; p < end_page; p++) unmark(p);
    total_pages = free_pages = end_page - first_page;

    paging_init();

    u32 pages = free_pages > 8192 ? 1024 : free_pages / 4;      /* 4 MB heap if RAM allows */
    u32 base = pages ? pmm_alloc_contig(pages) : 0;
    if (base) {
        heap_head = (struct hblock *)base;
        heap_head->size = pages * PAGE - sizeof(struct hblock);
        heap_head->free = 1; heap_head->next = NULL;
        heap_bytes = pages * PAGE;
    }
}
