/* FAT12 driver (root directory only) on the ATA disk. Every change is written
   straight through to disk, so files survive reboots. */
#include "chakra.h"

#define FAT_MAX (12 * 512)
#define ROOT_MAX (16 * 512)
static int mounted;
static u32 spc, reserved, nfats, spf, rootents, root_secs, fat_lba, root_lba, data_lba, nclust, total;
static u8 fat[FAT_MAX], root[ROOT_MAX], sec[512];

static u32 le16(const u8 *p) { return p[0] | (p[1] << 8); }
static u32 le32(const u8 *p) { return p[0] | (p[1] << 8) | (p[2] << 16) | ((u32)p[3] << 24); }
static void put16(u8 *p, u32 v) { p[0] = v; p[1] = v >> 8; }
static void put32(u8 *p, u32 v) { p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24; }

static u32 get_fat(u32 n)
{
    u32 i = n + n / 2, w = fat[i] | (fat[i + 1] << 8);
    return (n & 1) ? w >> 4 : w & 0xFFF;
}
static void set_fat(u32 n, u32 v)
{
    u32 i = n + n / 2;
    if (n & 1) { fat[i] = (fat[i] & 0x0F) | ((v & 0x0F) << 4); fat[i + 1] = v >> 4; }
    else { fat[i] = v & 0xFF; fat[i + 1] = (fat[i + 1] & 0xF0) | ((v >> 8) & 0x0F); }
}

int fat12_mount(void)
{
    mounted = 0;
    if (!ata_present() || ata_read(0, sec)) return -1;
    if (sec[510] != 0x55 || sec[511] != 0xAA || memcmp(sec + 0x36, "FAT12", 5)) return -1;
    if (le16(sec + 0x0B) != 512) return -1;
    spc = sec[0x0D]; reserved = le16(sec + 0x0E); nfats = sec[0x10];
    rootents = le16(sec + 0x11); spf = le16(sec + 0x16);
    total = le16(sec + 0x13) ? le16(sec + 0x13) : le32(sec + 0x20);
    if (!spc || !nfats || spf * 512 > FAT_MAX || rootents * 32 > ROOT_MAX) return -1;
    root_secs = (rootents * 32 + 511) / 512;
    fat_lba = reserved; root_lba = reserved + nfats * spf; data_lba = root_lba + root_secs;
    if (total <= data_lba) return -1;
    nclust = (total - data_lba) / spc;
    if (nclust >= 4085) return -1;
    for (u32 s = 0; s < spf; s++) if (ata_read(fat_lba + s, fat + s * 512)) return -1;
    for (u32 s = 0; s < root_secs; s++) if (ata_read(root_lba + s, root + s * 512)) return -1;
    mounted = 1;
    return 0;
}

static int flush_fat(void)
{
    for (u32 c = 0; c < nfats; c++)
        for (u32 s = 0; s < spf; s++) if (ata_write(fat_lba + c * spf + s, fat + s * 512)) return -1;
    return 0;
}
static int flush_root(void)
{
    for (u32 s = 0; s < root_secs; s++) if (ata_write(root_lba + s, root + s * 512)) return -1;
    return 0;
}

static void to83(const char *n, u8 out[11])
{
    memset(out, ' ', 11);
    int i = 0;
    while (*n && *n != '.' && i < 8) out[i++] = *n++;
    if (*n == '.') { n++; for (int k = 0; *n && k < 3; k++) out[8 + k] = *n++; }
}

static int valid(const u8 *e)
{ return e[0] != 0 && e[0] != 0xE5 && !(e[11] & 0x08) && (e[11] & 0x0F) != 0x0F && !(e[11] & 0x10); }

static u8 *find(const char *name)
{
    u8 n[11]; to83(name, n);
    for (u32 i = 0; i < rootents; i++) {
        u8 *e = root + i * 32;
        if (e[0] == 0) break;
        if (valid(e) && !memcmp(e, n, 11)) return e;
    }
    return NULL;
}

int fat12_list(struct fs_entry *out, int max)
{
    int n = 0;
    if (!mounted) return 0;
    for (u32 i = 0; i < rootents && n < max; i++) {
        u8 *e = root + i * 32;
        if (e[0] == 0) break;
        if (!valid(e)) continue;
        int k = 0;
        for (int j = 0; j < 8 && e[j] != ' '; j++) out[n].name[k++] = e[j];
        if (e[8] != ' ') { out[n].name[k++] = '.'; for (int j = 8; j < 11 && e[j] != ' '; j++) out[n].name[k++] = e[j]; }
        out[n].name[k] = 0;
        out[n].size = le32(e + 28);
        n++;
    }
    return n;
}

int fat12_size(const char *name, u32 *size)
{
    u8 *e = mounted ? find(name) : NULL;
    if (!e) return -1;
    *size = le32(e + 28);
    return 0;
}

int fat12_read(const char *name, char *buf, u32 max, u32 *len)
{
    u8 *e = mounted ? find(name) : NULL;
    if (!e) return -1;
    u32 size = le32(e + 28), cl = le16(e + 26), n = 0;
    if (size > max) size = max;
    while (cl >= 2 && cl < 0xFF8 && n < size) {
        for (u32 s = 0; s < spc && n < size; s++) {
            if (ata_read(data_lba + (cl - 2) * spc + s, sec)) return -2;
            u32 c = size - n < 512 ? size - n : 512;
            memcpy(buf + n, sec, c);
            n += c;
        }
        cl = get_fat(cl);
    }
    *len = n;
    return 0;
}

static void free_chain(u32 c)
{
    while (c >= 2 && c < 0xFF8) { u32 nx = get_fat(c); set_fat(c, 0); c = nx; }
}
static u32 chain_len(u32 c)
{
    u32 n = 0;
    while (c >= 2 && c < 0xFF8 && n <= nclust) { n++; c = get_fat(c); }
    return n;
}
static u32 free_clusters(void)
{
    u32 n = 0;
    for (u32 c = 2; c < nclust + 2; c++) if (get_fat(c) == 0) n++;
    return n;
}

u32 fat12_total_bytes(void) { return mounted ? nclust * spc * 512 : 0; }
u32 fat12_free_bytes(void) { return mounted ? free_clusters() * spc * 512 : 0; }

int fat12_write(const char *name, const char *data, u32 len)
{
    if (!mounted) return -1;
    u8 *e = find(name);
    if (!e) {
        for (u32 i = 0; i < rootents; i++) {
            u8 *x = root + i * 32;
            if (x[0] == 0 || x[0] == 0xE5) { e = x; break; }
        }
        if (!e) return -1;                         /* directory full */
        memset(e, 0, 32);
        to83(name, e);
    }
    u32 cb = spc * 512, need = (len + cb - 1) / cb;
    u32 oldfirst = le16(e + 26), oldlen = chain_len(oldfirst);
    if (free_clusters() + oldlen < need) return -2;
    free_chain(oldfirst);
    u32 first = 0, prev = 0, off = 0, c = 2;
    for (u32 k = 0; k < need; k++) {
        while (c < nclust + 2 && get_fat(c)) c++;
        set_fat(c, 0xFFF);
        if (prev) set_fat(prev, c); else first = c;
        prev = c;
        for (u32 s = 0; s < spc; s++) {
            memset(sec, 0, 512);
            u32 n = len - off > 512 ? 512 : (len > off ? len - off : 0);
            memcpy(sec, data + off, n);
            off += n;
            if (ata_write(data_lba + (c - 2) * spc + s, sec)) return -1;
        }
    }
    int h, m, s, d, mo, y;
    rtc_read(&h, &m, &s, &d, &mo, &y);
    e[11] = 0x20;
    put16(e + 22, (h << 11) | (m << 5) | (s / 2));
    put16(e + 24, ((y - 1980) << 9) | (mo << 5) | d);
    put16(e + 26, first);
    put32(e + 28, len);
    if (flush_fat() || flush_root()) return -1;
    return 0;
}

int fat12_remove(const char *name)
{
    u8 *e = mounted ? find(name) : NULL;
    if (!e) return -1;
    free_chain(le16(e + 26));
    e[0] = 0xE5;
    return (flush_fat() || flush_root()) ? -2 : 0;
}

int fat12_rename(const char *a, const char *b)
{
    u8 *e = mounted ? find(a) : NULL;
    if (!e) return -1;
    if (find(b)) return -3;
    to83(b, e);
    return flush_root() ? -2 : 0;
}

/* ---------------- disk manager support ---------------- */
int fat12_geo(struct fat_geo *g)
{
    if (!mounted) return -1;
    g->total_sectors = total; g->reserved = reserved; g->fats = nfats; g->spf = spf;
    g->root_entries = rootents; g->root_secs = root_secs; g->fat_lba = fat_lba; g->root_lba = root_lba;
    g->data_lba = data_lba; g->spc = spc; g->clusters = nclust; g->free_clusters = free_clusters();
    if (ata_read(0, sec)) return -1;
    memcpy(g->label, sec + 0x2B, 11); g->label[11] = 0;
    for (int i = 10; i >= 0 && g->label[i] == ' '; i--) g->label[i] = 0;
    return 0;
}

int fat12_label(const char *set, char *out)
{
    if (!mounted || ata_read(0, sec)) return -1;
    if (set) {
        memset(sec + 0x2B, ' ', 11);
        for (int i = 0; i < 11 && set[i]; i++) sec[0x2B + i] = (set[i] >= 'a' && set[i] <= 'z') ? set[i] - 32 : set[i];
        if (ata_write(0, sec)) return -2;
    }
    if (out) { memcpy(out, sec + 0x2B, 11); out[11] = 0; for (int i = 10; i >= 0 && out[i] == ' '; i--) out[i] = 0; }
    return 0;
}

int fat12_stat(const char *name, u32 *first, u32 *clusters, u32 *date, u32 *time)
{
    u8 *e = mounted ? find(name) : NULL;
    if (!e) return -1;
    *first = le16(e + 26); *clusters = chain_len(*first); *date = le16(e + 24); *time = le16(e + 22);
    return 0;
}

int fat12_check(int repair, u32 *files, u32 *errors, u32 *lost, u32 *fixed)
{
    static u8 seen[512];
    if (!mounted) return -1;
    memset(seen, 0, sizeof seen);
    *files = *errors = *lost = *fixed = 0;
    u32 cb = spc * 512;
    for (u32 i = 0; i < rootents; i++) {
        u8 *e = root + i * 32;
        if (e[0] == 0) break;
        if (!valid(e)) continue;
        (*files)++;
        u32 first = le16(e + 26), size = le32(e + 28), expect = (size + cb - 1) / cb;
        if (!first) { if (size) { (*errors)++; if (repair) { put32(e + 28, 0); (*fixed)++; } } continue; }
        u32 cl = first, n = 0, last = 0; int bad = 0;
        while (cl >= 2 && cl < 0xFF8) {
            if (cl >= nclust + 2) { bad = 1; break; }
            if (seen[cl >> 3] & (1 << (cl & 7))) { bad = 2; break; }
            seen[cl >> 3] |= 1 << (cl & 7);
            n++; last = cl; cl = get_fat(cl);
            if (n > nclust) { bad = 3; break; }
        }
        if (!bad && cl < 0xFF8) bad = 4;                    /* chain ends in a free or bad cluster */
        if (bad || n != expect) {
            (*errors)++;
            if (repair) {
                if (n == 0) { put16(e + 26, 0); put32(e + 28, 0); }
                else {
                    if (bad || n < expect) set_fat(last, 0xFFF);
                    else if (n > expect && expect > 0) {     /* chain longer than the size needs: free the tail */
                        u32 c = first; for (u32 k = 1; k < expect; k++) c = get_fat(c);
                        u32 rest = get_fat(c); set_fat(c, 0xFFF); free_chain(rest);
                    }
                    if (n * cb < size) put32(e + 28, n * cb);
                }
                (*fixed)++;
            }
        }
    }
    for (u32 c = 2; c < nclust + 2; c++)
        if (get_fat(c) && !(seen[c >> 3] & (1 << (c & 7)))) { (*lost)++; if (repair) { set_fat(c, 0); (*fixed)++; } }
    if (repair && *fixed && (flush_fat() || flush_root())) return -2;
    return 0;
}
