/* Basic I/O and file-reading commands: beep, port access, key monitor, pager, line editor. */
#include "chakra.h"

static u32 hexv(const char *s)
{
    u32 v = 0;
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) s += 2;
    for (; *s; s++) { char c = *s; v = v * 16 + (c >= 'a' ? c - 'a' + 10 : c >= 'A' ? c - 'A' + 10 : c - '0'); }
    return v;
}
static u32 decv(const char *s) { u32 n = 0; while (*s >= '0' && *s <= '9') n = n * 10 + (*s++ - '0'); return n; }

static void beep(u32 hz, u32 ms)
{
    if (hz < 40 || hz > 20000) hz = 800;
    u32 d = 1193180 / hz;
    outb(0x43, 0xB6); outb(0x42, d & 0xFF); outb(0x42, d >> 8);
    outb(0x61, inb(0x61) | 3);
    sleep_ms(ms);
    outb(0x61, inb(0x61) & ~3);
}

static void cmd_more(const char *name)
{
    u32 sz;
    if (fs_size(name, &sz)) { kprintf("more: no such file: %s\n", name); return; }
    char *b = kmalloc(sz + 1); u32 n = 0;
    if (!b || fs_read(name, b, sz, &n)) { puts("more: cannot read\n"); if (b) kfree(b); return; }
    int lines = 0;
    for (u32 i = 0; i < n; i++) {
        if (b[i] == '\r') continue;
        putc(b[i]);
        if (b[i] == '\n' && ++lines >= 20) {
            puts("-- more (space = next page, q = quit) --");
            int k = getchar();
            puts("\r                                          \r");
            if (k == 'q' || k == 'Q' || k == 3 || k == 27) break;
            lines = 0;
        }
    }
    putc('\n');
    kfree(b);
}

/* ed-style line editor: a(ppend) i<n> d<n> p w q */
static void cmd_edit(const char *name)
{
    enum { MAXL = 200, LL = 120 };
    char (*L)[LL] = kmalloc(MAXL * LL);
    if (!L) { puts("edit: out of memory\n"); return; }
    int n = 0, dirty = 0;
    u32 sz;
    if (!fs_size(name, &sz)) {
        char *b = kmalloc(sz + 1); u32 got = 0;
        if (b && !fs_read(name, b, sz, &got)) {
            int c = 0;
            for (u32 i = 0; i < got && n < MAXL; i++) {
                if (b[i] == '\r') continue;
                if (b[i] == '\n') { L[n][c] = 0; n++; c = 0; } else if (c < LL - 1) L[n][c++] = b[i];
            }
            if (c && n < MAXL) { L[n][c] = 0; n++; }
        }
        if (b) kfree(b);
        kprintf("Editing %s (%d lines)\n", name, n);
    } else kprintf("New file %s\n", name);
    puts("Commands: p = list   a = add lines at end (end with a single .)   i N = insert before line N\n          d N = delete line N   w = save   q = quit   (a bare number replaces that line)\n");
    char cmd[LL];
    for (;;) {
        puts("edit> ");
        int len = 0;
        for (;;) {
            int k = getchar();
            if (k == '\n') { putc('\n'); break; }
            if (k == '\b') { if (len) { len--; putc('\b'); } continue; }
            if (k >= 32 && k < 127 && len < LL - 1) { cmd[len++] = k; putc(k); }
        }
        cmd[len] = 0;
        if (!strcmp(cmd, "q")) { if (dirty) { puts("unsaved changes! 'w' saves, 'q!' quits anyway\n"); continue; } break; }
        if (!strcmp(cmd, "q!")) break;
        if (!strcmp(cmd, "p")) { for (int i = 0; i < n; i++) kprintf("%3d  %s\n", i + 1, L[i]); if (!n) puts("(empty)\n"); }
        else if (!strcmp(cmd, "w")) {
            u32 total = 0; for (int i = 0; i < n; i++) total += strlen(L[i]) + 1;
            char *o = kmalloc(total + 1); u32 p = 0;
            if (!o) { puts("out of memory\n"); continue; }
            for (int i = 0; i < n; i++) { u32 l = strlen(L[i]); memcpy(o + p, L[i], l); p += l; o[p++] = '\n'; }
            int r = fs_write(name, o, p, 0);
            kfree(o);
            if (r) puts("save failed (bad name or no space)\n"); else { puts("saved\n"); dirty = 0; }
        }
        else if (cmd[0] == 'd' && cmd[1] == ' ') {
            u32 k = decv(cmd + 2);
            if (k >= 1 && (int)k <= n) { memmove(L[k - 1], L[k], (n - k) * LL); n--; dirty = 1; } else puts("no such line\n");
        }
        else if (cmd[0] == 'a' || (cmd[0] == 'i' && cmd[1] == ' ')) {
            int at = n;
            if (cmd[0] == 'i') { at = (int)decv(cmd + 2) - 1; if (at < 0 || at > n) { puts("no such line\n"); continue; } }
            for (;;) {
                puts("  ");
                int l = 0; char t[LL];
                for (;;) {
                    int k = getchar();
                    if (k == '\n') { putc('\n'); break; }
                    if (k == '\b') { if (l) { l--; putc('\b'); } continue; }
                    if (k >= 32 && k < 127 && l < LL - 1) { t[l++] = k; putc(k); }
                }
                t[l] = 0;
                if (!strcmp(t, ".") || n >= MAXL) break;
                memmove(L[at + 1], L[at], (n - at) * LL);
                strncpy0(L[at], t, LL); at++; n++; dirty = 1;
            }
        }
        else if (cmd[0] >= '1' && cmd[0] <= '9') {
            u32 k = decv(cmd);
            if ((int)k <= n) {
                puts("  new text: ");
                int l = 0; char t[LL];
                for (;;) { int c = getchar(); if (c == '\n') { putc('\n'); break; } if (c == '\b') { if (l) { l--; putc('\b'); } continue; } if (c >= 32 && c < 127 && l < LL - 1) { t[l++] = c; putc(c); } }
                t[l] = 0; strncpy0(L[k - 1], t, LL); dirty = 1;
            } else puts("no such line\n");
        }
        else if (cmd[0]) puts("?\n");
    }
    kfree(L);
}

int io_command(int argc, char **argv)
{
    const char *c = argv[0];
    if (!strcmp(c, "beep")) beep(argc > 1 ? decv(argv[1]) : 880, argc > 2 ? decv(argv[2]) : 200);
    else if (!strcmp(c, "inb")) { if (argc < 2) puts("usage: inb <port hex>\n"); else { u32 p = hexv(argv[1]) & 0xFFFF; kprintf("port %x = %02x\n", p, inb(p)); } }
    else if (!strcmp(c, "outb")) {
        if (argc < 3) puts("usage: outb <port hex> <value hex>   (careful: writing to the wrong port can hang the machine)\n");
        else { u32 p = hexv(argv[1]) & 0xFFFF; outb(p, hexv(argv[2])); kprintf("wrote %02x to port %x\n", hexv(argv[2]) & 255, p); }
    }
    else if (!strcmp(c, "keys")) {
        puts("Key monitor: press keys to see their codes. Esc quits.\n");
        for (;;) { int k = getchar(); kprintf("  code %u (0x%x)%s\n", k, k, k >= 32 && k < 127 ? "" : ""); if (k == 27) break; }
    }
    else if (!strcmp(c, "more") || !strcmp(c, "less")) { if (argc < 2) puts("usage: more <file>\n"); else cmd_more(argv[1]); }
    else if (!strcmp(c, "edit")) { if (argc < 2) puts("usage: edit <file>\n"); else cmd_edit(argv[1]); }
    else return 0;
    return 1;
}
