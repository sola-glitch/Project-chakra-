; Chakra OS - kernel entry + interrupt stubs
[bits 32]
extern kmain
extern isr_handler
extern __bss_start
extern __bss_end

section .text.entry
global _start
_start:
    cld
    mov edi, __bss_start          ; zero the .bss
    mov ecx, __bss_end
    sub ecx, edi
    xor eax, eax
    rep stosb
    call kmain
.hang:
    cli
    hlt
    jmp .hang

section .text
%macro ISR_NOERR 1
isr%1:
    push dword 0
    push dword %1
    jmp isr_common
%endmacro
%macro ISR_ERR 1
isr%1:
    push dword %1
    jmp isr_common
%endmacro

%assign i 0
%rep 48
  %if i == 8 || (i >= 10 && i <= 14) || i == 17 || i == 21 || i == 29 || i == 30
    ISR_ERR i
  %else
    ISR_NOERR i
  %endif
  %assign i i+1
%endrep

isr_common:
    pushad
    push esp
    call isr_handler
    add esp, 4
    popad
    add esp, 8
    iretd

global switch_context
; void switch_context(u32 *old_esp, u32 new_esp)  - used by the scheduler
switch_context:
    mov eax, [esp + 4]
    mov edx, [esp + 8]
    push ebp
    push ebx
    push esi
    push edi
    mov [eax], esp
    mov esp, edx
    pop edi
    pop esi
    pop ebx
    pop ebp
    ret

section .data
global isr_stub_table
isr_stub_table:
%assign i 0
%rep 48
    dd isr %+ i
  %assign i i+1
%endrep

section .note.GNU-stack noalloc noexec nowrite progbits
