/* Text-mode UI: a live status bar (its own task) and the `ui` desktop launcher. */
#include "chakra.h"

#define A(fg, bg) ((u8)(((bg) << 4) | (fg)))

/* ---------------- status bar (row 0) ---------------- */
static void draw_status(void)
{
    char line[96];
    int h, m, s, d, mo, y, nt = 0;
    struct task_info ti;
    rtc_read(&h, &m, &s, &d, &mo, &y);
    for (int i = 0; i < 8; i++) if (!task_get(i, &ti)) nt++;
    u32 up = ticks() / 100;
    int n = ksnprintf(line, sizeof line, " CHAKRA OS %s | up %u:%02u:%02u | RAM free %u MB | tasks %d | %s",
                      CHAKRA_VERSION, up / 3600, (up / 60) % 60, up % 60, pmm_free_pages() / 256, nt,
                      fs_on_disk() ? "disk" : "RAM disk");
    while (n < 70) line[n++] = ' ';
    ksnprintf(line + 70, 11, "%02d:%02d:%02d ", h, m, s);
    line[80] = 0;
    vga_text(0, 0, line, A(WHITE, MAGENTA));
}

static void status_task(void *a)
{
    (void)a;
    for (;;) { draw_status(); task_sleep(500); }
}

void ui_start_status(void)
{
    draw_status();
    task_create("statusbar", status_task, NULL);
}

/* ---------------- desktop ---------------- */
static void box(int r, int c, int h, int w, const char *title, int focus)
{
    u8 a = focus ? A(LMAGENTA, BLACK) : A(DGREY, BLACK);
    u8 tl = focus ? 0xC9 : 0xDA, tr = focus ? 0xBB : 0xBF, bl = focus ? 0xC8 : 0xC0, br = focus ? 0xBC : 0xD9;
    u8 hz = focus ? 0xCD : 0xC4, vt = focus ? 0xBA : 0xB3;
    vga_fill(r, c, h, w, ' ', A(LGREY, BLACK));
    vga_put(r, c, tl, a); vga_put(r, c + w - 1, tr, a);
    vga_put(r + h - 1, c, bl, a); vga_put(r + h - 1, c + w - 1, br, a);
    for (int i = 1; i < w - 1; i++) { vga_put(r, c + i, hz, a); vga_put(r + h - 1, c + i, hz, a); }
    for (int i = 1; i < h - 1; i++) { vga_put(r + i, c, vt, a); vga_put(r + i, c + w - 1, vt, a); }
    if (title) { vga_put(r, c + 2, ' ', a); vga_text(r, c + 3, title, A(WHITE, BLACK)); vga_put(r, c + 3 + (int)strlen(title), ' ', a); }
}

static const char *items[] = { "Files", "System", "Tasks", "Chakras", "About", "Quit to shell" };
#define NITEMS 6
#define CR 4          /* content area: first row */
#define CC 25         /* first column */
#define CW 52         /* width */

static void line(int row, const char *s, u8 a)
{
    char b[CW + 1]; int i = 0;
    while (s[i] && i < CW) { b[i] = s[i]; i++; }
    while (i < CW) b[i++] = ' ';
    b[i] = 0;
    vga_text(CR + row, CC, b, a);
}

static void panel_files(int focus, int fsel, int view)
{
    struct fs_entry fe[16];
    int n = fs_list(fe, 16);
    if (view && fsel < n) {
        char *buf = kmalloc(1025); u32 len = 0;
        if (buf && !fs_read(fe[fsel].name, buf, 1024, &len)) {
            buf[len] = 0;
            line(0, fe[fsel].name, A(YELLOW, BLACK));
            int row = 2, col = 0; char ln[CW + 1];
            for (u32 i = 0; i <= len && row < 17; i++) {
                char c = i < len ? buf[i] : '\n';
                if (c == '\r') continue;
                if (c == '\n' || col == CW - 1) { ln[col] = 0; line(row++, ln, A(LGREY, BLACK)); col = 0; if (c == '\n') continue; }
                ln[col++] = (c >= 32 && c < 127) ? c : '.';
            }
            while (row < 17) line(row++, "", A(LGREY, BLACK));
        }
        if (buf) kfree(buf);
        line(17, "Left/Esc: back to the list", A(DGREY, BLACK));
        return;
    }
    line(0, "NAME            SIZE", A(YELLOW, BLACK));
    for (int i = 0; i < 16; i++) {
        char t[CW + 1];
        if (i < n) ksnprintf(t, sizeof t, "%s %-12s %6u", (focus && i == fsel) ? ">" : " ", fe[i].name, fe[i].size);
        else t[0] = 0;
        line(i + 1, t, (focus && i == fsel) ? A(BLACK, LMAGENTA) : A(LGREY, BLACK));
    }
    line(17, focus ? "Up/Down choose, Enter to read, Left back" : "Press Right or Enter to browse", A(DGREY, BLACK));
}

static void panel_system(void)
{
    char t[CW + 1]; int h, m, s, d, mo, y;
    rtc_read(&h, &m, &s, &d, &mo, &y);
    u32 up = ticks() / 100;
    line(0, "System", A(YELLOW, BLACK));
    ksnprintf(t, sizeof t, "Chakra OS %s  (x86, BIOS, 32-bit)", CHAKRA_VERSION); line(2, t, A(LGREY, BLACK));
    ksnprintf(t, sizeof t, "Uptime      %u:%02u:%02u", up / 3600, (up / 60) % 60, up % 60); line(3, t, A(LGREY, BLACK));
    ksnprintf(t, sizeof t, "Clock       %04d-%02d-%02d %02d:%02d:%02d", y, mo, d, h, m, s); line(4, t, A(LGREY, BLACK));
    ksnprintf(t, sizeof t, "RAM         %u MB, %u MB free", mem_top() >> 20, pmm_free_pages() / 256); line(5, t, A(LGREY, BLACK));
    ksnprintf(t, sizeof t, "Heap        %u KB used / %u KB", heap_used() / 1024, heap_total() / 1024); line(6, t, A(LGREY, BLACK));
    ksnprintf(t, sizeof t, "Paging      %s", paging_enabled() ? "on" : "off"); line(7, t, A(LGREY, BLACK));
    ksnprintf(t, sizeof t, "Disk        %s", fs_on_disk() ? "FAT12 on ATA" : "none (RAM disk)"); line(8, t, A(LGREY, BLACK));
    ksnprintf(t, sizeof t, "Space       %u KB free of %u KB", fs_free_bytes() / 1024, fs_total_bytes() / 1024); line(9, t, A(LGREY, BLACK));
    for (int i = 10; i < 18; i++) line(i, "", A(LGREY, BLACK));
}

static void panel_tasks(void)
{
    static const char *st[4] = { "free", "ready", "sleep", "dead" };
    struct task_info ti; char t[CW + 1]; int row = 2;
    line(0, "Tasks (preemptive, 100 switches/second)", A(YELLOW, BLACK));
    line(1, "ID NAME        STATE   CPU      PROGRESS", A(DGREY, BLACK));
    for (int i = 0; i < 8; i++)
        if (!task_get(i, &ti)) { ksnprintf(t, sizeof t, "%-2d %-11s %-7s %-8u %u", ti.id, ti.name, st[ti.state], ti.cpu, ti.progress); line(row++, t, A(LGREY, BLACK)); }
    while (row < 18) line(row++, "", A(LGREY, BLACK));
}

static void panel_chakras(void)
{
    static const u8 col[7] = { LMAGENTA, LBLUE, LCYAN, LGREEN, YELLOW, BROWN, RED };
    static const char *nm[7] = { "Crown       awareness, unity", "Third eye   insight, vision", "Throat      voice, truth",
        "Heart       love, connection", "Solar       will, confidence", "Sacral      creativity, flow", "Root        stability, survival" };
    line(0, "The seven chakras", A(YELLOW, BLACK));
    for (int i = 0; i < 7; i++) { line(i * 2 + 2, nm[i], A(col[i], BLACK)); vga_put(CR + i * 2 + 2, CC - 2, 0xDB, A(col[i], BLACK)); }
    for (int i = 16; i < 18; i++) line(i, "", A(LGREY, BLACK));
    for (int i = 1; i < 18; i += 2) if (i < 16) line(i, "", A(LGREY, BLACK));
}

static void panel_about(void)
{
    line(0, "About Chakra OS", A(YELLOW, BLACK));
    line(2, "A small operating system written from scratch:", A(LGREY, BLACK));
    line(3, "two-stage FAT12 boot, protected-mode kernel,", A(LGREY, BLACK));
    line(4, "paging, heap, preemptive tasks, ATA + FAT12,", A(LGREY, BLACK));
    line(5, "keyboard interrupts and a shell.", A(LGREY, BLACK));
    line(7, "Press Q or Esc to return to the shell.", A(DGREY, BLACK));
    for (int i = 8; i < 18; i++) line(i, "", A(LGREY, BLACK));
}

static void render(int sel, int focus, int fsel, int view)
{
    vga_fill(1, 0, 24, 80, ' ', A(LGREY, BLACK));
    static const u8 cc[7] = { RED, BROWN, YELLOW, LGREEN, LCYAN, LBLUE, LMAGENTA };
    for (int i = 0; i < 7; i++) vga_fill(1, 1 + i * 3, 1, 3, 0xDB, A(cc[i], BLACK));
    vga_text(1, 26, "CHAKRA DESKTOP", A(WHITE, BLACK));
    box(3, 1, 12, 22, "Menu", !focus);
    for (int i = 0; i < NITEMS; i++) {
        char t[24]; ksnprintf(t, sizeof t, " %-19s", items[i]);
        vga_text(5 + i, 2, t, i == sel ? A(BLACK, LMAGENTA) : A(LGREY, BLACK));
    }
    box(3, 24, 20, 55, items[sel], focus);
    switch (sel) {
    case 0: panel_files(focus, fsel, view); break;
    case 1: panel_system(); break;
    case 2: panel_tasks(); break;
    case 3: panel_chakras(); break;
    case 4: panel_about(); break;
    default: line(0, "Return to the shell", A(YELLOW, BLACK)); line(2, "Press Enter.", A(LGREY, BLACK)); break;
    }
    vga_text(24, 1, " Up/Down select  Enter/Right open  Left/Esc back  Q quit ", A(BLACK, LGREY));
}

void ui_run(void)
{
    int sel = 0, focus = 0, fsel = 0, view = 0;
    u32 last = 0;
    vga_cursor_visible(0);
    render(sel, focus, fsel, view);
    for (;;) {
        int k = input_nb();
        if (k < 0) {
            if (ticks() - last >= 50 && (sel == 1 || sel == 2)) { render(sel, focus, fsel, view); last = ticks(); }
            __asm__ volatile("hlt");
            continue;
        }
        if (k == 'q' || k == 'Q' || k == 3) break;
        if (k == 27 || k == KEY_LEFT) {
            if (view) view = 0; else if (focus) focus = 0; else if (k == 27) break;
        } else if (k == KEY_UP) {
            if (focus && sel == 0) { if (fsel > 0) fsel--; } else if (!focus && sel > 0) { sel--; fsel = 0; }
        } else if (k == KEY_DOWN) {
            if (focus && sel == 0) fsel++; else if (!focus && sel < NITEMS - 1) { sel++; fsel = 0; }
        } else if (k == '\n' || k == KEY_RIGHT) {
            if (!focus) { if (sel == NITEMS - 1) break; if (sel == 0) { focus = 1; fsel = 0; } }
            else if (sel == 0 && k == '\n') view = 1;
        }
        if (fsel > 15) fsel = 15;
        render(sel, focus, fsel, view);
    }
    vga_cursor_visible(1);
    clear_screen();
}
