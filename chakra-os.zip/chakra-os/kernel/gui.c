/* Chakra desktop: windows, mouse, taskbar and apps (Terminal, Files, Disks, Editor, Browser, Monitor). */
#include "chakra.h"

extern void con_use_terminal(void);

#define C_BG 0x241638
#define C_WIN 0x1C1B2E
#define C_BORDER 0x6A4C93
#define C_TITLE 0x7B2CBF
#define C_TITLE_IN 0x3D3560
#define C_TXT 0xE8E6F4
#define C_DIM 0x9A95B8
#define C_BTN 0x3B3566
#define C_SEL 0x5B2C8F
#define C_OK 0x46C26B
#define C_ERR 0xE5484D
#define C_TASK 0x15101F
#define TB 22
#define TASKH 30

enum { A_TERM, A_FILES, A_DISK, A_EDIT, A_WEB, A_MON, NAPPS };
static const char *app_name[NAPPS] = { "Terminal", "Files", "Disks", "Editor", "Browser", "Monitor" };

struct win {
    int used, app, x, y, w, h;
    char title[32];
    int sel, mode, confirm, scroll, cur, dirty, fetching, inlen;
    char in[100], msg[110], name[16];
    char *buf; u32 len;
};
static struct win wins[8];
static int zo[8], nz;
static int active, mx = 300, my = 200, mbtn, pbtn, drag = -1, ddx, ddy;
static int W, H;

/* terminal key queue */
static volatile int tq[128];
static volatile u32 tqh, tqt;
static void tpush(int k) { u32 n = (tqt + 1) & 127; if (n != tqh) { tq[tqt] = k; tqt = n; } }
int gui_term_pop(void)
{
    u32 f = irq_save(); int k = -1;
    if (tqh != tqt) { k = tq[tqh]; tqh = (tqh + 1) & 127; }
    irq_restore(f); return k;
}
int gui_active(void) { return active; }

static int hit(int px, int py, int x, int y, int w, int h) { return px >= x && px < x + w && py >= y && py < y + h; }
static void button(int x, int y, int w, const char *s, int on)
{
    gfx_rect(x, y, w, 22, on ? C_SEL : C_BTN);
    gfx_frame(x, y, w, 22, C_BORDER);
    gfx_text(x + (w - (int)strlen(s) * 8) / 2, y + 3, s, C_TXT, -1);
}
static void field(int x, int y, int w, const char *s, int focus)
{
    gfx_rect(x, y, w, 22, 0x0F0E1A); gfx_frame(x, y, w, 22, focus ? C_TITLE : C_BORDER);
    int max = (w - 12) / 8, n = (int)strlen(s);
    gfx_text(x + 6, y + 3, s + (n > max ? n - max : 0), C_TXT, -1);
    if (focus && (ticks() / 50) % 2) gfx_rect(x + 6 + (n > max ? max : n) * 8, y + 3, 2, 16, C_TXT);
}

/* ---------------- window management ---------------- */
static void raise_win(int i)
{
    int p = -1; for (int k = 0; k < nz; k++) if (zo[k] == i) p = k;
    if (p < 0) return;
    for (int k = p; k < nz - 1; k++) zo[k] = zo[k + 1];
    zo[nz - 1] = i;
}

static int open_win(int app)
{
    if (app != A_EDIT) for (int i = 0; i < 8; i++) if (wins[i].used && wins[i].app == app) { raise_win(i); gui_dirty = 1; return i; }
    int i; for (i = 0; i < 8; i++) if (!wins[i].used) break;
    if (i == 8) return -1;
    struct win *w = &wins[i];
    memset(w, 0, sizeof *w);
    w->used = 1; w->app = app;
    int k = nz;
    w->x = 40 + k * 26; w->y = 30 + k * 26;
    switch (app) {
    case A_TERM: w->x = 8; w->y = 8; w->w = 642; w->h = TB + 448 + 1; break;
    case A_FILES: w->w = 460; w->h = 400; break;
    case A_DISK: w->w = 520; w->h = 400; break;
    case A_EDIT: w->w = 600; w->h = 420; w->buf = kmalloc(8200); break;
    case A_WEB: w->w = 680; w->h = 480; w->buf = kmalloc(64 * 1024); strncpy0(w->in, "http://", sizeof w->in); w->inlen = 7; strncpy0(w->msg, "Type a web address and press Enter. Only http:// works for now.", sizeof w->msg); break;
    default: w->w = 480; w->h = 360; break;
    }
    if (w->x + w->w > W) w->x = W - w->w - 4;
    if (w->y + w->h > H - TASKH) w->y = H - TASKH - w->h - 2;
    if (w->x < 0) w->x = 0;
    if (w->y < 0) w->y = 0;
    strncpy0(w->title, app_name[app], sizeof w->title);
    zo[nz++] = i;
    gui_dirty = 1;
    return i;
}

static void close_win(int i)
{
    struct win *w = &wins[i];
    if (w->buf) kfree(w->buf);
    w->buf = NULL; w->used = 0;
    int p = 0; for (int k = 0; k < nz; k++) if (zo[k] != i) zo[p++] = zo[k];
    nz = p; gui_dirty = 1;
}

/* ---------------- terminal ---------------- */
static void draw_term(struct win *w, int cx, int cy)
{
    u16 *cells; int tx, ty, rows;
    term_state(&cells, &tx, &ty, &rows);
    gfx_rect(cx, cy, 640, rows * 16, 0x000000);
    for (int r = 0; r < rows; r++)
        for (int c = 0; c < 80; c++) {
            u16 v = cells[r * 80 + c]; u8 ch = v & 0xFF, at = v >> 8;
            if ((at >> 4) & 15) gfx_rect(cx + c * 8, cy + r * 16, 8, 16, vga_rgb(at >> 4));
            if (ch != ' ') { char s[2] = { ch, 0 }; gfx_text(cx + c * 8, cy + r * 16, s, vga_rgb(at & 15), -1); }
        }
    if ((ticks() / 50) % 2 || 1) gfx_rect(cx + tx * 8, cy + ty * 16 + 13, 8, 3, 0xFFFFFF);
    (void)w;
}

/* ---------------- files ---------------- */
static void files_msg(struct win *w, const char *m) { strncpy0(w->msg, m, sizeof w->msg); }

static void draw_files(struct win *w, int cx, int cy, int cw, int ch)
{
    static const char *bl[5] = { "Open", "New", "Copy", "Rename", "Delete" };
    for (int i = 0; i < 5; i++) button(cx + 6 + i * 68, cy + 4, 64, bl[i], 0);
    struct fs_entry fe[16];
    int n = fs_list(fe, 16);
    if (w->sel >= n) w->sel = n ? n - 1 : 0;
    gfx_text(cx + 10, cy + 34, "NAME", C_DIM, -1); gfx_text(cx + 220, cy + 34, "SIZE", C_DIM, -1);
    for (int i = 0; i < n; i++) {
        int y = cy + 52 + i * 18;
        if (i == w->sel) gfx_rect(cx + 4, y - 1, cw - 8, 18, C_SEL);
        char sz[16]; ksnprintf(sz, sizeof sz, "%u", fe[i].size);
        gfx_text(cx + 10, y, fe[i].name, C_TXT, -1); gfx_text(cx + 220, y, sz, C_TXT, -1);
    }
    if (w->mode) {
        static const char *pl[4] = { "", "Rename to:", "New file name:", "Copy to:" };
        gfx_text(cx + 10, cy + ch - 84, pl[w->mode], C_DIM, -1);
        field(cx + 110, cy + ch - 88, cw - 120, w->in, 1);
    }
    gfx_text(cx + 10, cy + ch - 58, w->msg, C_ERR, -1);
    u32 tot = fs_total_bytes(), fr = fs_free_bytes();
    char t[64]; ksnprintf(t, sizeof t, "%s: %u KB free of %u KB", fs_on_disk() ? "Disk" : "RAM disk", fr / 1024, tot / 1024);
    gfx_text(cx + 10, cy + ch - 36, t, C_TXT, -1);
    gfx_rect(cx + 10, cy + ch - 18, cw - 20, 10, 0x0F0E1A);
    gfx_rect(cx + 10, cy + ch - 18, tot ? (int)(((tot - fr) * (u32)(cw - 20)) / tot) : 0, 10, C_TITLE);
}

static void open_editor(const char *name);

static void files_click(struct win *w, int px, int py, int cw, int ch)
{
    struct fs_entry fe[16];
    int n = fs_list(fe, 16);
    (void)cw; (void)ch;
    if (py >= 4 && py < 26 && px >= 6) {
        int b = (px - 6) / 68;
        if (b > 4 || (px - 6) % 68 > 64) return;
        files_msg(w, "");
        if (b == 0 && n) { open_editor(fe[w->sel].name); }
        else if (b == 1) { w->mode = 2; w->inlen = 0; w->in[0] = 0; }
        else if (b == 2 && n) { w->mode = 3; w->inlen = 0; w->in[0] = 0; }
        else if (b == 3 && n) { w->mode = 1; strncpy0(w->in, fe[w->sel].name, sizeof w->in); w->inlen = strlen(w->in); }
        else if (b == 4 && n) {
            if (!strcmp(fe[w->sel].name, "KERNEL.BIN")) files_msg(w, "KERNEL.BIN is the system kernel: protected");
            else if (fs_remove(fe[w->sel].name)) files_msg(w, "could not delete"); else files_msg(w, "deleted");
        }
    } else if (py >= 52) {
        int row = (py - 52) / 18;
        if (row < n) w->sel = row;
    }
}

static void files_key(struct win *w, int k)
{
    struct fs_entry fe[16];
    int n = fs_list(fe, 16);
    if (!w->mode) {
        if (k == KEY_UP && w->sel > 0) w->sel--;
        else if (k == KEY_DOWN && w->sel + 1 < n) w->sel++;
        else if (k == '\n' && n) open_editor(fe[w->sel].name);
        else if (k == KEY_DEL && n && strcmp(fe[w->sel].name, "KERNEL.BIN")) fs_remove(fe[w->sel].name);
        return;
    }
    if (k == 27) { w->mode = 0; return; }
    if (k == '\b') { if (w->inlen) w->in[--w->inlen] = 0; return; }
    if (k >= 32 && k < 127 && w->inlen < 14) { w->in[w->inlen++] = k; w->in[w->inlen] = 0; return; }
    if (k != '\n' || (!n && w->mode != 2)) return;
    int r = 0;
    if (w->mode == 1) r = fs_rename(fe[w->sel].name, w->in);
    else if (w->mode == 2) { u32 sz; if (!fs_size(w->in, &sz)) r = -3; else r = fs_write(w->in, "", 0, 0); }
    else if (w->mode == 3) {
        u32 sz, got; char *b;
        if (fs_size(fe[w->sel].name, &sz) || !(b = kmalloc(sz + 1))) r = -1;
        else { r = fs_read(fe[w->sel].name, b, sz, &got) ? -1 : fs_write(w->in, b, got, 0); kfree(b); }
    }
    files_msg(w, r ? "failed (bad name 8.3, exists, or no space)" : "done");
    if (!r) w->mode = 0;
}

/* ---------------- disks ---------------- */
static void draw_disk(struct win *w, int cx, int cy, int cw, int ch)
{
    static const char *bl[4] = { "Check", "Repair", "Format", "Refresh" };
    for (int i = 0; i < 4; i++) button(cx + 6 + i * 84, cy + 4, 80, bl[i], i == 2 && w->confirm);
    char t[100]; struct fat_geo g; int y = cy + 38;
    ksnprintf(t, sizeof t, "Boot drive 0x%02x   ATA disk: %s", BOOTINFO->boot_drive, ata_present() ? "found" : "none");
    gfx_text(cx + 10, y, t, C_TXT, -1); y += 20;
    if (ata_present()) { ksnprintf(t, sizeof t, "Size: %u sectors (%u KB)", ata_sectors(), ata_sectors() / 2); gfx_text(cx + 10, y, t, C_TXT, -1); y += 20; }
    u32 used = 0, tot = fs_total_bytes();
    if (fs_on_disk() && !fat12_geo(&g)) {
        ksnprintf(t, sizeof t, "File system: FAT12   label: \"%s\"   cluster %u bytes", g.label, g.spc * 512); gfx_text(cx + 10, y, t, C_TXT, -1); y += 24;
        gfx_text(cx + 10, y, "Layout (sectors)", C_DIM, -1); y += 18;
        ksnprintf(t, sizeof t, "boot 0 | stage2 1-%u | FAT %u-%u", g.reserved - 1, g.fat_lba, g.root_lba - 1); gfx_text(cx + 10, y, t, C_TXT, -1); y += 18;
        ksnprintf(t, sizeof t, "root dir %u-%u | data %u-%u", g.root_lba, g.data_lba - 1, g.data_lba, g.total_sectors - 1); gfx_text(cx + 10, y, t, C_TXT, -1); y += 24;
        used = (g.clusters - g.free_clusters) * g.spc * 512;
        ksnprintf(t, sizeof t, "Clusters: %u total, %u used, %u free", g.clusters, g.clusters - g.free_clusters, g.free_clusters); gfx_text(cx + 10, y, t, C_TXT, -1); y += 24;
    } else { gfx_text(cx + 10, y, "File system: RAM disk (erased on reboot)", C_TXT, -1); y += 24; used = tot - fs_free_bytes(); }
    ksnprintf(t, sizeof t, "Space: %u KB used of %u KB", used / 1024, tot / 1024); gfx_text(cx + 10, y, t, C_TXT, -1); y += 20;
    gfx_rect(cx + 10, y, cw - 20, 14, 0x0F0E1A);
    gfx_rect(cx + 10, y, tot ? (int)((used * (u32)(cw - 20)) / tot) : 0, 14, C_TITLE); y += 30;
    gfx_text(cx + 10, y, w->msg, w->confirm ? C_ERR : C_OK, -1);
    (void)ch;
}

static void disk_click(struct win *w, int px, int py)
{
    if (py < 4 || py >= 26 || px < 6) return;
    int b = (px - 6) / 84;
    if (b > 3 || (px - 6) % 84 > 80) return;
    u32 files, errs, lost, fixed;
    if (b != 2) w->confirm = 0;
    if (b == 0 || b == 1) {
        if (!fs_on_disk()) { strncpy0(w->msg, "needs the FAT12 disk", sizeof w->msg); return; }
        if (fat12_check(b == 1, &files, &errs, &lost, &fixed)) { strncpy0(w->msg, "disk error", sizeof w->msg); return; }
        ksnprintf(w->msg, sizeof w->msg, "%u file(s), %u problem(s), %u lost cluster(s)%s", files, errs, lost, b == 1 ? ", repaired" : (errs || lost) ? " - click Repair" : " - clean");
    } else if (b == 2) {
        if (!w->confirm) { w->confirm = 1; strncpy0(w->msg, "This ERASES all files (KERNEL.BIN stays). Click Format again.", sizeof w->msg); }
        else {
            struct fs_entry fe[32]; int n = fs_list(fe, 32), gone = 0;
            for (int i = 0; i < n; i++) if (strcmp(fe[i].name, "KERNEL.BIN") && !fs_remove(fe[i].name)) gone++;
            w->confirm = 0; ksnprintf(w->msg, sizeof w->msg, "erased %d file(s)", gone);
        }
    } else strncpy0(w->msg, "refreshed", sizeof w->msg);
}

/* ---------------- editor ---------------- */
static void open_editor(const char *name)
{
    int i = open_win(A_EDIT);
    if (i < 0) return;
    struct win *w = &wins[i];
    if (!w->buf) { close_win(i); return; }
    strncpy0(w->name, name, sizeof w->name);
    ksnprintf(w->title, sizeof w->title, "Editor - %s", name);
    u32 got = 0; u32 sz;
    w->len = 0;
    if (!fs_size(name, &sz)) {
        if (sz > 8000) { strncpy0(w->msg, "file too big for the editor (8 KB max)", sizeof w->msg); sz = 8000; }
        fs_read(name, w->buf, sz, &got);
        u32 o = 0; for (u32 k = 0; k < got; k++) if (w->buf[k] != '\r') w->buf[o++] = w->buf[k];
        w->len = o;
    }
    w->buf[w->len] = 0; w->cur = 0; w->scroll = 0; w->dirty = 0;
    gui_dirty = 1;
}

static void draw_edit(struct win *w, int cx, int cy, int cw, int ch)
{
    button(cx + 6, cy + 4, 64, "Save", w->dirty);
    gfx_text(cx + 80, cy + 8, w->dirty ? "modified (Ctrl+S saves)" : w->msg[0] ? w->msg : "saved", w->dirty ? C_ERR : C_OK, -1);
    int cols = (cw - 12) / 8, rows = (ch - 40) / 16;
    int line = 0, col = 0, cl = 0, cc = 0;
    for (int i = 0; i < (int)w->cur; i++) { if (w->buf[i] == '\n') { cl++; cc = 0; } else cc++; }
    if (cl < w->scroll) w->scroll = cl;
    if (cl >= w->scroll + rows) w->scroll = cl - rows + 1;
    gfx_rect(cx + 4, cy + 32, cw - 8, ch - 36, 0x0F0E1A);
    for (u32 i = 0; i <= w->len; i++) {
        if (line >= w->scroll && line < w->scroll + rows) {
            int px = cx + 8 + col * 8, py = cy + 36 + (line - w->scroll) * 16;
            if ((int)i == w->cur) gfx_rect(px, py, 2, 16, C_TXT);
            if (i < w->len && w->buf[i] != '\n' && col < cols) { char s[2] = { w->buf[i], 0 }; gfx_text(px, py, s, C_TXT, -1); }
        }
        if (i < w->len && w->buf[i] == '\n') { line++; col = 0; } else col++;
    }
    (void)cc;
}

static void edit_save(struct win *w)
{
    int r = fs_write(w->name, w->buf, w->len, 0);
    if (r) strncpy0(w->msg, "save failed", sizeof w->msg); else { w->dirty = 0; strncpy0(w->msg, "saved", sizeof w->msg); }
}

static void edit_key(struct win *w, int k)
{
    if (!w->buf) return;
    int c = w->cur;
    if (k == 19) { edit_save(w); return; }
    if (k == KEY_LEFT) { if (c > 0) w->cur--; }
    else if (k == KEY_RIGHT) { if (c < (int)w->len) w->cur++; }
    else if (k == KEY_HOME) { while (w->cur > 0 && w->buf[w->cur - 1] != '\n') w->cur--; }
    else if (k == KEY_END) { while (w->cur < (int)w->len && w->buf[w->cur] != '\n') w->cur++; }
    else if (k == KEY_UP || k == KEY_DOWN) {
        int col = 0, p = c; while (p > 0 && w->buf[p - 1] != '\n') { p--; col++; }
        if (k == KEY_UP) {
            if (p == 0) return;
            int q = p - 1, pc = 0; while (q > 0 && w->buf[q - 1] != '\n') { q--; pc++; }
            w->cur = q + (col < pc ? col : pc);
        } else {
            int e = c; while (e < (int)w->len && w->buf[e] != '\n') e++;
            if (e >= (int)w->len) return;
            int q = e + 1, n = 0; while (q + n < (int)w->len && w->buf[q + n] != '\n' && n < col) n++;
            w->cur = q + n;
        }
    }
    else if (k == '\b') { if (c > 0) { memmove(w->buf + c - 1, w->buf + c, w->len - c); w->len--; w->cur--; w->dirty = 1; } }
    else if (k == KEY_DEL) { if (c < (int)w->len) { memmove(w->buf + c, w->buf + c + 1, w->len - c - 1); w->len--; w->dirty = 1; } }
    else if ((k == '\n' || (k >= 32 && k < 127) || k == '\t') && w->len < 8000) {
        memmove(w->buf + c + 1, w->buf + c, w->len - c); w->buf[c] = k == '\t' ? ' ' : k; w->len++; w->cur++; w->dirty = 1;
    }
    w->buf[w->len] = 0;
}

/* ---------------- browser ---------------- */
static void fetch_task(void *arg)
{
    struct win *w = &wins[(int)arg];
    char url[100], info[120], title[60], *body = NULL; u32 len = 0;
    strncpy0(url, w->in, sizeof url);
    int st = http_get(url, &body, &len, info, sizeof info);
    if (!wins[(int)arg].used || !w->buf) { if (body) kfree(body); w->fetching = 0; return; }
    if (st < 0) { ksnprintf(w->msg, sizeof w->msg, "Error: %s", info); w->buf[0] = 0; w->len = 0; }
    else {
        w->len = html_to_text(body, len, w->buf, 64 * 1024, title, sizeof title);
        ksnprintf(w->msg, sizeof w->msg, "%s", info);
        if (title[0]) ksnprintf(w->title, sizeof w->title, "Browser - %s", title);
        kfree(body);
    }
    w->scroll = 0; w->fetching = 0; gui_dirty = 1;
}

static void web_go(struct win *w, int idx)
{
    if (w->fetching) return;
    /* a plain number follows a numbered link from the current page */
    int num = 0, digits = 1;
    for (int i = 0; i < w->inlen; i++) { if (w->in[i] < '0' || w->in[i] > '9') digits = 0; else num = num * 10 + w->in[i] - '0'; }
    if (digits && w->inlen && w->len) {
        char key[12]; ksnprintf(key, sizeof key, "\n[%d] ", num);
        char *p = w->buf; int found = 0;
        for (u32 i = 0; i + 6 < w->len; i++) if (!strncmp(w->buf + i, key, strlen(key)) && i > 5) { p = w->buf + i + strlen(key); found = 1; }
        if (found) {
            int k = 0; while (*p && *p != '\n' && k < 98) w->in[k++] = *p++;
            w->in[k] = 0; w->inlen = k;
            if (w->in[0] == '/') { strncpy0(w->msg, "relative links are not followed yet", sizeof w->msg); return; }
        }
    }
    if (strncmp(w->in, "http", 4)) { char t[100]; ksnprintf(t, sizeof t, "http://%s", w->in); strncpy0(w->in, t, sizeof w->in); w->inlen = strlen(w->in); }
    w->fetching = 1; strncpy0(w->msg, "Loading...", sizeof w->msg);
    if (task_create("fetch", fetch_task, (void *)idx) < 0) { w->fetching = 0; strncpy0(w->msg, "no free task", sizeof w->msg); }
}

static void draw_web(struct win *w, int cx, int cy, int cw, int ch)
{
    field(cx + 6, cy + 4, cw - 70, w->in, 1);
    button(cx + cw - 58, cy + 4, 52, "Go", w->fetching);
    gfx_text(cx + 8, cy + 32, w->msg, w->fetching ? C_DIM : C_OK, -1);
    int rows = (ch - 54) / 16, cols = (cw - 16) / 8;
    gfx_rect(cx + 4, cy + 50, cw - 8, ch - 54, 0x0F0E1A);
    if (!w->buf || !w->len) return;
    int line = 0, col = 0;
    for (u32 i = 0; i < w->len; i++) {
        char c = w->buf[i];
        if (line >= w->scroll && line < w->scroll + rows && c != '\n' && col < cols) {
            char s[2] = { c, 0 }; gfx_text(cx + 8 + col * 8, cy + 52 + (line - w->scroll) * 16, s, C_TXT, -1);
        }
        if (c == '\n') { line++; col = 0; } else col++;
        if (line >= w->scroll + rows) break;
    }
}

static void web_key(struct win *w, int idx, int k)
{
    if (k == '\n') web_go(w, idx);
    else if (k == '\b') { if (w->inlen) w->in[--w->inlen] = 0; }
    else if (k >= 32 && k < 127 && w->inlen < 96) { w->in[w->inlen++] = k; w->in[w->inlen] = 0; }
    else if (k == KEY_UP && w->scroll > 0) w->scroll--;
    else if (k == KEY_DOWN) w->scroll++;
    else if (k == KEY_HOME) w->scroll = 0;
}

void gui_open_url(const char *url)
{
    int i = open_win(A_WEB);
    if (i < 0) return;
    struct win *w = &wins[i];
    strncpy0(w->in, url, sizeof w->in); w->inlen = strlen(w->in);
    web_go(w, i);
}

/* ---------------- monitor ---------------- */
static void draw_mon(struct win *w, int cx, int cy, int cw, int ch)
{
    char t[100]; int y = cy + 8; struct task_info ti; static const char *st[4] = { "free", "ready", "sleep", "dead" };
    (void)w; (void)ch;
    gfx_text(cx + 10, y, "TASKS", C_DIM, -1); y += 18;
    gfx_text(cx + 10, y, "ID  NAME        STATE   CPU      PROGRESS", C_DIM, -1); y += 18;
    for (int i = 0; i < 8; i++) if (!task_get(i, &ti)) { ksnprintf(t, sizeof t, "%-3d %-11s %-7s %-8u %u", ti.id, ti.name, st[ti.state], ti.cpu, ti.progress); gfx_text(cx + 10, y, t, C_TXT, -1); y += 16; }
    y += 10; gfx_text(cx + 10, y, "SYSTEM", C_DIM, -1); y += 18;
    int h, m, s, d, mo, yr; rtc_read(&h, &m, &s, &d, &mo, &yr); u32 up = ticks() / 100;
    ksnprintf(t, sizeof t, "Uptime %u:%02u:%02u   Clock %04d-%02d-%02d %02d:%02d", up / 3600, (up / 60) % 60, up % 60, yr, mo, d, h, m); gfx_text(cx + 10, y, t, C_TXT, -1); y += 18;
    ksnprintf(t, sizeof t, "RAM %u MB, %u MB free   Heap %u/%u KB", mem_top() >> 20, pmm_free_pages() / 256, heap_used() / 1024, heap_total() / 1024); gfx_text(cx + 10, y, t, C_TXT, -1); y += 18;
    char ipb[16]; ip_str(net.ip, ipb);
    ksnprintf(t, sizeof t, "Network: %s   IP %s", net.up ? "up" : "not configured", net.up ? ipb : "-"); gfx_text(cx + 10, y, t, C_TXT, -1); y += 18;
    ksnprintf(t, sizeof t, "Screen %dx%d   Mouse %s   PCI %d   USB %d", W, H, mouse_ok() ? "ok" : "none", pci_count(), usb_count()); gfx_text(cx + 10, y, t, C_TXT, -1);
    (void)cw;
}

/* ---------------- drawing and events ---------------- */
static void draw_win(int i, int focus)
{
    struct win *w = &wins[i];
    gfx_rect(w->x, w->y, w->w, w->h, focus ? C_TITLE : C_BORDER);
    gfx_rect(w->x + 1, w->y + 1, w->w - 2, TB - 1, focus ? C_TITLE : C_TITLE_IN);
    gfx_text(w->x + 8, w->y + 3, w->title, 0xFFFFFF, -1);
    gfx_rect(w->x + w->w - 22, w->y + 3, 18, 16, C_ERR);
    gfx_text(w->x + w->w - 18, w->y + 3, "x", 0xFFFFFF, -1);
    int cx = w->x + 1, cy = w->y + TB, cw = w->w - 2, ch = w->h - TB - 1;
    gfx_rect(cx, cy, cw, ch, C_WIN);
    switch (w->app) {
    case A_TERM: draw_term(w, cx, cy); break;
    case A_FILES: draw_files(w, cx, cy, cw, ch); break;
    case A_DISK: draw_disk(w, cx, cy, cw, ch); break;
    case A_EDIT: draw_edit(w, cx, cy, cw, ch); break;
    case A_WEB: draw_web(w, cx, cy, cw, ch); break;
    case A_MON: draw_mon(w, cx, cy, cw, ch); break;
    }
}

static void compose(void)
{
    gfx_rect(0, 0, W, H, C_BG);
    static const u32 ch[7] = { 0xE5484D, 0xF0803C, 0xF5D90A, 0x46C26B, 0x3CC8E8, 0x5B6CFF, 0xC06CFF };
    for (int i = 0; i < 7; i++) gfx_rect(i * (W / 7), 0, W / 7 + 1, 4, ch[i]);
    gfx_text(W - 150, 12, "CHAKRA OS " CHAKRA_VERSION, C_BORDER, -1);
    for (int k = 0; k < nz; k++) draw_win(zo[k], k == nz - 1);
    gfx_rect(0, H - TASKH, W, TASKH, C_TASK);
    gfx_rect(0, H - TASKH, W, 1, C_BORDER);
    int top = nz ? zo[nz - 1] : -1;
    for (int a = 0; a < NAPPS; a++) {
        int on = 0; for (int i = 0; i < 8; i++) if (wins[i].used && wins[i].app == a && i == top) on = 1;
        button(6 + a * 94, H - TASKH + 4, 90, app_name[a], on);
    }
    int h, m, s, d, mo, y; rtc_read(&h, &m, &s, &d, &mo, &y);
    char t[16]; ksnprintf(t, sizeof t, "%02d:%02d:%02d", h, m, s);
    gfx_text(W - 76, H - TASKH + 8, t, C_TXT, -1);
}

static void on_click(void)
{
    if (my >= H - TASKH) {
        for (int a = 0; a < NAPPS; a++) if (hit(mx, my, 6 + a * 94, H - TASKH + 4, 90, 22)) { open_win(a); }
        return;
    }
    for (int k = nz - 1; k >= 0; k--) {
        int i = zo[k]; struct win *w = &wins[i];
        if (!hit(mx, my, w->x, w->y, w->w, w->h)) continue;
        raise_win(i);
        if (my < w->y + TB) {
            if (hit(mx, my, w->x + w->w - 22, w->y + 3, 18, 16)) close_win(i);
            else { drag = i; ddx = mx - w->x; ddy = my - w->y; }
        } else {
            int px = mx - (w->x + 1), py = my - (w->y + TB), cw = w->w - 2, ch = w->h - TB - 1;
            if (w->app == A_FILES) files_click(w, px, py, cw, ch);
            else if (w->app == A_DISK) disk_click(w, px, py);
            else if (w->app == A_EDIT && py < 28 && px < 70) edit_save(w);
            else if (w->app == A_WEB && py < 28 && px > cw - 58) web_go(w, i);
        }
        return;
    }
}

static void gui_task(void *a)
{
    (void)a;
    u32 last = 0;
    int moved_only = 0;
    gui_dirty = 1;
    for (;;) {
        int k;
        while ((k = input_nb()) >= 0) {
            gui_dirty = 1;
            if (!nz) continue;
            int i = zo[nz - 1]; struct win *w = &wins[i];
            switch (w->app) {
            case A_TERM: tpush(k); break;
            case A_FILES: files_key(w, k); break;
            case A_EDIT: edit_key(w, k); break;
            case A_WEB: web_key(w, i, k); break;
            }
        }
        int dx, dy, b;
        if (mouse_poll(&dx, &dy, &b)) {
            mx += dx; my += dy;
            if (mx < 0) mx = 0;
            if (my < 0) my = 0;
            if (mx >= W) mx = W - 1;
            if (my >= H) my = H - 1;
            if (drag >= 0 && wins[drag].used && (b & 1)) { wins[drag].x = mx - ddx; wins[drag].y = my - ddy; gui_dirty = 1; }
            else moved_only = 1;
        }
        mbtn = b;
        if ((mbtn & 1) && !(pbtn & 1)) { on_click(); gui_dirty = 1; }
        if (!(mbtn & 1)) drag = -1;
        pbtn = mbtn;
        if (ticks() - last >= 50) { last = ticks(); gui_dirty = 1; }
        if (gui_dirty) { gui_dirty = 0; moved_only = 0; compose(); gfx_flush(); gfx_cursor(mx, my, 0); }
        else if (moved_only) { moved_only = 0; gfx_cursor(mx, my, 1); }
        task_sleep(10);
    }
}

void gui_start(void)
{
    if (gfx_init()) return;
    W = gfx_w(); H = gfx_h();
    mouse_init();
    con_use_terminal();
    active = 1;
    mx = W / 2; my = H / 2;
    open_win(A_TERM);
    task_create("desktop", gui_task, NULL);
}
