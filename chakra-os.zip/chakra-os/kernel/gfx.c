/* Framebuffer graphics: back buffer, rectangles, text (BIOS 8x16 font), mouse cursor. */
#include "chakra.h"

static u32 *fb, *bb;
static int W, H, pitch4, active;
static int cur_x = -100, cur_y = -100;

static const u32 pal[16] = { 0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xAA5500, 0xAAAAAA,
    0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF };
u32 vga_rgb(int c) { return pal[c & 15]; }
int gfx_on(void) { return active; }
int gfx_w(void) { return W; }
int gfx_h(void) { return H; }

int gfx_init(void)
{
    if (!BOOTINFO->gfx || BOOTINFO->gbpp != 32) return -1;
    W = BOOTINFO->gw; H = BOOTINFO->gh; pitch4 = BOOTINFO->gpitch / 4;
    fb = (u32 *)BOOTINFO->fb;
    if (paging_map(BOOTINFO->fb, BOOTINFO->gpitch * H)) return -1;
    u32 pages = (W * H * 4 + 4095) / 4096;
    bb = (u32 *)pmm_alloc_contig(pages);
    if (!bb) return -1;
    memset(bb, 0, pages * 4096);
    active = 1;
    return 0;
}

void gfx_rect(int x, int y, int w, int h, u32 c)
{
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > W) w = W - x;
    if (y + h > H) h = H - y;
    if (w <= 0 || h <= 0) return;
    for (int j = 0; j < h; j++) {
        u32 *p = bb + (y + j) * W + x; int n = w;
        __asm__ volatile("rep stosl" : "+D"(p), "+c"(n) : "a"(c) : "memory");
    }
}

void gfx_frame(int x, int y, int w, int h, u32 c)
{
    gfx_rect(x, y, w, 1, c); gfx_rect(x, y + h - 1, w, 1, c);
    gfx_rect(x, y, 1, h, c); gfx_rect(x + w - 1, y, 1, h, c);
}

static void glyph(int x, int y, u8 ch, u32 fg, int bg)
{
    if (x < 0 || y < 0 || x + 8 > W || y + 16 > H) return;
    const u8 *g = g_font + ch * 16;
    for (int r = 0; r < 16; r++) {
        u32 *p = bb + (y + r) * W + x; u8 bits = g[r];
        for (int c = 0; c < 8; c++) {
            if (bits & (0x80 >> c)) p[c] = fg; else if (bg >= 0) p[c] = (u32)bg;
        }
    }
}

void gfx_text(int x, int y, const char *s, u32 fg, int bg)
{
    for (; *s; s++, x += 8) glyph(x, y, (u8)*s, fg, bg);
}

static const u16 curs[16] = { 0x8000, 0xC000, 0xE000, 0xF000, 0xF800, 0xFC00, 0xFE00, 0xFF00,
                              0xFF80, 0xFC00, 0xDC00, 0x8E00, 0x0E00, 0x0700, 0x0700, 0x0000 };
static const u16 curm[16] = { 0xC000, 0xE000, 0xF000, 0xF800, 0xFC00, 0xFE00, 0xFF00, 0xFF80,
                              0xFFC0, 0xFFC0, 0xFE00, 0xFF00, 0x1F00, 0x0F80, 0x0F80, 0x0700 };

static void draw_cursor(int x, int y)
{
    for (int r = 0; r < 16; r++)
        for (int c = 0; c < 10; c++) {
            int px = x + c, py = y + r;
            if (px < 0 || py < 0 || px >= W || py >= H) continue;
            if (curm[r] & (0x8000 >> c)) fb[py * pitch4 + px] = (curs[r] & (0x8000 >> c)) ? 0xFFFFFF : 0x000000;
        }
}
static void restore_under(int x, int y)
{
    for (int r = 0; r < 16; r++) {
        int py = y + r; if (py < 0 || py >= H) continue;
        for (int c = 0; c < 10; c++) { int px = x + c; if (px >= 0 && px < W) fb[py * pitch4 + px] = bb[py * W + px]; }
    }
}

void gfx_flush(void)
{
    for (int y = 0; y < H; y++) {
        u32 *d = fb + y * pitch4, *s = bb + y * W; int n = W;
        __asm__ volatile("rep movsl" : "+D"(d), "+S"(s), "+c"(n) :: "memory");
    }
    draw_cursor(cur_x, cur_y);
}

/* move the pointer without redrawing the whole screen */
void gfx_cursor(int x, int y, int redraw_old)
{
    if (redraw_old) restore_under(cur_x, cur_y);
    cur_x = x; cur_y = y;
    draw_cursor(x, y);
}
