/* Realtek RTL8139 network card driver (PIO). QEMU: -nic user,model=rtl8139 */
#include "chakra.h"
#define RX_LEN 8192
static u16 io;
static u8 *rxbuf;
static u32 rxoff;
static u8 *txbuf[4];
static int txcur, found;

const char *nic_name(void) { return found ? "Realtek RTL8139" : "none"; }

int nic_init(void)
{
    if (found) return 0;
    struct pci_dev *d = pci_find_id(0x10EC, 0x8139);
    if (!d) return -1;
    pci_enable(d);
    io = d->bar[0] & 0xFFFC;
    outb(io + 0x52, 0);                      /* power on */
    outb(io + 0x37, 0x10);                   /* reset */
    for (int t = 0; t < 100000 && (inb(io + 0x37) & 0x10); t++) ;
    rxbuf = kmalloc(RX_LEN + 16 + 1536);
    for (int i = 0; i < 4; i++) txbuf[i] = kmalloc(1792);
    if (!rxbuf || !txbuf[0] || !txbuf[1] || !txbuf[2] || !txbuf[3]) return -1;
    memset(rxbuf, 0, RX_LEN + 16 + 1536);
    outl(io + 0x30, (u32)rxbuf);
    outw(io + 0x3C, 0);                      /* no interrupts: we poll */
    outl(io + 0x44, 0x8F);                   /* accept broadcast+multicast+physical, WRAP */
    outb(io + 0x37, 0x0C);                   /* RX + TX enable */
    for (int i = 0; i < 6; i++) net.mac[i] = inb(io + i);
    rxoff = 0; txcur = 0; found = 1;
    return 0;
}

int nic_send(const void *buf, u32 len)
{
    if (!found || len > 1514) return -1;
    if (len < 60) len = 60;
    u32 f = irq_save();
    u8 *b = txbuf[txcur];
    memset(b, 0, 64);
    memcpy(b, buf, len < 1514 ? len : 1514);
    for (int t = 0; t < 100000; t++) {          /* wait until the card is done with this buffer */
        u32 sd = inl(io + 0x10 + txcur * 4);
        if (!sd || (sd & 0x2000) || (sd & 0x8000)) break;
    }
    outl(io + 0x20 + txcur * 4, (u32)b);
    outl(io + 0x10 + txcur * 4, len);
    txcur = (txcur + 1) & 3;
    irq_restore(f);
    return 0;
}

int nic_recv(void *buf, u32 max)
{
    if (!found || (inb(io + 0x37) & 1)) return 0;     /* buffer empty */
    u8 *p = rxbuf + rxoff;
    u16 st = p[0] | (p[1] << 8), len = p[2] | (p[3] << 8);
    int n = 0;
    if ((st & 1) && len >= 18 && len <= 1518) {
        n = len - 4;
        if ((u32)n > max) n = max;
        memcpy(buf, p + 4, n);
    }
    rxoff = (rxoff + len + 4 + 3) & ~3u;
    rxoff %= RX_LEN;
    outw(io + 0x38, (u16)(rxoff - 16));
    if (!(st & 1) || len < 18 || len > 1518) { outb(io + 0x37, 0x04); outb(io + 0x37, 0x0C); outl(io + 0x44, 0x8F); rxoff = 0; outl(io + 0x30, (u32)rxbuf); return 0; }
    return n;
}
