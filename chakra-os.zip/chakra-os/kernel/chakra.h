#ifndef CHAKRA_H
#define CHAKRA_H
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef int i32;
typedef u32 size_t;
#define NULL ((void *)0)
#define CHAKRA_VERSION "1.0.0"

static inline void outb(u16 p, u8 v) { __asm__ volatile("outb %0,%1" ::"a"(v), "Nd"(p)); }
static inline u8 inb(u16 p) { u8 v; __asm__ volatile("inb %1,%0" : "=a"(v) : "Nd"(p)); return v; }
static inline void outw(u16 p, u16 v) { __asm__ volatile("outw %0,%1" ::"a"(v), "Nd"(p)); }
static inline u16 inw(u16 p) { u16 v; __asm__ volatile("inw %1,%0" : "=a"(v) : "Nd"(p)); return v; }
static inline void outl(u16 p, u32 v) { __asm__ volatile("outl %0,%1" ::"a"(v), "Nd"(p)); }
static inline u32 inl(u16 p) { u32 v; __asm__ volatile("inl %1,%0" : "=a"(v) : "Nd"(p)); return v; }
static inline u32 irq_save(void) { u32 f; __asm__ volatile("pushf; pop %0; cli" : "=r"(f)::"memory"); return f; }
static inline void irq_restore(u32 f) { __asm__ volatile("push %0; popf" ::"r"(f) : "memory", "cc"); }

enum { BLACK, BLUE, GREEN, CYAN, RED, MAGENTA, BROWN, LGREY, DGREY, LBLUE, LGREEN,
       LCYAN, LRED, LMAGENTA, YELLOW, WHITE };

/* ---- boot information left by stage 2 at 0x500 ---- */
struct e820_entry { u32 base_lo, base_hi, len_lo, len_hi, type, acpi; };
struct bootinfo { u32 magic, total_kb, boot_drive, e820_count; struct e820_entry e820[20]; u32 gfx, fb, gw, gh, gpitch, gbpp; };
extern struct bootinfo g_boot;   /* copied from 0x500 at start, before page 0 is unmapped */
#define BOOTINFO (&g_boot)
void bootinfo_init(void);

/* ---- console: VGA rows 1-24 (row 0 = status bar), mirrored to serial ---- */
void vga_init(void);
void putc(char c);
void puts(const char *s);
void clear_screen(void);
void set_color(u8 fg, u8 bg);
u8 get_fg(void);
u8 get_bg(void);
void con_left(void);
void con_right(void);
void con_capture_start(char *buf, u32 max);
u32 con_capture_end(void);
void vga_put(int row, int col, u8 ch, u8 attr);
void vga_text(int row, int col, const char *s, u8 attr);
void vga_fill(int row, int col, int h, int w, u8 ch, u8 attr);
void vga_cursor_visible(int v);
void kprintf(const char *fmt, ...);
int ksnprintf(char *buf, size_t max, const char *fmt, ...);

/* ---- serial ---- */
int serial_init(void);
void serial_putc(char c);
int serial_getc_nb(void);

/* ---- input ---- */
#define KEY_UP 0x101
#define KEY_DOWN 0x102
#define KEY_LEFT 0x103
#define KEY_RIGHT 0x104
#define KEY_HOME 0x105
#define KEY_END 0x106
#define KEY_DEL 0x107
void kbd_init(void);
void kbd_irq(void);
int input_nb(void);
int getchar(void);

/* ---- interrupts, timer ---- */
void idt_init(void);
void timer_init(void);
u32 ticks(void);
void sleep_ms(u32 ms);

/* ---- memory manager ---- */
void mm_init(void);
u32 pmm_alloc(void);
void pmm_free(u32 addr);
u32 pmm_total_pages(void);
u32 pmm_free_pages(void);
u32 mem_top(void);
int paging_enabled(void);
u32 pmm_alloc_contig(u32 n);
int paging_map(u32 phys, u32 size);
void *kmalloc(u32 n);
void kfree(void *p);
u32 heap_total(void);
u32 heap_used(void);

/* ---- tasks ---- */
struct task_info { int id; char name[16]; int state; u32 cpu; u32 progress; };
void sched_init(void);
int task_create(const char *name, void (*fn)(void *), void *arg);
void task_sleep(u32 ms);
void task_exit(void);
int task_kill(int id);
int task_get(int idx, struct task_info *out);
void task_set_progress(u32 p);
void sched_tick(void);
int task_current(void);

/* ---- disk ---- */
int ata_init(void);
int ata_present(void);
u32 ata_sectors(void);
int ata_read(u32 lba, void *buf);
int ata_write(u32 lba, const void *buf);

#define FS_MAXNAME 13
struct fs_entry { char name[FS_MAXNAME]; u32 size; };

/* ---- FAT12 (on the ATA disk) ---- */
int fat12_list(struct fs_entry *out, int max);
int fat12_size(const char *name, u32 *size);
int fat12_read(const char *name, char *buf, u32 max, u32 *len);
int fat12_write(const char *name, const char *data, u32 len);
int fat12_remove(const char *name);
int fat12_rename(const char *a, const char *b);
int fat12_mount(void);

struct fat_geo { u32 total_sectors, reserved, fats, spf, root_entries, root_secs, fat_lba, root_lba, data_lba, spc, clusters, free_clusters; char label[12]; };
int fat12_geo(struct fat_geo *g);
int fat12_stat(const char *name, u32 *first, u32 *clusters, u32 *date, u32 *time);
int fat12_check(int repair, u32 *files, u32 *errors, u32 *lost, u32 *fixed);
int fat12_label(const char *set, char *out);
u32 fat12_total_bytes(void);
u32 fat12_free_bytes(void);

/* ---- file system front end (FAT12 if a disk is found, else RAM) ---- */
void fs_init(void);
int fs_on_disk(void);
int fs_norm(const char *in, char out[FS_MAXNAME]);
int fs_list(struct fs_entry *out, int max);
int fs_read(const char *name, char *buf, u32 max, u32 *len);
int fs_size(const char *name, u32 *size);
int fs_write(const char *name, const char *data, u32 len, int append);
int fs_remove(const char *name);
int fs_rename(const char *a, const char *b);
u32 fs_total_bytes(void);
u32 fs_free_bytes(void);

/* ---- RTC ---- */
void rtc_read(int *h, int *m, int *s, int *d, int *mo, int *y);

/* ---- lib ---- */
size_t strlen(const char *s);
int strcmp(const char *a, const char *b);
int strncmp(const char *a, const char *b, size_t n);
char *strncpy0(char *d, const char *s, size_t n);
void *memset(void *d, int c, size_t n);
void *memcpy(void *d, const void *s, size_t n);
void *memmove(void *d, const void *s, size_t n);
int memcmp(const void *a, const void *b, size_t n);

/* ---- mouse + graphics + desktop ---- */
void mouse_init(void);
void mouse_irq(void);
void mouse_byte(u8 b);
int mouse_poll(int *dx, int *dy, int *btn);
int mouse_ok(void);
extern u8 g_font[4096];
int gfx_init(void);
int gfx_on(void);
int gfx_w(void);
int gfx_h(void);
void gfx_rect(int x, int y, int w, int h, u32 c);
void gfx_frame(int x, int y, int w, int h, u32 c);
void gfx_text(int x, int y, const char *s, u32 fg, int bg);
void gfx_flush(void);
void gfx_cursor(int x, int y, int redraw_old);
u32 vga_rgb(int c);
void term_state(u16 **cells, int *cx, int *cy, int *rows);
extern volatile int gui_dirty;
int gui_active(void);
int gui_term_pop(void);
void gui_start(void);
void gui_open_url(const char *url);

/* ---- UI ---- */
void ui_start_status(void);
void ui_run(void);

/* ---- PCI ---- */
struct pci_dev { u8 bus, dev, fn, irq; u16 vendor, device; u8 class, sub, prog; u32 bar[6]; };
int pci_scan(void);
int pci_count(void);
struct pci_dev *pci_get(int i);
struct pci_dev *pci_find_class(u8 cls, u8 sub, int nth);
struct pci_dev *pci_find_id(u16 vendor, u16 device);
u32 pci_read32(struct pci_dev *d, u8 off);
void pci_write32(struct pci_dev *d, u8 off, u32 v);
void pci_enable(struct pci_dev *d);
const char *pci_class_name(u8 cls, u8 sub);

/* ---- network ---- */
#define IP4(a, b, c, d) (((u32)(a) << 24) | ((u32)(b) << 16) | ((u32)(c) << 8) | (u32)(d))
struct netcfg { u8 mac[6]; u32 ip, mask, gw, dns; int nic, up; };
extern struct netcfg net;
int nic_init(void);
int nic_send(const void *buf, u32 len);
int nic_recv(void *buf, u32 max);
const char *nic_name(void);
int net_ensure(void);
int net_dhcp(void);
void net_static(void);
int net_ping(u32 ip, u32 timeout_ms, u32 *rtt_ms);
int net_resolve(const char *name, u32 *ip);
void ip_str(u32 ip, char *out);
int tcp_connect(u32 ip, u16 port);
int tcp_send(int h, const void *d, u32 n);
int tcp_recv(int h, void *buf, u32 max, u32 timeout_ms);
void tcp_close(int h);
int http_get(const char *url, char **body, u32 *len, char *info, u32 infomax);
u32 html_to_text(const char *html, u32 n, char *out, u32 max, char *title, u32 tmax);
int net_command(int argc, char **argv);
int disk_command(int argc, char **argv);
int io_command(int argc, char **argv);
int usb_command(int argc, char **argv);
int usb_count(void);

void print_banner(void);
void shell_run(void);
#endif
