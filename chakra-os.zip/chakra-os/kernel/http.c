/* HTTP/1.0 client (plain http only) and an HTML-to-text converter for the web viewer. */
#include "chakra.h"

static char lowc(char c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }

static const char *find_hdr(const char *h, const char *name)
{
    u32 nl = strlen(name);
    for (const char *p = h; *p; ) {
        u32 i = 0;
        while (i < nl && lowc(p[i]) == name[i]) i++;
        if (i == nl && p[nl] == ':') { p += nl + 1; while (*p == ' ') p++; return p; }
        while (*p && *p != '\n') p++;
        if (*p) p++;
    }
    return NULL;
}

static int parse_url(const char *url, char *host, u32 hmax, u16 *port, char *path, u32 pmax)
{
    if (!strncmp(url, "http://", 7)) url += 7;
    else if (!strncmp(url, "https://", 8)) return -10;
    u32 i = 0;
    while (*url && *url != '/' && *url != ':' && i + 1 < hmax) host[i++] = *url++;
    host[i] = 0;
    *port = 80;
    if (*url == ':') { url++; u32 p = 0; while (*url >= '0' && *url <= '9') p = p * 10 + (*url++ - '0'); if (!p || p > 65535) return -1; *port = p; }
    if (*url == '/') strncpy0(path, url, pmax); else strncpy0(path, "/", pmax);
    return host[0] ? 0 : -1;
}

/* returns the HTTP status (>0) with *body = malloc'd buffer starting with the body, or a negative error */
int http_get(const char *url0, char **body, u32 *len, char *info, u32 imax)
{
    char url[300], host[100], path[200], loc[300];
    strncpy0(url, url0, sizeof url);
    for (int hop = 0; hop < 4; hop++) {
        u16 port;
        int r = parse_url(url, host, sizeof host, &port, path, sizeof path);
        if (r == -10) { ksnprintf(info, imax, "HTTPS (TLS) is not supported yet - only http:// works"); return -10; }
        if (r) { ksnprintf(info, imax, "bad URL"); return -1; }
        u32 ip;
        if (net_resolve(host, &ip)) { ksnprintf(info, imax, "cannot resolve %s", host); return -2; }
        int h = tcp_connect(ip, port);
        if (h < 0) { ksnprintf(info, imax, "cannot connect to %s:%u", host, port); return -3; }
        char req[500];
        int rl = ksnprintf(req, sizeof req, "GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: ChakraOS/" CHAKRA_VERSION "\r\nAccept: text/html,text/plain\r\nConnection: close\r\n\r\n", path, host);
        if (tcp_send(h, req, rl)) { tcp_close(h); ksnprintf(info, imax, "send failed"); return -4; }
        char *buf = kmalloc(96 * 1024 + 1);
        if (!buf) { tcp_close(h); ksnprintf(info, imax, "out of memory"); return -5; }
        u32 n = 0; int c;
        while (n < 96 * 1024 && (c = tcp_recv(h, buf + n, 96 * 1024 - n, 6000)) > 0) n += c;
        tcp_close(h);
        buf[n] = 0;
        if (n < 12 || strncmp(buf, "HTTP/", 5)) { kfree(buf); ksnprintf(info, imax, "no valid HTTP response"); return -6; }
        int status = 0;
        const char *sp = buf; while (*sp && *sp != ' ') sp++;
        while (*sp == ' ') sp++;
        while (*sp >= '0' && *sp <= '9') status = status * 10 + (*sp++ - '0');
        char *he = NULL;
        for (u32 i = 0; i + 3 < n; i++) if (buf[i] == '\r' && buf[i + 1] == '\n' && buf[i + 2] == '\r' && buf[i + 3] == '\n') { he = buf + i; break; }
        u32 hl = he ? (u32)(he - buf) + 4 : n;
        if (he) *he = 0;
        if (status >= 300 && status < 400) {
            const char *lv = find_hdr(buf, "location");
            if (lv) {
                u32 k = 0; while (lv[k] && lv[k] != '\r' && lv[k] != '\n' && k + 1 < sizeof loc) { loc[k] = lv[k]; k++; } loc[k] = 0;
                if (loc[0] == '/') ksnprintf(url, sizeof url, "http://%s:%u%s", host, port, loc); else strncpy0(url, loc, sizeof url);
                kfree(buf);
                continue;
            }
        }
        const char *ct = find_hdr(buf, "content-type");
        char cts[40] = ""; if (ct) { u32 k = 0; while (ct[k] && ct[k] != '\r' && ct[k] != '\n' && ct[k] != ';' && k < 39) { cts[k] = ct[k]; k++; } cts[k] = 0; }
        ksnprintf(info, imax, "%d  %s  %u bytes", status, cts[0] ? cts : "?", n - hl);
        char *b = buf + hl; u32 bl = n - hl;
        const char *te = find_hdr(buf, "transfer-encoding");
        if (te && lowc(te[0]) == 'c') {                    /* de-chunk in place */
            u32 in = 0, out = 0;
            while (in < bl) {
                u32 sz = 0;
                while (in < bl && b[in] != '\r' && b[in] != '\n') { char d = lowc(b[in]); sz = sz * 16 + (d >= 'a' ? d - 'a' + 10 : d - '0'); in++; }
                while (in < bl && (b[in] == '\r' || b[in] == '\n')) in++;
                if (!sz) break;
                if (in + sz > bl) sz = bl - in;
                memmove(b + out, b + in, sz); out += sz; in += sz;
                while (in < bl && (b[in] == '\r' || b[in] == '\n')) in++;
            }
            bl = out;
        }
        memmove(buf, b, bl); buf[bl] = 0;
        *body = buf; *len = bl;
        return status;
    }
    ksnprintf(info, imax, "too many redirects");
    return -7;
}

/* ---------- HTML to text ---------- */
struct out { char *b; u32 n, max; int col, sp; };
static void oc(struct out *o, char c)
{
    if (o->n + 1 >= o->max) return;
    if (c == '\n') { if (o->n && o->b[o->n - 1] == '\n' && o->n > 1 && o->b[o->n - 2] == '\n') return; o->col = 0; o->sp = 0; }
    else if (c == ' ') { if (o->sp || !o->col) return; o->sp = 1; }
    else o->sp = 0;
    if (c != '\n' && c != ' ') o->col++; else if (c == ' ') o->col++;
    o->b[o->n++] = c;
}
static void os(struct out *o, const char *s) { while (*s) oc(o, *s++); }

u32 html_to_text(const char *h, u32 n, char *outb, u32 max, char *title, u32 tmax)
{
    struct out o = { outb, 0, max, 0, 0 };
    char links[12][90]; int nl = 0, in_title = 0, skip = 0, ti = 0, pre = 0;
    if (title && tmax) title[0] = 0;
    for (u32 i = 0; i < n; i++) {
        char c = h[i];
        if (c == '<') {
            if (!strncmp(h + i, "<!--", 4)) { while (i + 2 < n && strncmp(h + i, "-->", 3)) i++; i += 2; continue; }
            char tag[12]; int tl = 0, closing = 0; u32 j = i + 1;
            if (j < n && h[j] == '/') { closing = 1; j++; }
            while (j < n && tl < 11 && ((h[j] >= 'a' && h[j] <= 'z') || (h[j] >= 'A' && h[j] <= 'Z') || (h[j] >= '0' && h[j] <= '9'))) tag[tl++] = lowc(h[j++]);
            tag[tl] = 0;
            u32 ts = j; while (j < n && h[j] != '>') j++;
            if (!strcmp(tag, "script") || !strcmp(tag, "style")) skip = !closing;
            else if (!strcmp(tag, "title")) in_title = !closing;
            else if (!strcmp(tag, "pre")) pre = !closing;
            else if (!strcmp(tag, "br") || !strcmp(tag, "tr") || !strcmp(tag, "div") || !strcmp(tag, "ul") || !strcmp(tag, "ol")) oc(&o, '\n');
            else if (tag[0] == 'p' && !tag[1]) { oc(&o, '\n'); oc(&o, '\n'); }
            else if (tag[0] == 'h' && tag[1] >= '1' && tag[1] <= '6') { if (!closing) { oc(&o, '\n'); oc(&o, '\n'); os(&o, "== "); } else { os(&o, " =="); oc(&o, '\n'); oc(&o, '\n'); } }
            else if (!strcmp(tag, "li") && !closing) { oc(&o, '\n'); os(&o, "* "); }
            else if (!strcmp(tag, "a")) {
                if (!closing) {
                    nl = nl < 12 ? nl : 12;
                    links[nl % 12][0] = 0;
                    for (u32 k = ts; k + 5 < j; k++)
                        if (lowc(h[k]) == 'h' && lowc(h[k + 1]) == 'r' && lowc(h[k + 2]) == 'e' && lowc(h[k + 3]) == 'f' && h[k + 4] == '=') {
                            char q = h[k + 5]; u32 s0 = k + 5; if (q == '"' || q == '\'') s0++; else q = ' ';
                            int w = 0; while (s0 < j && h[s0] != q && h[s0] != '>' && w < 88) links[nl % 12][w++] = h[s0++];
                            links[nl % 12][w] = 0; break;
                        }
                } else if (nl < 12 && links[nl][0]) { char t[8]; ksnprintf(t, sizeof t, " [%d]", nl + 1); os(&o, t); nl++; }
            }
            i = j; continue;
        }
        if (skip) continue;
        if (in_title) { if (title && ti + 1 < (int)tmax && c != '\n' && c != '\r') { title[ti++] = c; title[ti] = 0; } continue; }
        if (c == '&') {
            char e[10]; int k = 0; u32 j = i + 1;
            while (j < n && h[j] != ';' && k < 8 && h[j] != ' ') e[k++] = h[j++];
            e[k] = 0;
            if (j < n && h[j] == ';') {
                if (!strcmp(e, "amp")) c = '&'; else if (!strcmp(e, "lt")) c = '<'; else if (!strcmp(e, "gt")) c = '>';
                else if (!strcmp(e, "quot")) c = '"'; else if (!strcmp(e, "nbsp")) c = ' '; else if (!strcmp(e, "apos")) c = '\'';
                else if (e[0] == '#') { int v = 0; for (int q = 1; e[q] >= '0' && e[q] <= '9'; q++) v = v * 10 + (e[q] - '0'); c = (v >= 32 && v < 127) ? v : '?'; }
                else c = '?';
                i = j;
            }
        }
        if (c == '\r') continue;
        if (pre) { if (c == '\n') oc(&o, '\n'); else { if (o.n + 1 < o.max) { o.b[o.n++] = c; o.col++; } } continue; }
        if (c == '\n' || c == '\t') c = ' ';
        if (o.col >= 76 && c == ' ') { oc(&o, '\n'); continue; }
        if ((u8)c >= 32 && (u8)c < 127) oc(&o, c);
    }
    if (nl) { oc(&o, '\n'); oc(&o, '\n'); os(&o, "Links:\n"); for (int k = 0; k < nl; k++) { char t[100]; ksnprintf(t, sizeof t, "[%d] %s\n", k + 1, links[k]); os(&o, t); } }
    o.b[o.n < o.max ? o.n : o.max - 1] = 0;
    return o.n;
}
