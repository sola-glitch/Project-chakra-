/* ATA PIO driver (primary bus, master drive, 28-bit LBA). Works in QEMU and on
   machines with IDE / SATA-in-IDE-mode. Not available when booted from USB. */
#include "chakra.h"
#define IO 0x1F0
#define CTL 0x3F6
static int present;
static u32 nsectors;

static int wait_ready(void)
{
    for (int t = 0; t < 1000000; t++) {
        u8 s = inb(IO + 7);
        if (!(s & 0x80)) return (s & 0x21) ? -1 : 0;
    }
    return -1;
}
static int wait_drq(void)
{
    for (int t = 0; t < 1000000; t++) {
        u8 s = inb(IO + 7);
        if (s & 0x21) return -1;
        if (!(s & 0x80) && (s & 8)) return 0;
    }
    return -1;
}

int ata_init(void)
{
    present = 0;
    if (inb(IO + 7) == 0xFF) return 0;               /* floating bus: no controller */
    outb(CTL, 0x02);                                  /* no IRQ14 */
    outb(IO + 6, 0xA0);
    for (int i = 0; i < 4; i++) inb(CTL);
    outb(IO + 2, 0); outb(IO + 3, 0); outb(IO + 4, 0); outb(IO + 5, 0);
    outb(IO + 7, 0xEC);                               /* IDENTIFY */
    if (inb(IO + 7) == 0) return 0;
    for (int t = 0; t < 1000000 && (inb(IO + 7) & 0x80); t++) ;
    if (inb(IO + 4) || inb(IO + 5)) return 0;         /* ATAPI etc. */
    if (wait_drq()) return 0;
    u16 id[256]; u32 cnt = 256; u16 *p = id;
    __asm__ volatile("rep insw" : "+D"(p), "+c"(cnt) : "d"((u16)IO) : "memory");
    nsectors = id[60] | ((u32)id[61] << 16);
    present = nsectors > 0;
    return present;
}
int ata_present(void) { return present; }
u32 ata_sectors(void) { return nsectors; }

static void setup(u32 lba, u8 cmd)
{
    outb(IO + 6, 0xE0 | ((lba >> 24) & 0x0F));
    outb(IO + 2, 1);
    outb(IO + 3, lba & 0xFF);
    outb(IO + 4, (lba >> 8) & 0xFF);
    outb(IO + 5, (lba >> 16) & 0xFF);
    outb(IO + 7, cmd);
}

int ata_read(u32 lba, void *buf)
{
    if (!present || lba >= nsectors) return -1;
    u32 f = irq_save();
    int r = -1;
    if (!wait_ready()) {
        setup(lba, 0x20);
        if (!wait_drq()) {
            u32 cnt = 256; u16 *p = buf;
            __asm__ volatile("rep insw" : "+D"(p), "+c"(cnt) : "d"((u16)IO) : "memory");
            r = 0;
        }
    }
    irq_restore(f);
    return r;
}

int ata_write(u32 lba, const void *buf)
{
    if (!present || lba >= nsectors) return -1;
    u32 f = irq_save();
    int r = -1;
    if (!wait_ready()) {
        setup(lba, 0x30);
        if (!wait_drq()) {
            u32 cnt = 256; const u16 *p = buf;
            __asm__ volatile("rep outsw" : "+S"(p), "+c"(cnt) : "d"((u16)IO) : "memory");
            outb(IO + 7, 0xE7);                        /* flush cache */
            r = wait_ready();
        }
    }
    irq_restore(f);
    return r;
}
