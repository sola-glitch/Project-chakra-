/* PS/2 mouse (IRQ12). Collects 3-byte packets into accumulated movement + buttons. */
#include "chakra.h"
static int ok, phase, dx, dy, btn;
static u8 pk[3];

static void wait_in(void) { for (int t = 0; t < 100000 && (inb(0x64) & 2); t++) ; }
static void wait_out(void) { for (int t = 0; t < 100000 && !(inb(0x64) & 1); t++) ; }
static u8 aux_cmd(u8 c)
{
    wait_in(); outb(0x64, 0xD4);
    wait_in(); outb(0x60, c);
    wait_out(); return inb(0x60);                    /* ACK (0xFA) */
}

void mouse_init(void)
{
    wait_in(); outb(0x64, 0xA8);                     /* enable the aux (mouse) port */
    wait_in(); outb(0x64, 0x20);
    wait_out(); u8 st = inb(0x60);
    st = (st | 2) & ~0x20;                           /* IRQ12 on, clock on */
    wait_in(); outb(0x64, 0x60);
    wait_in(); outb(0x60, st);
    aux_cmd(0xF6);                                   /* defaults */
    ok = aux_cmd(0xF4) == 0xFA;                      /* start streaming */
    phase = 0;
}
int mouse_ok(void) { return ok; }

void mouse_byte(u8 b)
{
    if (!ok) return;
    if (phase == 0 && !(b & 8)) return;              /* out of sync */
    pk[phase++] = b;
    if (phase < 3) return;
    phase = 0;
    int x = pk[1], y = pk[2];
    if (pk[0] & 0x10) x -= 256;
    if (pk[0] & 0x20) y -= 256;
    if (pk[0] & 0xC0) x = y = 0;                     /* overflow */
    dx += x; dy -= y; btn = pk[0] & 7;
}

void mouse_irq(void)
{
    u8 st = inb(0x64);
    if (st & 1) { u8 d = inb(0x60); if (st & 0x20) mouse_byte(d); }
}

int mouse_poll(int *x, int *y, int *b)
{
    u32 f = irq_save();
    *x = dx; *y = dy; *b = btn;
    int moved = dx || dy;
    dx = dy = 0;
    irq_restore(f);
    return moved;
}
