/* Disk and file manager commands: disk layout, usage, check/repair, label, format, stat, touch. */
#include "chakra.h"

static void bar(u32 used, u32 total)
{
    int n = total ? (int)((used * 30) / total) : 0;
    putc('[');
    for (int i = 0; i < 30; i++) putc(i < n ? '#' : '.');
    kprintf("] %u%%\n", total ? (used * 100) / total : 0);
}

static void cmd_disk(void)
{
    kprintf("Boot drive : 0x%02x\n", BOOTINFO->boot_drive);
    if (ata_present()) kprintf("ATA disk   : %u sectors (%u KB)\n", ata_sectors(), ata_sectors() / 2);
    else puts("ATA disk   : none found (booted from USB/floppy? files live in RAM)\n");
    struct fat_geo g;
    if (!fs_on_disk() || fat12_geo(&g)) {
        kprintf("File system: RAM disk, %u of %u bytes used\n", fs_total_bytes() - fs_free_bytes(), fs_total_bytes());
        bar(fs_total_bytes() - fs_free_bytes(), fs_total_bytes());
        return;
    }
    kprintf("File system: FAT12, label \"%s\", cluster = %u bytes\n", g.label, g.spc * 512);
    puts("Layout (sectors):\n");
    kprintf("  boot sector   0\n  stage 2       1 - %u\n  FAT x%u        %u - %u\n  root dir      %u - %u (%u entries)\n  data          %u - %u\n",
            g.reserved - 1, g.fats, g.fat_lba, g.root_lba - 1, g.root_lba, g.data_lba - 1, g.root_entries, g.data_lba, g.total_sectors - 1);
    u32 used = g.clusters - g.free_clusters;
    kprintf("Clusters   : %u total, %u used, %u free\n", g.clusters, used, g.free_clusters);
    kprintf("Space      : %u KB used, %u KB free\n", used * g.spc / 2, g.free_clusters * g.spc / 2);
    bar(used, g.clusters);
}

static void cmd_df(void)
{
    u32 tot = fs_total_bytes(), fr = fs_free_bytes();
    kprintf("%s: %u KB total, %u KB used, %u KB free\n", fs_on_disk() ? "FAT12 disk" : "RAM disk", tot / 1024, (tot - fr) / 1024, fr / 1024);
    bar(tot - fr, tot);
}

static void cmd_fsck(int fix)
{
    u32 files, errs, lost, fixed;
    if (!fs_on_disk()) { puts("fsck: needs the FAT12 disk (the RAM disk has nothing to check)\n"); return; }
    if (fat12_check(fix, &files, &errs, &lost, &fixed)) { puts("fsck: disk error\n"); return; }
    kprintf("Checked %u file(s): %u file problem(s), %u lost cluster(s)\n", files, errs, lost);
    if (fix) kprintf("Repaired %u problem(s).\n", fixed);
    else if (errs || lost) puts("Run 'fsck fix' to repair.\n");
    else puts("The file system is clean.\n");
}

static void cmd_stat(const char *name)
{
    char n[FS_MAXNAME]; u32 size;
    if (fs_norm(name, n) || fs_size(n, &size)) { kprintf("stat: no such file: %s\n", name); return; }
    kprintf("File    : %s\nSize    : %u bytes\n", n, size);
    u32 first, cl, d, t;
    if (fs_on_disk() && !fat12_stat(n, &first, &cl, &d, &t))
        kprintf("Cluster : first %u, %u in chain\nModified: %04u-%02u-%02u %02u:%02u\n", first, cl, 1980 + (d >> 9), (d >> 5) & 15, d & 31, t >> 11, (t >> 5) & 63);
}

static void cmd_format(int argc, char **argv)
{
    if (argc < 2 || strcmp(argv[1], "yes")) {
        puts("format erases ALL your files (KERNEL.BIN is kept so the disk still boots).\nType 'format yes' to continue.\n");
        return;
    }
    struct fs_entry fe[32];
    int n = fs_list(fe, 32), gone = 0;
    for (int i = 0; i < n; i++) if (strcmp(fe[i].name, "KERNEL.BIN") && !fs_remove(fe[i].name)) gone++;
    kprintf("Erased %d file(s).\n", gone);
}

int disk_command(int argc, char **argv)
{
    const char *c = argv[0];
    if (!strcmp(c, "disk")) cmd_disk();
    else if (!strcmp(c, "df")) cmd_df();
    else if (!strcmp(c, "fsck") || !strcmp(c, "chkdsk")) cmd_fsck(argc > 1 && !strcmp(argv[1], "fix"));
    else if (!strcmp(c, "stat")) { if (argc < 2) puts("usage: stat <file>\n"); else cmd_stat(argv[1]); }
    else if (!strcmp(c, "touch")) {
        if (argc < 2) { puts("usage: touch <file>\n"); return 1; }
        u32 sz;
        if (fs_size(argv[1], &sz)) { int r = fs_write(argv[1], "", 0, 0); if (r) puts("touch: bad name or no space\n"); }
        else puts("file already exists\n");
    }
    else if (!strcmp(c, "label")) {
        char b[12];
        if (!fs_on_disk()) { puts("label: needs the FAT12 disk\n"); return 1; }
        if (argc > 1) { if (fat12_label(argv[1], b) < 0) { puts("label: disk error\n"); return 1; } }
        else if (fat12_label(NULL, b) < 0) { puts("label: disk error\n"); return 1; }
        kprintf("Volume label: \"%s\"\n", b);
    }
    else if (!strcmp(c, "format")) cmd_format(argc, argv);
    else return 0;
    return 1;
}
