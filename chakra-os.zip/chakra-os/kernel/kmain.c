#include "chakra.h"

void print_banner(void)
{
    static const u8 col[7] = { RED, BROWN, YELLOW, LGREEN, LCYAN, LBLUE, LMAGENTA };
    u8 of = get_fg(), ob = get_bg();
    set_color(LMAGENTA, ob);
    puts("   ____ _   _    _    _  ______      _     \n"
         "  / ___| | | |  / \\  | |/ /  _ \\    / \\    \n"
         " | |   | |_| | / _ \\ | ' /| |_) |  / _ \\   \n"
         " | |___|  _  |/ ___ \\| . \\|  _ <  / ___ \\  \n"
         "  \\____|_| |_/_/   \\_\\_|\\_\\_| \\_\\/_/   \\_\\ \n");
    for (int i = 0; i < 7; i++) {
        set_color(col[i], ob);
        for (int k = 0; k < 6; k++) putc((char)0xDB);
        putc(' ');
    }
    set_color(of, ob);
    kprintf("\n Chakra OS %s - type 'help'\n", CHAKRA_VERSION);
}

static void ok(const char *s) { u8 o = get_fg(); set_color(LGREEN, get_bg()); puts(" [ok] "); set_color(o, get_bg()); puts(s); putc('\n'); }
static void no(const char *s) { u8 o = get_fg(); set_color(YELLOW, get_bg()); puts(" [--] "); set_color(o, get_bg()); puts(s); putc('\n'); }

void kmain(void)
{
    bootinfo_init();              /* before paging unmaps page 0 */
    serial_init();
    vga_init();
    idt_init();
    mm_init();
    sched_init();
    kbd_init();
    fs_init();
    pci_scan();
    timer_init();                 /* interrupts on: timer + keyboard */
    gui_start();                  /* graphical desktop if the loader set a video mode */
    if (!gui_active()) ui_start_status();
    print_banner();
    char b[80];
    ksnprintf(b, sizeof b, "memory: %u MB RAM, paging %s, %u KB heap", mem_top() >> 20, paging_enabled() ? "on" : "off", heap_total() / 1024);
    ok(b);
    if (fs_on_disk()) { ksnprintf(b, sizeof b, "disk: FAT12, %u KB free (files survive reboot)", fs_free_bytes() / 1024); ok(b); }
    else no("disk: none found, using a RAM disk (erased on reboot)");
    ok(gui_active() ? "multitasking: preemptive scheduler, desktop task running" : "multitasking: preemptive scheduler, status bar task running");
    putc('\n');
    shell_run();
}
