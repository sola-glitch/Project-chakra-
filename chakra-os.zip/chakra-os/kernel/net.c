/* Network stack: Ethernet, ARP, IPv4, ICMP (ping), UDP, DHCP, DNS, and a small TCP client. */
#include "chakra.h"

struct netcfg net;

static inline u16 bs16(u16 v) { return (u16)((v << 8) | (v >> 8)); }
static inline u32 bs32(u32 v) { return __builtin_bswap32(v); }

struct eth { u8 dst[6], src[6]; u16 type; } __attribute__((packed));
struct arp { u16 htype, ptype; u8 hlen, plen; u16 op; u8 sha[6]; u32 spa; u8 tha[6]; u32 tpa; } __attribute__((packed));
struct ip4 { u8 vihl, tos; u16 len, id, frag; u8 ttl, proto; u16 csum; u32 src, dst; } __attribute__((packed));
struct udph { u16 sport, dport, len, csum; } __attribute__((packed));
struct tcph { u16 sport, dport; u32 seq, ack; u8 off, flags; u16 win, csum, urg; } __attribute__((packed));
struct icmp { u8 type, code; u16 csum, id, seq; } __attribute__((packed));

void ip_str(u32 ip, char *o) { ksnprintf(o, 16, "%u.%u.%u.%u", ip >> 24, (ip >> 16) & 255, (ip >> 8) & 255, ip & 255); }

static u32 csum_add(u32 sum, const void *d, u32 n)
{
    const u8 *p = d;
    while (n > 1) { sum += (p[0] << 8) | p[1]; p += 2; n -= 2; }
    if (n) sum += p[0] << 8;
    return sum;
}
static u16 csum_fin(u32 sum) { while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16); return bs16((u16)~sum); }

/* ---------------- ARP ---------------- */
static struct { u32 ip; u8 mac[6]; int ok; } arpc[8];
static const u8 BCAST[6] = { 255, 255, 255, 255, 255, 255 };

static void eth_send(const u8 *dst, u16 type, const void *payload, u32 n)
{
    u8 f[1536];
    struct eth *e = (struct eth *)f;
    memcpy(e->dst, dst, 6); memcpy(e->src, net.mac, 6); e->type = bs16(type);
    memcpy(f + sizeof(*e), payload, n);
    nic_send(f, sizeof(*e) + n);
}

static void arp_send(u16 op, const u8 *tha, u32 tpa)
{
    struct arp a;
    a.htype = bs16(1); a.ptype = bs16(0x0800); a.hlen = 6; a.plen = 4; a.op = bs16(op);
    memcpy(a.sha, net.mac, 6); a.spa = bs32(net.ip);
    memcpy(a.tha, tha, 6); a.tpa = bs32(tpa);
    eth_send(op == 1 ? BCAST : tha, 0x0806, &a, sizeof a);
}

static void arp_learn(u32 ip, const u8 *mac)
{
    int slot = -1;
    for (int i = 0; i < 8; i++) if (arpc[i].ok && arpc[i].ip == ip) { slot = i; break; }
    if (slot < 0) for (int i = 0; i < 8; i++) if (!arpc[i].ok) { slot = i; break; }
    if (slot < 0) slot = ip & 7;
    arpc[slot].ip = ip; memcpy(arpc[slot].mac, mac, 6); arpc[slot].ok = 1;
}

static void net_poll(void);

static int arp_lookup(u32 ip, u8 *mac)
{
    for (int i = 0; i < 8; i++) if (arpc[i].ok && arpc[i].ip == ip) { memcpy(mac, arpc[i].mac, 6); return 0; }
    return -1;
}

static int arp_resolve(u32 ip, u8 *mac)
{
    if (ip == 0xFFFFFFFFu) { memcpy(mac, BCAST, 6); return 0; }
    for (int tries = 0; tries < 4; tries++) {
        if (!arp_lookup(ip, mac)) return 0;
        static const u8 z[6] = { 0 };
        arp_send(1, z, ip);
        for (int w = 0; w < 25; w++) { net_poll(); if (!arp_lookup(ip, mac)) return 0; sleep_ms(10); }
    }
    return -1;
}

/* ---------------- IP ---------------- */
static u16 ipid;

static int ip_send_from(u32 src, u32 dst, u8 proto, const void *pl, u32 n)
{
    if (n > 1480) return -1;
    u8 f[1500];
    struct ip4 *h = (struct ip4 *)f;
    h->vihl = 0x45; h->tos = 0; h->len = bs16(20 + n); h->id = bs16(++ipid); h->frag = 0;
    h->ttl = 64; h->proto = proto; h->csum = 0; h->src = bs32(src); h->dst = bs32(dst);
    h->csum = csum_fin(csum_add(0, h, 20));
    memcpy(f + 20, pl, n);
    u32 hop = dst;
    if (dst != 0xFFFFFFFFu && (dst & net.mask) != (net.ip & net.mask)) hop = net.gw;
    u8 mac[6];
    if (arp_resolve(hop, mac)) return -1;
    eth_send(mac, 0x0800, f, 20 + n);
    return 0;
}
static int ip_send(u32 dst, u8 proto, const void *pl, u32 n) { return ip_send_from(net.ip, dst, proto, pl, n); }

/* ---------------- ICMP ---------------- */
static volatile int ping_seq, ping_got;

/* ---------------- UDP, DHCP, DNS ---------------- */
static volatile int dhcp_state;                      /* 0 idle, 2 offer, 5 ack */
static u32 dhcp_xid, d_ip, d_mask, d_gw, d_dns, d_srv;
static volatile int dns_got; static u16 dns_id; static u32 dns_ans; static u16 dns_port = 53000;

static int udp_send(u32 src, u32 dst, u16 sp, u16 dp, const void *d, u32 n)
{
    u8 b[1480];
    struct udph *u = (struct udph *)b;
    if (n > 1400) return -1;
    u->sport = bs16(sp); u->dport = bs16(dp); u->len = bs16(8 + n); u->csum = 0;
    memcpy(b + 8, d, n);
    return ip_send_from(src, dst, 17, b, 8 + n);
}

static void dhcp_input(const u8 *p, u32 n)
{
    if (n < 240 || p[0] != 2 || memcmp(p + 4, &(u32){ bs32(dhcp_xid) }, 4)) return;
    u32 yi = (p[16] << 24) | (p[17] << 16) | (p[18] << 8) | p[19];
    int mt = 0; u32 mask = 0, gw = 0, dns = 0, srv = 0;
    for (u32 i = 240; i + 1 < n && p[i] != 255;) {
        u8 o = p[i], l = p[i + 1];
        if (o == 0) { i++; continue; }
        const u8 *v = p + i + 2;
        u32 w = l >= 4 ? (v[0] << 24) | (v[1] << 16) | (v[2] << 8) | v[3] : 0;
        if (o == 53) mt = v[0]; else if (o == 1) mask = w; else if (o == 3) gw = w; else if (o == 6) dns = w; else if (o == 54) srv = w;
        i += 2 + l;
    }
    if (mt == 2 && dhcp_state == 1) { d_ip = yi; d_mask = mask; d_gw = gw; d_dns = dns; d_srv = srv; dhcp_state = 2; }
    else if (mt == 5 && dhcp_state == 3) { d_ip = yi; if (mask) d_mask = mask; if (gw) d_gw = gw; if (dns) d_dns = dns; dhcp_state = 5; }
}

static void dns_input(const u8 *p, u32 n)
{
    if (n < 12 || ((p[0] << 8) | p[1]) != dns_id || !(p[2] & 0x80)) return;
    u32 an = (p[6] << 8) | p[7], i = 12;
    for (u32 q = (p[4] << 8) | p[5]; q && i < n; q--) {          /* skip questions */
        while (i < n && p[i]) { if ((p[i] & 0xC0) == 0xC0) { i++; break; } i += p[i] + 1; }
        i += 5;
    }
    for (; an && i + 10 < n; an--) {
        while (i < n && p[i]) { if ((p[i] & 0xC0) == 0xC0) { i++; break; } i += p[i] + 1; }
        i++;
        u16 type = (p[i] << 8) | p[i + 1], rl = (p[i + 8] << 8) | p[i + 9];
        i += 10;
        if (type == 1 && rl == 4 && i + 4 <= n) { dns_ans = (p[i] << 24) | (p[i + 1] << 16) | (p[i + 2] << 8) | p[i + 3]; dns_got = 1; return; }
        i += rl;
    }
    dns_got = -1;
}

/* ---------------- TCP ---------------- */
#define MAXCONN 4
#define RXCAP (96 * 1024)
enum { C_FREE, C_SYN, C_EST, C_CLOSED };
struct tcb {
    int state; u32 rip; u16 lport, rport;
    u32 snd_una, snd_nxt, rcv_nxt;
    u8 *rx; u32 rxn, rxpos; int fin, rst;
};
static struct tcb conns[MAXCONN];
static u16 next_port = 41000;

static void tcp_seg(struct tcb *t, u8 flags, const void *d, u32 n)
{
    u8 b[1480];
    struct tcph *h = (struct tcph *)b;
    u32 hl = (flags & 2) ? 24 : 20;
    h->sport = bs16(t->lport); h->dport = bs16(t->rport);
    h->seq = bs32((flags & 2) ? t->snd_una : t->snd_nxt); h->ack = bs32(t->rcv_nxt);
    h->off = (hl / 4) << 4; h->flags = flags; h->win = bs16(8192); h->csum = 0; h->urg = 0;
    if (flags & 2) { b[20] = 2; b[21] = 4; b[22] = 0x05; b[23] = 0xB4; }
    if (n) memcpy(b + hl, d, n);
    struct { u32 s, d; u8 z, p; u16 l; } __attribute__((packed)) ph = { bs32(net.ip), bs32(t->rip), 0, 6, bs16(hl + n) };
    u32 sum = csum_add(0, &ph, 12);
    h->csum = csum_fin(csum_add(sum, b, hl + n));
    ip_send(t->rip, 6, b, hl + n);
}

static void tcp_input(u32 src, const u8 *p, u32 n)
{
    if (n < 20) return;
    const struct tcph *h = (const struct tcph *)p;
    u16 dp = bs16(h->dport), sp = bs16(h->sport);
    u32 seq = bs32(h->seq), ack = bs32(h->ack), hl = (h->off >> 4) * 4;
    if (hl < 20 || hl > n) return;
    u32 dl = n - hl;
    for (int i = 0; i < MAXCONN; i++) {
        struct tcb *t = &conns[i];
        if (t->state == C_FREE || t->rip != src || t->lport != dp || t->rport != sp) continue;
        if (h->flags & 4) { t->rst = 1; t->state = C_CLOSED; return; }
        if (t->state == C_SYN) {
            if ((h->flags & 0x12) == 0x12 && ack == t->snd_nxt) { t->snd_una = ack; t->rcv_nxt = seq + 1; t->state = C_EST; tcp_seg(t, 0x10, NULL, 0); }
            return;
        }
        if (h->flags & 0x10) { if ((i32)(ack - t->snd_una) > 0 && (i32)(ack - t->snd_nxt) <= 0) t->snd_una = ack; }
        if (dl) {
            if (seq == t->rcv_nxt && t->rx && t->rxn + dl <= RXCAP) {
                memcpy(t->rx + t->rxn, p + hl, dl); t->rxn += dl; t->rcv_nxt += dl;
            }
            tcp_seg(t, 0x10, NULL, 0);
        }
        if ((h->flags & 1) && seq + dl == t->rcv_nxt) { t->rcv_nxt++; t->fin = 1; tcp_seg(t, 0x10, NULL, 0); }
        return;
    }
}

/* ---------------- receive path ---------------- */
static void net_rx(u8 *f, u32 n)
{
    if (n < 14) return;
    struct eth *e = (struct eth *)f;
    u16 type = bs16(e->type);
    u8 *p = f + 14; u32 pl = n - 14;
    if (type == 0x0806 && pl >= sizeof(struct arp)) {
        struct arp *a = (struct arp *)p;
        arp_learn(bs32(a->spa), a->sha);
        if (bs16(a->op) == 1 && net.ip && bs32(a->tpa) == net.ip) arp_send(2, a->sha, bs32(a->spa));
    } else if (type == 0x0800 && pl >= 20) {
        struct ip4 *h = (struct ip4 *)p;
        u32 ihl = (h->vihl & 15) * 4, tl = bs16(h->len), src = bs32(h->src), dst = bs32(h->dst);
        if (ihl < 20 || tl > pl || tl < ihl) return;
        if (net.ip && dst != net.ip && dst != 0xFFFFFFFFu && dst != (net.ip | ~net.mask)) return;
        u8 *q = p + ihl; u32 ql = tl - ihl;
        if (h->proto == 1 && ql >= 8) {
            struct icmp *ic = (struct icmp *)q;
            if (ic->type == 8) {
                u8 r[1480]; memcpy(r, q, ql); struct icmp *ri = (struct icmp *)r;
                ri->type = 0; ri->csum = 0; ri->csum = csum_fin(csum_add(0, r, ql));
                ip_send(src, 1, r, ql);
            } else if (ic->type == 0 && bs16(ic->id) == 0xC4A1 && bs16(ic->seq) == (u16)ping_seq) ping_got = 1;
        } else if (h->proto == 17 && ql >= 8) {
            struct udph *u = (struct udph *)q;
            u16 dp = bs16(u->dport);
            if (dp == 68) dhcp_input(q + 8, ql - 8);
            else if (dp == dns_port) dns_input(q + 8, ql - 8);
        } else if (h->proto == 6) tcp_input(src, q, ql);
    }
}

static void net_poll(void)
{
    u32 f = irq_save();
    static u8 buf[1536];
    int n;
    for (int i = 0; i < 32 && (n = nic_recv(buf, sizeof buf)) > 0; i++) net_rx(buf, n);
    irq_restore(f);
}

/* ---------------- configuration ---------------- */
void net_static(void)
{
    net.ip = IP4(10, 0, 2, 15); net.mask = IP4(255, 255, 255, 0); net.gw = IP4(10, 0, 2, 2); net.dns = IP4(10, 0, 2, 3); net.up = 1;
}

int net_dhcp(void)
{
    if (nic_init()) return -1;
    memset(arpc, 0, sizeof arpc);
    net.ip = 0;
    dhcp_xid = ticks() * 2654435761u + 12345; dhcp_state = 1;
    u8 m[300]; memset(m, 0, sizeof m);
    for (int round = 0; round < 3 && dhcp_state != 5; round++) {
        memset(m, 0, sizeof m);
        m[0] = 1; m[1] = 1; m[2] = 6; *(u32 *)(m + 4) = bs32(dhcp_xid); m[10] = 0x80;
        memcpy(m + 28, net.mac, 6);
        m[236] = 99; m[237] = 130; m[238] = 83; m[239] = 99;
        int i = 240;
        if (dhcp_state == 1) { m[i++] = 53; m[i++] = 1; m[i++] = 1; }
        else { m[i++] = 53; m[i++] = 1; m[i++] = 3; m[i++] = 50; m[i++] = 4; m[i++] = d_ip >> 24; m[i++] = d_ip >> 16; m[i++] = d_ip >> 8; m[i++] = d_ip;
               m[i++] = 54; m[i++] = 4; m[i++] = d_srv >> 24; m[i++] = d_srv >> 16; m[i++] = d_srv >> 8; m[i++] = d_srv; }
        m[i++] = 55; m[i++] = 3; m[i++] = 1; m[i++] = 3; m[i++] = 6; m[i++] = 255;
        udp_send(0, 0xFFFFFFFFu, 68, 67, m, i);
        for (int w = 0; w < 100 && dhcp_state != 5; w++) {
            net_poll();
            if (dhcp_state == 2) { dhcp_state = 3; break; }
            sleep_ms(10);
        }
        if (dhcp_state == 3) {                      /* got an offer: now REQUEST it */
            i = 240; memset(m + 240, 0, 40);
            m[i++] = 53; m[i++] = 1; m[i++] = 3; m[i++] = 50; m[i++] = 4; m[i++] = d_ip >> 24; m[i++] = d_ip >> 16; m[i++] = d_ip >> 8; m[i++] = d_ip;
            m[i++] = 54; m[i++] = 4; m[i++] = d_srv >> 24; m[i++] = d_srv >> 16; m[i++] = d_srv >> 8; m[i++] = d_srv; m[i++] = 255;
            udp_send(0, 0xFFFFFFFFu, 68, 67, m, i);
            for (int w = 0; w < 100 && dhcp_state != 5; w++) { net_poll(); sleep_ms(10); }
        }
    }
    if (dhcp_state != 5) return -1;
    net.ip = d_ip; net.mask = d_mask ? d_mask : IP4(255, 255, 255, 0); net.gw = d_gw; net.dns = d_dns ? d_dns : d_gw; net.up = 1;
    return 0;
}

int net_ensure(void)
{
    if (net.up) return 0;
    if (!pci_count()) pci_scan();
    if (nic_init()) return -1;
    if (net_dhcp()) net_static();
    return 0;
}

/* ---------------- ping, DNS, TCP API ---------------- */
int net_ping(u32 ip, u32 timeout_ms, u32 *rtt)
{
    if (net_ensure()) return -1;
    u8 b[40]; struct icmp *ic = (struct icmp *)b;
    memset(b, 0x61, sizeof b);
    ic->type = 8; ic->code = 0; ic->id = bs16(0xC4A1); ic->seq = bs16(++ping_seq); ic->csum = 0;
    ic->csum = csum_fin(csum_add(0, b, sizeof b));
    ping_got = 0;
    u32 t0 = ticks();
    if (ip_send(ip, 1, b, sizeof b)) return -2;
    while ((ticks() - t0) * 10 < timeout_ms) {
        net_poll();
        if (ping_got) { *rtt = (ticks() - t0) * 10; return 0; }
        sleep_ms(10);
    }
    return -3;
}

static int parse_ip(const char *s, u32 *ip)
{
    u32 v = 0, parts = 0, cur = 0; int digits = 0;
    for (;; s++) {
        if (*s >= '0' && *s <= '9') { cur = cur * 10 + (*s - '0'); digits++; if (cur > 255) return -1; }
        else if (*s == '.' || !*s) { if (!digits) return -1; v = (v << 8) | cur; parts++; cur = 0; digits = 0; if (!*s) break; }
        else return -1;
    }
    if (parts != 4) return -1;
    *ip = v; return 0;
}

int net_resolve(const char *name, u32 *ip)
{
    if (!parse_ip(name, ip)) return 0;
    if (net_ensure()) return -1;
    u8 q[300]; int i = 12;
    memset(q, 0, 12);
    dns_id = (u16)(ticks() * 7 + 1); q[0] = dns_id >> 8; q[1] = dns_id; q[2] = 1; q[5] = 1;
    const char *s = name;
    while (*s) {
        const char *e = s; while (*e && *e != '.') e++;
        int l = e - s; if (l == 0 || l > 63 || i + l + 6 > 280) return -2;
        q[i++] = l; memcpy(q + i, s, l); i += l;
        s = *e ? e + 1 : e;
    }
    q[i++] = 0; q[i++] = 0; q[i++] = 1; q[i++] = 0; q[i++] = 1;
    for (int tries = 0; tries < 3; tries++) {
        dns_got = 0; dns_port = 53000 + (ticks() & 0xFF);
        udp_send(net.ip, net.dns, dns_port, 53, q, i);
        for (int w = 0; w < 200 && !dns_got; w++) { net_poll(); sleep_ms(10); }
        if (dns_got == 1) { *ip = dns_ans; return 0; }
        if (dns_got == -1) return -3;
    }
    return -4;
}

static struct tcb *conn(int h) { return (h >= 0 && h < MAXCONN && conns[h].state != C_FREE) ? &conns[h] : NULL; }

int tcp_connect(u32 ip, u16 port)
{
    if (net_ensure()) return -1;
    int h = -1;
    for (int i = 0; i < MAXCONN; i++) if (conns[i].state == C_FREE) { h = i; break; }
    if (h < 0) return -2;
    struct tcb *t = &conns[h];
    memset(t, 0, sizeof *t);
    t->rx = kmalloc(RXCAP);
    if (!t->rx) return -2;
    t->rip = ip; t->rport = port; t->lport = next_port++;
    t->snd_una = ticks() * 64013u + 1000; t->snd_nxt = t->snd_una + 1; t->state = C_SYN;
    for (int tries = 0; tries < 4 && t->state == C_SYN; tries++) {
        tcp_seg(t, 0x02, NULL, 0);
        for (int w = 0; w < 100 && t->state == C_SYN; w++) { net_poll(); sleep_ms(10); }
    }
    if (t->state != C_EST) { kfree(t->rx); t->state = C_FREE; return -3; }
    return h;
}

int tcp_send(int h, const void *d, u32 n)
{
    struct tcb *t = conn(h);
    if (!t || t->state != C_EST) return -1;
    const u8 *p = d;
    while (n) {
        u32 c = n > 1400 ? 1400 : n;
        u32 start = t->snd_nxt;
        t->snd_nxt += c;
        int ok = 0;
        for (int tries = 0; tries < 6 && !ok; tries++) {
            u32 save = t->snd_nxt; t->snd_nxt = start;
            tcp_seg(t, 0x18, p, c);
            t->snd_nxt = save;
            for (int w = 0; w < 40; w++) {
                net_poll();
                if (t->rst) return -1;
                if ((i32)(t->snd_una - t->snd_nxt) >= 0) { ok = 1; break; }
                sleep_ms(10);
            }
        }
        if (!ok) return -1;
        p += c; n -= c;
    }
    return 0;
}

int tcp_recv(int h, void *buf, u32 max, u32 timeout_ms)
{
    struct tcb *t = conn(h);
    if (!t) return 0;
    u32 t0 = ticks();
    for (;;) {
        net_poll();
        if (t->rxpos < t->rxn) {
            u32 c = t->rxn - t->rxpos; if (c > max) c = max;
            memcpy(buf, t->rx + t->rxpos, c); t->rxpos += c;
            return c;
        }
        if (t->fin || t->rst || t->state == C_CLOSED) return 0;
        if ((ticks() - t0) * 10 >= timeout_ms) return -1;
        sleep_ms(10);
    }
}

void tcp_close(int h)
{
    struct tcb *t = conn(h);
    if (!t) return;
    if (t->state == C_EST) {
        tcp_seg(t, 0x11, NULL, 0); t->snd_nxt++;
        for (int w = 0; w < 30; w++) { net_poll(); if (t->fin) break; sleep_ms(10); }
    }
    kfree(t->rx); t->rx = NULL; t->state = C_FREE;
}
