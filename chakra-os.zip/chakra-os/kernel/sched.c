/* Preemptive round-robin scheduler. Tasks are kernel threads, each with its own
   stack. The timer interrupt calls sched_tick() 100 times a second. */
#include "chakra.h"

#define MAXTASKS 8
#define STACKSZ 16384
enum { T_FREE, T_READY, T_SLEEP, T_DEAD };

struct task {
    u32 esp; int state; char name[16];
    u32 wake, cpu, progress;
    u8 *stack; void (*fn)(void *); void *arg;
};
static struct task tasks[MAXTASKS];
static int cur;
extern void switch_context(u32 *old, u32 new_esp);

void sched_init(void)
{
    memset(tasks, 0, sizeof(tasks));
    tasks[0].state = T_READY;
    strncpy0(tasks[0].name, "shell", 16);
    cur = 0;
}

static void tramp(void)
{
    __asm__ volatile("sti");
    struct task *t = &tasks[cur];
    t->fn(t->arg);
    task_exit();
}

int task_create(const char *name, void (*fn)(void *), void *arg)
{
    u8 *stk = kmalloc(STACKSZ);
    if (!stk) return -1;
    u32 f = irq_save();
    int i;
    for (i = 1; i < MAXTASKS; i++) if (tasks[i].state == T_FREE) break;
    if (i == MAXTASKS) { irq_restore(f); kfree(stk); return -1; }
    struct task *t = &tasks[i];
    memset(t, 0, sizeof(*t));
    u32 *sp = (u32 *)(stk + STACKSZ);
    *--sp = 0;                 /* dummy return address for tramp */
    *--sp = (u32)tramp;        /* switch_context "returns" here */
    *--sp = 0; *--sp = 0; *--sp = 0; *--sp = 0;   /* ebp ebx esi edi */
    t->esp = (u32)sp; t->stack = stk; t->fn = fn; t->arg = arg;
    strncpy0(t->name, name, 16);
    t->state = T_READY;
    irq_restore(f);
    return i;
}

static void reap(void)
{
    for (int i = 1; i < MAXTASKS; i++)
        if (tasks[i].state == T_DEAD && i != cur) { kfree(tasks[i].stack); tasks[i].stack = NULL; tasks[i].state = T_FREE; }
}

/* call with interrupts disabled */
static void schedule(void)
{
    reap();
    int next = -1;
    for (int k = 1; k <= MAXTASKS; k++) {
        int i = (cur + k) % MAXTASKS;
        struct task *t = &tasks[i];
        if (t->state == T_SLEEP && (i32)(ticks() - t->wake) >= 0) t->state = T_READY;
        if (t->state == T_READY) { next = i; break; }
    }
    if (next < 0 || next == cur) return;
    int old = cur;
    cur = next;
    switch_context(&tasks[old].esp, tasks[next].esp);
}

void sched_tick(void)
{
    tasks[cur].cpu++;
    schedule();
}

void task_sleep(u32 ms)
{
    u32 f = irq_save();
    tasks[cur].wake = ticks() + (ms + 9) / 10;
    tasks[cur].state = T_SLEEP;
    schedule();
    irq_restore(f);
}

void task_exit(void)
{
    __asm__ volatile("cli");
    tasks[cur].state = T_DEAD;
    schedule();
    for (;;) __asm__ volatile("hlt");
}

int task_kill(int id)
{
    if (id <= 1 || id >= MAXTASKS) return -1;
    u32 f = irq_save();
    int ok = (tasks[id].state == T_READY || tasks[id].state == T_SLEEP) ? 0 : -1;
    if (!ok) tasks[id].state = T_DEAD;
    irq_restore(f);
    return ok;
}

int task_get(int idx, struct task_info *o)
{
    if (idx < 0 || idx >= MAXTASKS) return -1;
    u32 f = irq_save();
    struct task *t = &tasks[idx];
    int ok = (t->state == T_FREE) ? -1 : 0;
    if (!ok) { o->id = idx; strncpy0(o->name, t->name, 16); o->state = t->state; o->cpu = t->cpu; o->progress = t->progress; }
    irq_restore(f);
    return ok;
}

void task_set_progress(u32 p) { tasks[cur].progress = p; }
int task_current(void) { return cur; }
