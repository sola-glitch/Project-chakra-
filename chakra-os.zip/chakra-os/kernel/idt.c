/* IDT, PIC remap, PIT timer (100 Hz), exception handler. */
#include "chakra.h"

struct idt_entry { u16 lo; u16 sel; u8 zero; u8 flags; u16 hi; } __attribute__((packed));
struct idt_ptr { u16 limit; u32 base; } __attribute__((packed));
struct regs { u32 edi, esi, ebp, esp, ebx, edx, ecx, eax, int_no, err, eip, cs, eflags; };

extern u32 isr_stub_table[48];
static struct idt_entry idt[48];
static volatile u32 tick_count;

static const char *exc_names[20] = {
    "Divide error", "Debug", "NMI", "Breakpoint", "Overflow", "Bound range",
    "Invalid opcode", "Device not available", "Double fault", "Coprocessor overrun",
    "Invalid TSS", "Segment not present", "Stack fault", "General protection fault",
    "Page fault", "Reserved", "x87 FPU error", "Alignment check", "Machine check", "SIMD error"
};

void idt_init(void)
{
    for (int i = 0; i < 48; i++) {
        u32 a = isr_stub_table[i];
        idt[i].lo = a & 0xFFFF; idt[i].sel = 0x08; idt[i].zero = 0;
        idt[i].flags = 0x8E; idt[i].hi = a >> 16;
    }
    struct idt_ptr p = { sizeof(idt) - 1, (u32)idt };
    __asm__ volatile("lidt %0" ::"m"(p));
    /* remap PIC: IRQ0-7 -> 32-39, IRQ8-15 -> 40-47; only the timer unmasked */
    outb(0x20, 0x11); outb(0xA0, 0x11);
    outb(0x21, 32);   outb(0xA1, 40);
    outb(0x21, 4);    outb(0xA1, 2);
    outb(0x21, 1);    outb(0xA1, 1);
    outb(0x21, 0xF8); outb(0xA1, 0xEF);   /* IRQ0 timer, IRQ1 keyboard, IRQ2 cascade, IRQ12 mouse */
}

void timer_init(void)
{
    u32 div = 1193182 / 100;
    outb(0x43, 0x36);
    outb(0x40, div & 0xFF);
    outb(0x40, div >> 8);
    __asm__ volatile("sti");
}

u32 ticks(void) { return tick_count; }

void sleep_ms(u32 ms)
{
    u32 end = tick_count + (ms + 9) / 10;
    while ((i32)(end - tick_count) > 0) __asm__ volatile("hlt");
}

void isr_handler(struct regs *r)
{
    if (r->int_no < 32) {
        set_color(WHITE, RED);
        kprintf("\n\n *** CHAKRA KERNEL PANIC ***\n");
        kprintf(" Exception %u: %s\n", r->int_no, r->int_no < 20 ? exc_names[r->int_no] : "Unknown");
        kprintf(" EIP=%x  error=%x  EFLAGS=%x\n", r->eip, r->err, r->eflags);
        if (r->int_no == 14) {
            u32 cr2; __asm__ volatile("mov %%cr2,%0" : "=r"(cr2));
            kprintf(" Faulting address (CR2) = %x\n", cr2);
        }
        kprintf(" System halted.\n");
        for (;;) __asm__ volatile("cli; hlt");
    }
    if (r->int_no == 32) {
        tick_count++;
        outb(0x20, 0x20);        /* acknowledge BEFORE any task switch */
        sched_tick();
        return;
    }
    if (r->int_no == 33) kbd_irq();
    if (r->int_no == 44) mouse_irq();
    if (r->int_no >= 40) outb(0xA0, 0x20);
    outb(0x20, 0x20);
}
