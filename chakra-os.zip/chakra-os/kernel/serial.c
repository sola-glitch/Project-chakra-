/* COM1 serial port, 115200 8N1. Safe on machines that have no serial port. */
#include "chakra.h"
#define COM1 0x3F8
static int ok;

int serial_init(void)
{
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x80);
    outb(COM1 + 0, 0x01);   /* divisor 1 = 115200 baud */
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x03);
    outb(COM1 + 2, 0xC7);
    outb(COM1 + 4, 0x1E);   /* loopback self-test */
    outb(COM1 + 0, 0xAE);
    if (inb(COM1) != 0xAE) { ok = 0; return 0; }
    outb(COM1 + 4, 0x0F);
    ok = 1;
    return 1;
}

void serial_putc(char c)
{
    if (!ok) return;
    int t = 100000;
    while (!(inb(COM1 + 5) & 0x20) && --t) ;
    outb(COM1, (u8)c);
}

int serial_getc_nb(void)
{
    if (!ok) return -1;
    if (inb(COM1 + 5) & 1) return inb(COM1);
    return -1;
}
