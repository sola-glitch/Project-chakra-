/* File system front end. Uses FAT12 on the ATA disk when one is found (files
   survive reboot); otherwise falls back to a small RAM disk. Names are 8.3,
   upper-case. */
#include "chakra.h"

#define RAM_FILES 16
#define RAM_SIZE 2048
struct ramfile { char name[FS_MAXNAME]; int used; u32 size; char data[RAM_SIZE]; };
static struct ramfile ram[RAM_FILES];
static int disk;

int fs_on_disk(void) { return disk; }

int fs_norm(const char *in, char out[FS_MAXNAME])
{
    int b = 0, e = 0, dot = 0, n = 0;
    for (; in[n]; n++) {
        char c = in[n];
        if (c >= 'a' && c <= 'z') c -= 32;
        if (c == '.') { if (dot || b == 0) return -1; dot = 1; continue; }
        int ok = (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');
        for (const char *p = "_-~!#$%&()@^'{}"; !ok && *p; p++) if (*p == c) ok = 1;
        if (!ok) return -1;
        if (dot) { if (++e > 3) return -1; } else if (++b > 8) return -1;
    }
    if (!b) return -1;
    int k = 0;
    for (int i = 0; in[i]; i++) { char c = in[i]; if (c >= 'a' && c <= 'z') c -= 32; out[k++] = c; }
    out[k] = 0;
    return 0;
}

static struct ramfile *rfind(const char *n)
{ for (int i = 0; i < RAM_FILES; i++) if (ram[i].used && !strcmp(ram[i].name, n)) return &ram[i]; return NULL; }

void fs_init(void)
{
    disk = 0;
    if (ata_init() && fat12_mount() == 0) { disk = 1; return; }
    static const char *msg = "Welcome to Chakra OS.\nNo disk found, so this is a RAM disk (erased on reboot).\n";
    memset(ram, 0, sizeof(ram));
    fs_write("README.TXT", msg, strlen(msg), 0);
}

int fs_list(struct fs_entry *out, int max)
{
    u32 f = irq_save();
    int n = 0;
    if (disk) n = fat12_list(out, max);
    else for (int i = 0; i < RAM_FILES && n < max; i++)
        if (ram[i].used) { strncpy0(out[n].name, ram[i].name, FS_MAXNAME); out[n].size = ram[i].size; n++; }
    irq_restore(f);
    return n;
}

int fs_size(const char *name, u32 *size)
{
    char n[FS_MAXNAME];
    if (fs_norm(name, n)) return -1;
    u32 f = irq_save();
    int r;
    if (disk) r = fat12_size(n, size);
    else { struct ramfile *x = rfind(n); r = x ? 0 : -1; if (x) *size = x->size; }
    irq_restore(f);
    return r;
}

int fs_read(const char *name, char *buf, u32 max, u32 *len)
{
    char n[FS_MAXNAME];
    if (fs_norm(name, n)) return -1;
    u32 f = irq_save();
    int r;
    if (disk) r = fat12_read(n, buf, max, len);
    else {
        struct ramfile *x = rfind(n);
        if (!x) r = -1; else { *len = x->size < max ? x->size : max; memcpy(buf, x->data, *len); r = 0; }
    }
    irq_restore(f);
    return r;
}

/* 0 ok, -1 bad name / no slot, -2 no space or too big */
int fs_write(const char *name, const char *data, u32 len, int append)
{
    char n[FS_MAXNAME];
    if (fs_norm(name, n)) return -1;
    u32 f = irq_save();
    int r;
    if (disk) {
        u32 old = 0;
        char *tmp = NULL;
        if (append && fat12_size(n, &old) == 0 && old) {
            tmp = kmalloc(old + len);
            if (!tmp) { irq_restore(f); return -2; }
            u32 got = 0;
            fat12_read(n, tmp, old, &got);
            memcpy(tmp + got, data, len);
            r = fat12_write(n, tmp, got + len);
            kfree(tmp);
        } else r = fat12_write(n, data, len);
    } else {
        struct ramfile *x = rfind(n);
        if (!x) {
            for (int i = 0; i < RAM_FILES; i++) if (!ram[i].used) { x = &ram[i]; break; }
            if (!x) { irq_restore(f); return -1; }
            memset(x, 0, sizeof(*x)); strncpy0(x->name, n, FS_MAXNAME); x->used = 1;
        } else if (!append) x->size = 0;
        if (x->size + len > RAM_SIZE) r = -2;
        else { memcpy(x->data + x->size, data, len); x->size += len; r = 0; }
    }
    irq_restore(f);
    return r;
}

int fs_remove(const char *name)
{
    char n[FS_MAXNAME];
    if (fs_norm(name, n)) return -1;
    u32 f = irq_save();
    int r;
    if (disk) r = fat12_remove(n);
    else { struct ramfile *x = rfind(n); r = x ? 0 : -1; if (x) x->used = 0; }
    irq_restore(f);
    return r;
}

int fs_rename(const char *a, const char *b)
{
    char x[FS_MAXNAME], y[FS_MAXNAME];
    if (fs_norm(a, x) || fs_norm(b, y)) return -1;
    u32 f = irq_save();
    int r;
    if (disk) r = fat12_rename(x, y);
    else {
        struct ramfile *s = rfind(x);
        if (!s) r = -1; else if (rfind(y)) r = -3; else { strncpy0(s->name, y, FS_MAXNAME); r = 0; }
    }
    irq_restore(f);
    return r;
}

u32 fs_total_bytes(void) { return disk ? fat12_total_bytes() : RAM_FILES * RAM_SIZE; }
u32 fs_free_bytes(void)
{
    if (disk) return fat12_free_bytes();
    u32 used = 0;
    for (int i = 0; i < RAM_FILES; i++) if (ram[i].used) used += ram[i].size;
    return RAM_FILES * RAM_SIZE - used;
}
