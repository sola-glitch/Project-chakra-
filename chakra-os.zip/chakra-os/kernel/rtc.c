#include "chakra.h"
static u8 cmos(u8 r) { outb(0x70, r); return inb(0x71); }
static int bcd(u8 v) { return (v & 0xF) + (v >> 4) * 10; }

void rtc_read(int *h, int *m, int *s, int *d, int *mo, int *y)
{
    u32 f = irq_save();
    int t = 100000; while ((cmos(0x0A) & 0x80) && --t) ;
    u8 rb = cmos(0x0B);
    u8 hh = cmos(4); int pm = hh & 0x80; hh &= 0x7F;
    int bin = rb & 4;
    *s = bin ? cmos(0) : bcd(cmos(0));
    *m = bin ? cmos(2) : bcd(cmos(2));
    *h = bin ? hh : bcd(hh);
    if (!(rb & 2)) { *h %= 12; if (pm) *h += 12; }
    *d = bin ? cmos(7) : bcd(cmos(7));
    *mo = bin ? cmos(8) : bcd(cmos(8));
    *y = 2000 + (bin ? cmos(9) : bcd(cmos(9)));
    irq_restore(f);
}
