/* PCI configuration space access (mechanism 1) and device list. */
#include "chakra.h"
#define MAXDEV 40
static struct pci_dev devs[MAXDEV];
static int ndev;

static u32 rd(u8 b, u8 d, u8 f, u8 off)
{ outl(0xCF8, 0x80000000u | ((u32)b << 16) | ((u32)d << 11) | ((u32)f << 8) | (off & 0xFC)); return inl(0xCFC); }
static void wr(u8 b, u8 d, u8 f, u8 off, u32 v)
{ outl(0xCF8, 0x80000000u | ((u32)b << 16) | ((u32)d << 11) | ((u32)f << 8) | (off & 0xFC)); outl(0xCFC, v); }

int pci_scan(void)
{
    ndev = 0;
    for (int b = 0; b < 256 && ndev < MAXDEV; b++)
        for (int d = 0; d < 32; d++) {
            if ((rd(b, d, 0, 0) & 0xFFFF) == 0xFFFF) continue;
            int nf = (rd(b, d, 0, 0x0C) & 0x800000) ? 8 : 1;
            for (int f = 0; f < nf && ndev < MAXDEV; f++) {
                u32 id = rd(b, d, f, 0);
                if ((id & 0xFFFF) == 0xFFFF) continue;
                struct pci_dev *p = &devs[ndev++];
                u32 cl = rd(b, d, f, 8);
                p->bus = b; p->dev = d; p->fn = f;
                p->vendor = id & 0xFFFF; p->device = id >> 16;
                p->class = cl >> 24; p->sub = (cl >> 16) & 0xFF; p->prog = (cl >> 8) & 0xFF;
                p->irq = rd(b, d, f, 0x3C) & 0xFF;
                for (int i = 0; i < 6; i++) p->bar[i] = rd(b, d, f, 0x10 + i * 4);
            }
        }
    return ndev;
}
int pci_count(void) { return ndev; }
struct pci_dev *pci_get(int i) { return (i >= 0 && i < ndev) ? &devs[i] : NULL; }
struct pci_dev *pci_find_class(u8 c, u8 s, int nth)
{ for (int i = 0; i < ndev; i++) if (devs[i].class == c && devs[i].sub == s && nth-- == 0) return &devs[i]; return NULL; }
struct pci_dev *pci_find_id(u16 v, u16 d)
{ for (int i = 0; i < ndev; i++) if (devs[i].vendor == v && devs[i].device == d) return &devs[i]; return NULL; }
u32 pci_read32(struct pci_dev *d, u8 off) { return rd(d->bus, d->dev, d->fn, off); }
void pci_write32(struct pci_dev *d, u8 off, u32 v) { wr(d->bus, d->dev, d->fn, off, v); }
void pci_enable(struct pci_dev *d)
{ pci_write32(d, 4, (pci_read32(d, 4) & 0xFFFF) | 7); }

const char *pci_class_name(u8 c, u8 s)
{
    switch (c) {
    case 0x01: return s == 1 ? "IDE controller" : s == 6 ? "SATA controller" : "storage controller";
    case 0x02: return "network controller";
    case 0x03: return "display controller";
    case 0x04: return "multimedia";
    case 0x06: return s == 0 ? "host bridge" : s == 1 ? "ISA bridge" : "bridge";
    case 0x0C: return s == 3 ? "USB controller" : "serial bus";
    case 0x0D: return "wireless controller";
    default: return "device";
    }
}
