; ============================================================
;  Chakra OS - STAGE 1 boot sector (FAT12 volume header)
;  Job: load stage 2 (disk sectors 1..8) to 0x7E00 and jump to it.
;  It must be tiny: 512 bytes, and it begins with a FAT12 BPB so the
;  whole disk is a normal FAT12 volume that other tools can read.
; ============================================================
[bits 16]
[org 0x7C00]

    jmp short start
    nop
; ---- FAT12 BIOS Parameter Block (matches tools/mkimage.py) ----
    db "CHAKRA  "          ; OEM name
    dw 512                 ; bytes per sector
    db 1                   ; sectors per cluster
    dw 9                   ; reserved sectors: boot sector + 8 for stage 2
    db 2                   ; number of FATs
    dw 224                 ; root directory entries
    dw 2880                ; total sectors (1.44 MB)
    db 0xF0                ; media descriptor
    dw 9                   ; sectors per FAT
    dw 18                  ; sectors per track
    dw 2                   ; heads
    dd 0                   ; hidden sectors
    dd 0                   ; total sectors (32-bit)
    db 0                   ; drive number
    db 0                   ; reserved
    db 0x29                ; extended boot signature
    dd 0x43484B52          ; volume serial
    db "CHAKRA     "       ; volume label (11)
    db "FAT12   "          ; file system type (8)

start:
    jmp 0x0000:.go         ; normalise CS:IP
.go:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti
    mov [boot_drive], dl

    mov si, 3                      ; three attempts
.retry:
    mov ax, 0x0208                 ; read 8 sectors
    mov bx, 0x7E00                 ; into 0000:7E00
    mov cx, 0x0002                 ; cylinder 0, sector 2
    xor dh, dh                     ; head 0
    mov dl, [boot_drive]
    int 0x13
    jnc .ok
    xor ax, ax                     ; reset disk and try again
    mov dl, [boot_drive]
    int 0x13
    dec si
    jnz .retry
    mov si, msg_err
.print:
    lodsb
    test al, al
    jz .halt
    mov ah, 0x0E
    xor bx, bx
    int 0x10
    jmp .print
.halt:
    cli
    hlt
    jmp .halt
.ok:
    mov dl, [boot_drive]
    jmp 0x0000:0x7E00

msg_err:    db "Chakra: cannot read stage 2", 0
boot_drive: db 0

times 510 - ($ - $$) db 0
dw 0xAA55
