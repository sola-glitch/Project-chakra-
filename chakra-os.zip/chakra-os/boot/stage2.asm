; ============================================================
;  Chakra OS - STAGE 2 loader                      BIOS / x86
;  Runs at 0x7E00 (loaded by stage 1). Real mode. It:
;    1. detects memory (E820 map + E801 total)  -> BootInfo at 0x500
;    2. reads the FAT12 volume and finds KERNEL.BIN in the root dir
;    3. follows the FAT cluster chain, loading it to 0x10000
;    4. enters 32-bit protected mode and jumps to the kernel
;  BootInfo layout at 0x500:
;    +0 magic 'CHKB'  +4 total KB  +8 boot drive  +12 E820 count
;    +16 E820 entries, 24 bytes each (up to 20)
; ============================================================
[bits 16]
[org 0x7E00]

BPB         equ 0x7C00          ; stage 1 is still in memory
ROOT_BUF    equ 0x9000
FAT_BUF     equ 0xB000
KERNEL_SEG  equ 0x1000

stage2:
    mov [boot_drive], dl
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ax, 0x0003
    int 0x10
    mov si, msg_hello
    call print

    ; ---- drive capabilities
    mov byte [spt], 18
    mov byte [heads], 2
    mov ah, 0x08                  ; CHS geometry (used only if no LBA support)
    mov dl, [boot_drive]
    xor di, di
    int 0x13
    jc .geo_done
    mov al, cl
    and al, 0x3F
    jz .geo_done
    mov [spt], al
    inc dh
    mov [heads], dh
.geo_done:
    xor ax, ax
    mov es, ax
    mov ah, 0x41
    mov bx, 0x55AA
    mov dl, [boot_drive]
    int 0x13
    jc .noext
    cmp bx, 0xAA55
    jne .noext
    test cx, 1
    jz .noext
    mov byte [have_ext], 1
.noext:

    ; ---- BootInfo: magic, drive
    mov dword [0x500], 0x424B4843 ; 'CHKB'
    movzx eax, byte [boot_drive]
    mov [0x508], eax

    ; ---- total memory in KB (E801, fallback 88h)
    xor cx, cx
    xor dx, dx
    mov ax, 0xE801
    int 0x15
    jc .mem_old
    test ax, ax
    jnz .have801
    mov ax, cx
    mov bx, dx
.have801:
    movzx eax, ax
    movzx ebx, bx
    shl ebx, 6
    add eax, ebx
    add eax, 1024
    jmp .mem_store
.mem_old:
    mov ah, 0x88
    int 0x15
    movzx eax, ax
    add eax, 1024
.mem_store:
    mov [0x504], eax

    ; ---- E820 memory map
    xor ebx, ebx
    mov di, 0x510
    xor bp, bp
.e820:
    mov dword [di + 20], 1
    mov eax, 0xE820
    mov edx, 0x534D4150
    mov ecx, 24
    int 0x15
    jc .e820_done
    cmp eax, 0x534D4150
    jne .e820_done
    inc bp
    add di, 24
    cmp bp, 20
    jae .e820_done
    test ebx, ebx
    jnz .e820
.e820_done:
    movzx eax, bp
    mov [0x50C], eax

    ; ---- FAT12 geometry from the BPB
    movzx eax, word [BPB + 0x0E]  ; reserved sectors
    mov [fat_lba], eax
    movzx ebx, byte [BPB + 0x10]  ; FAT count
    movzx ecx, word [BPB + 0x16]  ; sectors per FAT
    imul ebx, ecx
    add eax, ebx
    mov [root_lba], eax
    movzx ebx, word [BPB + 0x11]  ; root entries
    shl ebx, 5
    add ebx, 511
    shr ebx, 9
    add eax, ebx
    mov [data_lba], eax

    ; ---- read FAT to FAT_BUF
    mov eax, [fat_lba]
    movzx cx, byte [BPB + 0x16]
    mov bx, FAT_BUF
.rf:
    call read_sector
    inc eax
    add bx, 512
    loop .rf

    ; ---- read root directory to ROOT_BUF
    mov eax, [root_lba]
    movzx ecx, word [BPB + 0x11]
    shl ecx, 5
    add ecx, 511
    shr ecx, 9
    mov bx, ROOT_BUF
.rr:
    call read_sector
    inc eax
    add bx, 512
    loop .rr

    ; ---- find KERNEL.BIN
    mov si, ROOT_BUF
    mov bp, [BPB + 0x11]
.search:
    cmp byte [si], 0
    je not_found
    push si
    mov di, kname
    mov cx, 11
    repe cmpsb
    pop si
    je .found
    add si, 32
    dec bp
    jnz .search
    jmp not_found
.found:
    mov ax, [si + 26]             ; first cluster
    mov word [dst_seg], KERNEL_SEG
    push ax                       ; print() clobbers AX
    mov si, msg_load
    call print
    pop ax

    ; ---- follow the cluster chain
.load:
    push ax
    movzx edx, ax
    sub edx, 2
    movzx ecx, byte [BPB + 0x0D]
    imul edx, ecx
    add edx, [data_lba]
    mov eax, edx
    mov es, [dst_seg]
    xor bx, bx
    movzx cx, byte [BPB + 0x0D]
.sec:
    call read_sector
    inc eax
    add bx, 512
    loop .sec
    xor ax, ax
    mov es, ax
    movzx ax, byte [BPB + 0x0D]
    shl ax, 5                     ; sectors * 512 / 16 paragraphs
    add [dst_seg], ax
    pop ax
    mov bx, ax                    ; next = FAT12[cluster]
    shr bx, 1
    add bx, ax
    mov dx, [bx + FAT_BUF]
    test al, 1
    jz .even
    shr dx, 4
    jmp .got
.even:
    and dx, 0x0FFF
.got:
    mov ax, dx
    cmp ax, 0xFF8
    jb .load

    ; ---- graphics mode (VBE) unless T is pressed within about half a second
    mov si, msg_gfx
    call print
    mov ah, 0x00
    int 0x1A
    mov [t0], dx
.gwait:
    mov ah, 0x01
    int 0x16
    jnz .gkey
    mov ah, 0x00
    int 0x1A
    sub dx, [t0]
    cmp dx, 10
    jb .gwait
    jmp .gtry
.gkey:
    mov ah, 0x00
    int 0x16
    or al, 0x20
    cmp al, 't'
    je .gdone
.gtry:
    call vbe_setup
.gdone:
    ; ---- protected mode
    mov si, msg_go
    call print
    mov ax, 0x2401                ; A20 via BIOS, then fast gate
    int 0x15
    in al, 0x92
    or al, 2
    and al, 0xFE
    out 0x92, al
    cli
    lgdt [gdt_desc]
    mov eax, cr0
    or eax, 1
    mov cr0, eax
    jmp dword 0x08:pm_entry

; ---------------- VBE: copy the BIOS 8x16 font, pick a 32-bit mode, set it ----------------
vbe_setup:
    pusha
    push es
    mov ax, 0x1130                ; get pointer to the 8x16 ROM font in ES:BP
    mov bh, 6
    int 0x10
    push ds
    push es
    pop ds
    mov si, bp
    xor ax, ax
    mov es, ax
    mov di, 0x2000
    mov cx, 2048
    cld
    rep movsw
    pop ds
    xor ax, ax
    mov es, ax
    mov dword [0x3000], 'VBE2'
    mov ax, 0x4F00
    mov di, 0x3000
    int 0x10
    cmp ax, 0x004F
    jne .done
    mov ax, [0x300E]
    mov [mlist_off], ax
    mov ax, [0x3010]
    mov [mlist_seg], ax
    mov byte [pass], 0
.pass:
    movzx bx, byte [pass]
    shl bx, 2
    mov ax, [wants + bx]
    mov [want_w], ax
    mov ax, [wants + bx + 2]
    mov [want_h], ax
    mov si, [mlist_off]
    mov ax, [mlist_seg]
    mov fs, ax
.next:
    mov cx, [fs:si]
    add si, 2
    cmp cx, 0xFFFF
    je .nextpass
    push si
    push cx
    mov ax, 0x4F01
    mov di, 0x3200
    int 0x10
    pop cx
    pop si
    cmp ax, 0x004F
    jne .next
    mov ax, [0x3200]
    and ax, 0x91                  ; supported + graphics + linear framebuffer
    cmp ax, 0x91
    jne .next
    cmp byte [0x3219], 32
    jne .next
    mov ax, [0x3212]
    cmp ax, [want_w]
    jne .next
    mov ax, [0x3214]
    cmp ax, [want_h]
    jne .next
    mov [vbe_mode], cx
    jmp .set
.nextpass:
    inc byte [pass]
    cmp byte [pass], 3
    jb .pass
    jmp .done
.set:
    mov bx, [vbe_mode]
    or bx, 0x4000
    mov ax, 0x4F02
    int 0x10
    cmp ax, 0x004F
    jne .done
    mov dword [0x6F0], 1
    mov eax, [0x3228]
    mov [0x6F4], eax
    movzx eax, word [0x3212]
    mov [0x6F8], eax
    movzx eax, word [0x3214]
    mov [0x6FC], eax
    movzx eax, word [0x3210]
    mov [0x700], eax
    mov dword [0x704], 32
.done:
    pop es
    popa
    ret

not_found:
    mov si, msg_nok
    call print
    cli
.h: hlt
    jmp .h

; ---------------- read one sector: EAX = LBA, ES:BX = buffer ----------------
read_sector:
    pushad
    mov byte [retries], 3
.again:
    cmp byte [have_ext], 0
    je .chs
    mov [dap_lba], eax
    mov [dap_off], bx
    mov [dap_seg], es
    mov word [dap_count], 1
    mov si, dap
    mov dl, [boot_drive]
    mov ah, 0x42
    int 0x13
    jc .err
    popad
    ret
.chs:
    push eax
    xor edx, edx
    movzx ecx, byte [spt]
    div ecx
    inc dl
    mov [t_sec], dl
    xor edx, edx
    movzx ecx, byte [heads]
    div ecx
    mov dh, dl
    mov ch, al
    shl ah, 6
    mov cl, [t_sec]
    or cl, ah
    mov dl, [boot_drive]
    mov ax, 0x0201
    int 0x13
    pop eax
    jc .err
    popad
    ret
.err:
    xor ax, ax
    mov dl, [boot_drive]
    int 0x13
    mov eax, [esp + 28]           ; restore LBA saved by pushad
    mov bx, [esp + 16]            ; and BX
    dec byte [retries]
    jnz .again
    mov si, msg_dsk
    call print
    cli
.hh: hlt
    jmp .hh

print:
    lodsb
    test al, al
    jz .d
    mov ah, 0x0E
    xor bx, bx
    int 0x10
    jmp print
.d: ret

[bits 32]
pm_entry:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, 0x90000
    jmp 0x10000

[bits 16]
msg_hello:  db "Chakra stage 2", 13, 10, 0
msg_load:   db "Loading KERNEL.BIN...", 13, 10, 0
msg_gfx:    db "Press T for text mode...", 13, 10, 0
msg_go:     db "Starting kernel", 13, 10, 0
msg_nok:    db "KERNEL.BIN not found", 0
msg_dsk:    db "Disk read error", 0
kname:      db "KERNEL  BIN"

boot_drive: db 0
have_ext:   db 0
spt:        db 18
heads:      db 2
t_sec:      db 0
retries:    db 0
dst_seg:    dw 0
t0:         dw 0
mlist_off:  dw 0
mlist_seg:  dw 0
vbe_mode:   dw 0
want_w:     dw 0
want_h:     dw 0
pass:       db 0
wants:      dw 800, 600, 1024, 768, 640, 480
fat_lba:    dd 0
root_lba:   dd 0
data_lba:   dd 0

dap:        db 0x10, 0
dap_count:  dw 0
dap_off:    dw 0
dap_seg:    dw 0
dap_lba:    dq 0

gdt:
    dq 0
    dq 0x00CF9A000000FFFF
    dq 0x00CF92000000FFFF
gdt_end:
gdt_desc:
    dw gdt_end - gdt - 1
    dd gdt
